---
-- BitTorrent client WebUI feature.
-- @release $Id: btc.lua 154043 2011-04-26 17:17:34Z marina.maslova $
--

local crm           = require("webui.crm")
local btc  = {}

function btc.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().btc.exists()

    t:close()

    return present
end

return btc
