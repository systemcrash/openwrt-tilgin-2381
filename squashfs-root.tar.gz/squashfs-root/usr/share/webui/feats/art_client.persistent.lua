---
-- Wi-Fi ART (Atheros Radio Test) client support WebUI feature.
-- @release $Id: art_client.lua 141635 2009-12-09 13:25:37Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local art_client    = {}

function art_client.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().wlan.art_client.exists()

    t:close()

    return present
end


return art_client
