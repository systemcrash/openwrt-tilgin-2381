---
-- Speed test WebUI feature.
-- @release $Id: speed_test.lua 160576 2012-06-08 16:43:53Z michael.kochkin $
--

local crm           = require("webui.crm")
local speed_test  = {}

function speed_test.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().net_diag.load.exists()

    t:close()

    return present
end

return speed_test
