---
-- WAN port Ethernet phy WebUI feature.
-- @release $Id:$
--

local crm           = require("webui.crm")
local wan_phy_eth   = {}


function wan_phy_eth.check()
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local present   = false

    for dev_id, dev in mit.connection.device.table.
                        aka(_("connection device set")).
                        iaka(_("connection device #%s")).as_iter() do
        if dev.port.port_type.aka(_("port type")).get_string() ==
           "eth_port" then
            present = true
            break
        end
    end

    t:close()

    return present
end


return wan_phy_eth
