---
-- SNMP WebUI feature.
-- @release $Id: snmp.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local snmp  = {}

function snmp.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().snmp.exists()

    t:close()

    return present
end

return snmp
