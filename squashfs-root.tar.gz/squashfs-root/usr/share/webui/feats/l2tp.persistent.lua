---
-- l2tp WebUI feature.
-- @release $Id: l2tp.lua 167572 2014-07-08 16:12:40Z michael.kochkin $
--

local crm           = require("webui.crm")
local l2tp  = {}

function l2tp.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().l2tp.exists()

    t:close()

    return present
end

return l2tp
