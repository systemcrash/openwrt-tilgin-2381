---
-- Security WebUI feature.
-- @release $Id: security.lua 167572 2014-07-08 16:12:40Z michael.kochkin $
--

local crm           = require("webui.crm")
local security  = {}

function security.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().security.exists()

    t:close()

    return present
end

return security
