---
-- WLAN support WebUI feature.
-- @release $Id: wlan.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm   = require("webui.crm")
local wlan  = {}

function wlan.check()
    local t         = crm.transaction():webui_open_ro()
    local wlan_port = t:mit().wlan.port.aka(_("WLAN port"))
    local present   = wlan_port.exists() and wlan_port.get_link():len() > 0

    t:close()

    return present
end


return wlan
