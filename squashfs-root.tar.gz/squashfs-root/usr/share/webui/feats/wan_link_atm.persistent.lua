---
-- WAN port Ethernet link WebUI feature.
-- @release $Id:$
--

local crm           = require("webui.crm")
local wan_link_atm  = {}


function wan_link_atm.check()
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local present   = false

    for dev_id, dev in mit.connection.device.table.
                        aka(_("connection device set")).
                        iaka(_("connection device #%s")).as_iter() do
        if dev.link.prop.conn_stack.stack.name.aka(_("stack name")).
                get_string() == "atm" then
            present = true
            break
        end
    end

    t:close()

    return present
end


return wan_link_atm
