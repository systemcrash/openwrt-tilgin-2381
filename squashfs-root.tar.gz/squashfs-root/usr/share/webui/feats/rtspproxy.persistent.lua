---
-- RTSP proxy WebUI feature.
-- @release $Id: rtspproxy.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local rtspproxy  = {}

function rtspproxy.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().rtspproxy.exists()

    t:close()

    return present
end

return rtspproxy
