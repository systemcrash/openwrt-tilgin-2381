---
-- Wi-Fi ART (Atheros Radio Test) client presence WebUI feature.
-- @release $Id: art_client_enabled.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm   = require("webui.crm")
local art_client_enabled   = {}

function art_client_enabled.check()
    local t             = crm.transaction():webui_open_ro()
    local art_client    = t:mit().wlan.art_client
    local present       = art_client.exists() and
                          art_client.enabled.get_boolean()

    t:close()

    return present
end


return art_client_enabled
