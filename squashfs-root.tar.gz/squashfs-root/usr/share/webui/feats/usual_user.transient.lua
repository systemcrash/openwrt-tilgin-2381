---
-- User with access_level = user WebUI feature.
-- @release $Id:$
--

local crm           = require("webui.crm")
local usual_user  = {}


function usual_user.check()
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local present   = false

    for user_id, user in mit.webui.user.
                        aka(_("user set")).
                        iaka(_("user #%s")).as_iter() do
        if user.access_level.name.aka(_("access_level name")).
                get_string() == "user" then
            present = true
            break
        end
    end

    t:close()

    return present
end


return usual_user
