---
-- WLAN button WebUI feature.
-- @release $Id:$
--

local crm   = require("webui.crm")
local wlan_button   = {}

function wlan_button.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().button.list.wlan_security.exists()

    t:close()

    return present
end


return wlan_button
