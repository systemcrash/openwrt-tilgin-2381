---
-- strg WebUI feature.
-- @release $Id: $
--

local crm           = require("webui.crm")
local extfs  = {}

function extfs.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().extfs.exists()

    if present == true then
        present = t:mit().extfs.supported.get_boolean()
    end
    t:close()

    return present
end

return extfs
