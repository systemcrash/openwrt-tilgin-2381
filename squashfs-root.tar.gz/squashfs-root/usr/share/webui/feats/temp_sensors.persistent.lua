---
-- Temperature sensor presence WebUI feature.
-- @release $Id: temp_sensors.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local temp_sensors  = {}

function temp_sensors.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().temp_sensor.exists()

    t:close()

    return present
end


return temp_sensors
