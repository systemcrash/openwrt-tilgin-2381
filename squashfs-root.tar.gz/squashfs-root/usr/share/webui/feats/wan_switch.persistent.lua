---
-- WAN switch support WebUI feature.
-- @release $Id:$
--

local fs            = require("fs")
local wan_switch    = {}

local function check_proc()
     local f = io.open("/proc/vood_ng/wan_switch", "r")
     if f ~= nil then
         io.close(f)
     end
     return (f ~= nil)
end

local function check_sys()
    local f
    local c

    for input in fs.dir.iter("/sys/class/input") do
        if (input:match("^input%d+$")) then
            f = io.open("/sys/class/input/" .. input ..
                        "/capabilities/key")
            c = f:read("*a")
            f:close()
            -- FIXME use bit matching
            if (c == "200 0 0 0 0 0 0 0 0\n") then
                return true
            end
        end
    end

    return false
end

function wan_switch.check()
    return check_proc() or check_sys()
end


return wan_switch
