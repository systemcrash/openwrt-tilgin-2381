---
-- Optional button WebUI feature.
-- @release $Id:$
--

local crm   = require("webui.crm")
local optional_button   = {}

function optional_button.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().button.list.optional.exists()

    t:close()

    return present
end


return optional_button
