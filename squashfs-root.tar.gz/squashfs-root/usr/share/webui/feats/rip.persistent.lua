---
-- RIP WebUI feature.
-- @release $Id: rip.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local rip  = {}

function rip.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().rip.exists()

    t:close()

    return present
end

return rip
