---
-- terminal equipment WebUI feature.
-- @release $Id: $
--

local crm           = require("webui.crm")
local term_equip  = {}

function term_equip.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().term_equip.exists()

    t:close()

    return present
end

return term_equip
