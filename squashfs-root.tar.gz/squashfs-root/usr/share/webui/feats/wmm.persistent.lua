---
-- Wi-Fi multimedia (WMM) support WebUI feature.
-- @release $Id:$
--

local crm   = require("webui.crm")
local wmm   = {}

function wmm.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().enum.wlan_wmm_ac.exists()

    t:close()

    return present
end


return wmm
