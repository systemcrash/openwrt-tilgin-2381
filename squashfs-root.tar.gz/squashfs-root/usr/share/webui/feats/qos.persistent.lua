---
-- QoS WebUI feature.
-- @release $Id: qos.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local qos  = {}

function qos.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().qos.exists()

    t:close()

    return present
end

return qos
