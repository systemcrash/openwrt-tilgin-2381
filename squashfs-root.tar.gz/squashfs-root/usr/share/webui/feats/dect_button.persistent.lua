---
-- DECT button WebUI feature.
-- @release $Id:$
--

local crm   = require("webui.crm")
local dect_button   = {}

function dect_button.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().button.list.dect_security.exists()

    t:close()

    return present
end


return dect_button
