---
-- strg WebUI feature.
-- @release $Id: $
--

local crm           = require("webui.crm")
local ppe  = {}

function ppe.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().ppe.exists()

    t:close()

    return present
end

return ppe
