---
-- ATM OAM support WebUI feature.
-- @release $Id: atm_oam.lua 148238 2010-07-23 15:38:56Z nikolai.kondrashov $
--

local crm       = require("webui.crm")
local atm_oam   = {}

function atm_oam.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().oam.exists()

    t:close()

    return present
end


return atm_oam
