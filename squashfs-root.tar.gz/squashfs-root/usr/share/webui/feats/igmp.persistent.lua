---
-- IGMP WebUI feature.
-- @release $Id: igmp.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local igmp  = {}

function igmp.check()
    local t         = crm.transaction():webui_open_ro()
    local hw_switch = t:mit().igmp.hw_switch
    local present   = hw_switch.exists() and hw_switch.get_link():len() > 0
                      
    t:close()

    return present
end

return igmp
