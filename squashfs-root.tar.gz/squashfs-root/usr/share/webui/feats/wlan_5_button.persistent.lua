---
-- WLAN_5 button WebUI feature.
-- @release $Id:$
--

local crm   = require("webui.crm")
local wlan_5_button   = {}

function wlan_5_button.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().button.list.wlan_5_security.exists()

    t:close()

    return present
end


return wlan_5_button
