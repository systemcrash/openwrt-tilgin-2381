---
-- Transceiver presence WebUI feature.
-- @release $Id:$
--

local crm   = require("webui.crm")
local trx   = {}

function trx.check()
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local trx_type  = mit.port.WAN.fb_transmitter_type.name.
                        aka(_("fiber transceiver type"))
    local present

    present = trx_type.exists() and (trx_type.get_string() ~= "none")

    t:close()

    return present
end


return trx
