---
-- Ping WebUI feature.
-- @release $Id: ping.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local ping  = {}

function ping.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().ping.exists()

    t:close()

    return present
end

return ping
