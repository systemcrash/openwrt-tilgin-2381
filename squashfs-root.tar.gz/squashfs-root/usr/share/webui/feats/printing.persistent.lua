---
-- Printing WebUI feature.
-- @release $Id: printing.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local printing  = {}

function printing.check()
    local t         = crm.transaction():webui_open_ro()
    local present   = t:mit().printing.exists()

    t:close()

    return present
end

return printing
