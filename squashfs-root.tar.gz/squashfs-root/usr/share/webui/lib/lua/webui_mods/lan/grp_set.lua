---
-- WebUI module library - LAN group set
-- @release $Id: grp_set.lua 166903 2014-05-27 14:32:43Z maxim.menshchikov $
--


local crm               = require("webui.crm")
local webui_mods        = {}
webui_mods.lan          = {}
webui_mods.lan.grp_set  = {}
webui_mods.lan.grp      = require("webui_mods.lan.grp")


function webui_mods.lan.grp_set.path_valid(path)
    return path:match("^/lan/group/[^/]+") ~= nil
end


function webui_mods.lan.grp_set.slct_path(hdf, path)
    local id

    if path:len() == 0 then
        return
    end

    id = path:match("^/lan/group/([^/]+)")

    if id then
        hdf.lan_group[id] = true
        hdf.lan_group = id;
    else
        error(string.format(_("invalid LAN group path \"%s\""), path))
    end
end


function webui_mods.lan.grp_set.smmr(hdf, mit)
    local h_list = hdf.lan_group.create()

    for id, c in mit.lan.group.aka(_("LAN group set")).
                               iaka(_("LAN group #%s")).
                               as_iter_readable() do
        if c.visible() then
            webui_mods.lan.grp.smmr(h_list[id].create(), c)
        end
    end
end


function webui_mods.lan.grp_set.fetch_client_list(h, mit)
    local h_list = h.lan_group.create()

    for grp_id, c_grp in mit.lan.group.aka(_("LAN group set")).
                                       iaka(_("LAN group #%s")).
                                       as_iter_readable() do
        if c_grp.visible() then
            webui_mods.lan.grp.fetch_client_list(h_list[grp_id].create(), c_grp)
        end
    end
end


function webui_mods.lan.grp_set.apply_client_list(mit, h)
    local c_list = mit.lan.group.iaka(_("LAN group #%s"))

    for grp_id, h_grp in h.lan_group.iaka(_("LAN group #%s")).iter() do
        webui_mods.lan.grp.apply_client_list(c_list[grp_id], h_grp)
    end
end


function webui_mods.lan.grp_set.get_path(hdf)
    local id = hdf.lan_group.get() or ""

    return (id == "") and "" or ("/lan/group/" .. id)
end


return webui_mods.lan.grp_set


