---
-- WebUI module library - packet filter key
-- @release $Id: key.lua 142061 2009-12-18 18:04:12Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local webui_mods        = {}
webui_mods.iface        = {}
webui_mods.iface.tree   = require("webui_mods.iface.tree")
webui_mods.pf           = {}
webui_mods.pf.key       = {}
webui_mods.pf.key.type  = {}

local key_type = webui_mods.pf.key.type

--
-- "in" key
--
key_type["in"] = {}

key_type["in"].title = _("input interface")

key_type["in"].fetch = function (h, c)
    local iface_id, iface_link

    for iface_id, iface_link in
        c.iface.aka(_("interface set")).
                iaka(_("interface link #%s")).as_iter() do
        webui_mods.iface.tree.slct(h.iface, iface_link.get_link())
    end
end

key_type["in"].apply = function (c, h)
    local h_iface_list = {webui_mods.iface.tree.path(h.iface)}
    local h_iface_set = {}
    local iface_index
    local iface_path
    local iface_link

    -- Convert interface array to set
    for iface_index, iface_path in ipairs(h_iface_list) do
        h_iface_set[iface_path] = true
    end

    -- For each interface in the CRM
    for iface_index, iface_link in
        c.iface.aka(_("interface set")).
                iaka(_("interface #%s")).as_iter() do
        iface_path = iface_link.get_link()

        -- If interface is not in the form
        if not h_iface_set[iface_path] then
            c.del.aka(_("delete interface")).
                exec({iface = crm.value.link(iface_path)})
        end

        -- Remove interface from the set as processed
        h_iface_set[iface_path] = nil
    end

    -- For each interface left in the set
    for iface_path in pairs(h_iface_set) do
        -- Add it
        c.add.aka(_("add interface")).
            exec({iface = crm.value.link(iface_path)})
    end
end


--
-- MAC address key
--
local function fetch_key_mac(h, c)
    local address, mask

    address = c.mac.aka(_("address")).get()
    mask = c.mask.aka(_("mask")).get()

    h.address = address:get_octets_as_mac_addr()
    address:mask_octets_with_octets(mask)
    h.masked_address = address:get_octets_as_mac_addr()
    h.mask = mask:get_octets_as_mac_addr()
end

local function apply_key_mac(c, h)
    c.mac.aka(_("address")).set(h.address.aka(_("address")).as_crm_mac_addr())
    c.mask.aka(_("mask")).set(h.mask.aka(_("mask")).as_crm_mac_addr())
end

local dflt_key_mac = {
    address = "00:00:00:00:00:00",
    mask = "FF:FF:FF:FF:FF:FF"
}


--
-- "src_mac" key
--
key_type.src_mac = {}
key_type.src_mac.title  = _("source MAC address")
key_type.src_mac.fetch  = fetch_key_mac
key_type.src_mac.apply  = apply_key_mac
key_type.src_mac.dflt   = dflt_key_mac


--
-- "dst_mac" key
--
key_type.dst_mac        = {}
key_type.dst_mac.title  = _("destination MAC address")
key_type.dst_mac.fetch  = fetch_key_mac
key_type.dst_mac.apply  = apply_key_mac
key_type.dst_mac.dflt   = dflt_key_mac


--
-- "ether_type" key
--
key_type.ether_type         = {}
key_type.ether_type.title   = _("Ethernet type")

function key_type.ether_type.fetch(h, c)
    h.ether_type = c.ether_type.aka(_("Ethernet type")).as_string()
end

function key_type.ether_type.apply(c, h)
    c.ether_type.aka(_("type")).set_u16(
        h.ether_type[h.rep.get()].aka(_("type")).req_range(0, 65535))
end


key_type.ether_type.dflt = {ether_type = 0}


--
-- "ether_prio" key
--
key_type.ether_prio         = {}
key_type.ether_prio.title   = _("Ethernet IEEE 802.1p priority")

function key_type.ether_prio.fetch(h, c)
    h.prio = c.prio.aka(_("priority")).as_string()
end

function key_type.ether_prio.apply(c, h)
    c.prio.aka(_("priority")).set_u8(h.prio.aka(_("priority")).req_range(0, 7))
end

key_type.ether_prio.dflt = {prio = 0}


--
-- "ip_tos" key
--
key_type.ip_tos         = {}
key_type.ip_tos.title   = _("IP TOS field")

function key_type.ip_tos.fetch(h, c)
    h.tos = c.tos.aka(_("value")).as_string()
end

function key_type.ip_tos.apply(c, h)
    c.tos.aka(_("value")).set_u8(h.tos.aka(_("value")).req_range(0, 255))
end

key_type.ip_tos.dflt = {tos = 0}


--
-- "ip_proto" key
--
key_type.ip_proto       = {}
key_type.ip_proto.title = _("IP protocol")

function key_type.ip_proto.fetch(h, c)
    h.proto = c.proto.aka(_("protocol")).as_string()
end

function key_type.ip_proto.apply(c, h)
    c.proto.aka(_("protocol")).set_u8(
        h.proto[h.rep.get()].aka(_("protocol")).req_range(0, 255))
end

key_type.ip_proto.dflt = {proto = 0}


--
-- IP address key
--
local function fetch_key_ip(h, c)
    local address, prefix

    address = c.ip.aka(_("address")).get()
    prefix = c.prefix.aka(_("prefix")).as_number()

    h.address = address:get_octets_as_ip_addr()
    address:mask_octets_with_prefix(prefix)
    h.masked_address = address:get_octets_as_ip_addr()
    h.prefix = prefix
end

local function apply_key_ip(c, h)
    c.ip.aka(_("address")).set(
        h.address.aka(_("address")).as_crm_ip_addr())
    c.prefix.aka(_("prefix")).set_u8(
        h.prefix.aka(_("prefix")).req_range(0, 32))
end

local dflt_key_ip = {
    address = "0.0.0.0",
    prefix = 32
}


--
-- "src_ip" key
--
key_type.src_ip = {}
key_type.src_ip.title   = _("source IP address")
key_type.src_ip.fetch   = fetch_key_ip
key_type.src_ip.apply   = apply_key_ip
key_type.src_ip.dflt    = dflt_key_ip


--
-- "dst_ip" key
--
key_type.dst_ip = {}
key_type.dst_ip.title   = _("destination IP address")
key_type.dst_ip.fetch   = fetch_key_ip
key_type.dst_ip.apply   = apply_key_ip
key_type.dst_ip.dflt    = dflt_key_ip


--
-- "ip_len" key
--
key_type.ip_len         = {}
key_type.ip_len.title   = _("IP payload length")

function key_type.ip_len.fetch(h, c)
    h.min = c.low.aka(_("minimum")).as_string()
    h.max = c.high.aka(_("maximum")).as_string()
end

function key_type.ip_len.apply(c, h)
    c.low.aka(_("minimum")).set_u32(h.min.aka(_("minimum")).req_range(0, 65535))
    c.high.aka(_("maximum")).set_u32(h.max.aka(_("maximum")).req_range(0, 65535))
end

key_type.ip_len.dflt = {min = 0, max = 65535}


--
-- Port key
--
local function fetch_key_port(h, c)
    local port, rlen

    port = c.port.as_number()
    rlen = c.rlen.as_number()

    h.min = port
    h.max = port + rlen - 1
end

local function apply_key_port_single(c, h)
    c.port.set_u16(h.single.aka(_("port")).req_range(1, 65535))
    c.rlen.set_u16(1)
end

local function apply_key_port_range(c, h)
    local min, max, tmp

    min = h.min.aka(_("start")).req_range(1, 65535).as_number()
    max = h.max.aka(_("end")).req_range(1, 65535).as_number()

    if (min > max) then
        tmp = min
        min = max
        max = tmp
    end

    c.port.set_u16(min)
    c.rlen.set_u16(max - min + 1)
end

local function apply_key_port(c, h)
    local rep = h.rep.aka(_("representation"))

    if rep.get() == "single" then
        apply_key_port_single(c, h)
    elseif rep.get() == "range" then
        apply_key_port_range(c, h)
    else
        error(hdf.err.Req(_("%s is invalid"), rep))
    end
end

local dflt_key_port = {
    min = 1,
    max = 65535
}

--
-- "src_port" key
--
key_type.src_port = {}
key_type.src_port.title = _("source TCP/UDP port")
key_type.src_port.fetch = fetch_key_port
key_type.src_port.apply = apply_key_port
key_type.src_port.dflt  = dflt_key_port


--
-- "dst_port" key
--
key_type.dst_port = {}
key_type.dst_port.title = _("destination TCP/UDP port")
key_type.dst_port.fetch = fetch_key_port
key_type.dst_port.apply = apply_key_port
key_type.dst_port.dflt  = dflt_key_port


--
-- "tcp_flags" key
--
key_type.tcp_flags          = {}
key_type.tcp_flags.title    = _("TCP flags")
key_type.tcp_flags.list     = {"URG", "ACK", "PSH", "RST", "SYN", "FIN"}

function key_type.tcp_flags.fetch(h, c)
    local flag_index, flag_name

    for flag_index, flag_name in ipairs(key_type.tcp_flags.list) do
        h.mask[flag_name] = c.mask[flag_name].get_boolean()
        h.comp[flag_name] = c.comp[flag_name].get_boolean()
    end
end

function key_type.tcp_flags.apply(c, h)
    local flag_name, flag_bit

    for flag_name, flag_bit in c.mask.as_iter() do
        flag_bit.set_boolean(h.mask[flag_name].as_boolean())
    end

    for flag_name, flag_bit in c.comp.as_iter() do
        flag_bit.set_boolean(h.comp[flag_name].as_boolean())
    end
end

function key_type.tcp_flags.dflt(h)
    local flag_index, flag_name

    for flag_index, flag_name in ipairs(key_type.tcp_flags.list) do
        h.mask[flag_name] = 0
        h.comp[flag_name] = 0
    end
end


--
-- Retrieve key type descriptor.
--
function webui_mods.pf.key.get_desc(t)
    local d = key_type[t]

    if not d then
        error(_("unknown type \"%s\""):format(t))
    end

    return d
end


--
-- "apply" muxer
--
function webui_mods.pf.key.apply(t, c, h)
    local d = webui_mods.pf.key.get_desc(t)

    c.aka(_("\"%s\" key"):format(d.title))
    h.aka(_("\"%s\" key"):format(d.title))
    c.inverse.aka(_("inversion flag")).set_boolean(
        h.inverse.aka(_("inversion flag")).as_boolean())

    if d.apply then
        d.apply(c, h)
    end
end


--
-- "fetch" muxer
--
function webui_mods.pf.key.fetch(t, h, c)
    local d = webui_mods.pf.key.get_desc(t)

    h.type = t
    h.title = d.title
    c.aka(_("\"%s\" key"):format(d.title))

    h.inverse = c.inverse.aka(_("inversion flag")).get_boolean()

    if d.fetch then
        d.fetch(h, c)
    end
end


--
-- "default" muxer
--
function webui_mods.pf.key.dflt(t, h)
    local d = webui_mods.pf.key.get_desc(t)
    local dflt = d.dflt

    h.type = t
    h.title = d.title

    if type(dflt) == "table" then
        h.import_table(dflt)
    elseif type(dflt) == "function" then
        dflt(h)
    end
end

return webui_mods.pf.key
