---
-- WebUI module library - packet filter key set
-- @release $Id: key.lua 139693 2009-10-26 11:09:08Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local webui_mods        = {}
webui_mods.pf           = {}
webui_mods.pf.key       = require("webui_mods.pf.key")
webui_mods.pf.key_set   = {}


function webui_mods.pf.key_set.apply(c_filter, h_filter, type_list)
    local c_key_list    = c_filter.key.aka(_("key set")).iaka(_("\"%s\" key"))
    local h_key_list    = h_filter.key.aka(_("key set")).iaka(_("\"%s\" key"))
    local c_key_set     = c_key_list.get_set_as_map()

    local i, key_type, c_key, h_key

    -- For each supported key type
    for i, key_type in ipairs(type_list) do
        h_key = h_key_list[key_type]
        c_key = c_key_list[key_type]

        -- If the key is enabled on the form
        if h_key.as_boolean() then
            -- If there is no such key in CRM
            if not c_key_set[key_type] then
                -- Add it
                c_filter.add_key.exec({type = crm.value.string(key_type)})
            end

            -- Apply key
            webui_mods.pf.key.apply(key_type, c_key, h_key)
        else
            -- If there is such key in CRM
            if c_key_set[key_type] then
                -- Delete it
                c_filter.del_key.exec({type = crm.value.string(key_type)})
            end
        end
    end
end


function webui_mods.pf.key_set.fetch(h_filter, c_filter, type_list)
    local i, key_type, c_key, h_key
    local c_key_list = c_filter.key.aka(_("key set")).iaka(_("\"%s\" key"))
    local h_key_list = h_filter.key.create()

    -- Retrieve key list
    for i, key_type in ipairs(type_list) do
        c_key = c_key_list[key_type]
        -- Create key - it must be there to appear on the form
        h_key = h_key_list[key_type].create()

        -- If there is such key in CRM
        if c_key.exists() then
            -- Indicate it is enabled
            h_key.set(true)
            -- Fetch it
            webui_mods.pf.key.fetch(key_type, h_key, c_key)
        else
            -- Output default key parameters
            webui_mods.pf.key.dflt(key_type, h_key)
        end
    end
end


return webui_mods.pf.key_set
