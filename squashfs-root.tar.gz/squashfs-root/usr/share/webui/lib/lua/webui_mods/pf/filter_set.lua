---
-- WebUI module library - packet filter set
-- @release $Id: key.lua 139693 2009-10-26 11:09:08Z nikolai.kondrashov $
--

local crm                   = require("webui.crm")
local webui_mods            = {}
webui_mods.pf               = {}
webui_mods.pf.filter_set    = {}
webui_mods.pf.filter        = require("webui_mods.pf.filter")


function webui_mods.pf.filter_set.get_supported_key_type_list(c, key_type_list)
    local filtered_key_type_list    = {}

    if key_type_list then
        local supported_key_type_map

        supported_key_type_map = c["."].supported_key.
                                    aka(_("supported key type set")).
                                    get_set_as_map()

        for i, key_type in ipairs(key_type_list) do
            if supported_key_type_map[key_type] then
                table.insert(filtered_key_type_list, key_type)
            end
        end
    else
        filtered_key_type_list = c["."].supported_key.
                                    aka(_("supported key type set")).
                                    get_set_as_array()
    end

    return filtered_key_type_list
end


---
-- Apply filter set.
--
-- @param c Filter set CRM node (like /firewall/filter).
-- @param h Filter set HDF node (should contain "list" node with the actual
--          filter set).
-- @param o Optional options table; could contain following fields:
--              key_type_list   - set of supported keys stored as an array,
--              action_type_map - supported action set, stored as a
--                                name->flag map,
--              extra_apply_fn  - extra filter application function.
--
function webui_mods.pf.filter_set.apply(c, h, o)
    local filter_id, h_filter

    local c_filter_set = c.table.aka(_("filter set")).iaka(_("filter #%s"))
    local c_filter
    local key_type_list

    o = o or {}

    key_type_list =
        webui_mods.pf.filter_set.
            get_supported_key_type_list(c, o.key_type_list)

    for filter_id, h_filter in h.list.iaka(_("filter #%s")).iter() do
        c_filter = c_filter_set[filter_id]
        if webui_mods.pf.filter.match(c_filter,
                                      key_type_list,
                                      o.action_type_map) then
            if h_filter.delete.as_boolean() then
                c.del.aka(_("delete")).
                    exec({index = crm.value.u32(filter_id)})
            else
                webui_mods.pf.filter.apply(c_filter, h_filter,
                                           key_type_list, o.extra_apply_fn)
            end
        end
    end
end


---
-- Fetch filter set.
--
-- @param h Filter set HDF node (will contain "list" node with the actual
--          filter set).
-- @param c Filter set CRM node (like /firewall/filter).
-- @param o Optional options table; could contain following fields:
--              key_type_list   - set of supported keys stored as an array,
--              action_type_map - supported action set, stored as a
--                                name->flag map,
--              extra_fetch_fn  - extra filter fetching function.
--
function webui_mods.pf.filter_set.fetch(h, c, o)
    local h_filter_list
    local filter_id, c_filter, h_filter
    local key_type_list

    o = o or {}

    key_type_list =
        webui_mods.pf.filter_set.
            get_supported_key_type_list(c, o.key_type_list)

    h_filter_list = h.list.create()
    for filter_id, c_filter in c.table.aka(_("filter set")).
                                       iaka(_("filter #%s")).as_iter() do
        if webui_mods.pf.filter.match(c_filter,
                                      key_type_list,
                                      o.action_type_map) then
            h_filter = h_filter_list[filter_id].create()
            webui_mods.pf.filter.fetch(h_filter, c_filter,
                                       key_type_list, o.extra_fetch_fn)
        end
    end
end


---
-- Add filter to a set.
--
-- @param c             Filter set CRM node (like /firewall/filter).
-- @param label         Filter human-readable label.
-- @param action_type   Action type.
--
-- @return Added filter index in the set.
--
function webui_mods.pf.filter_set.add(c, label, action_type)
    local index

    index = c.add.aka(_("add")).exec({}, {"index"}):as_string()
    webui_mods.pf.filter.init(c.table[index].aka(_("new flow")), label, action_type)

    return index
end


return webui_mods.pf.filter_set
