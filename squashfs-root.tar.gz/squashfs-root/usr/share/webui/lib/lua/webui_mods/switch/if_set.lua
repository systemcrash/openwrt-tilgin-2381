---
-- WebUI module library - Switch port set
-- @release $Id: port.lua 138275 2009-09-18 13:34:25Z nikolai.kondrashov $
--

local webui_mods            = {}
webui_mods.switch           = {}
webui_mods.switch.if_set    = {}
webui_mods.switch.port      = require("webui_mods.switch.port")


function webui_mods.switch.if_set.as_port_iter(if_set)
    local if_id_array       = if_set.get_set_as_array()
    local port_id
    local port_map          = {}
    local port_id_array     = {}
    local ipairs_f, ipairs_s, ipairs_i

    -- Filter out non-port interfaces,
    -- building port id -> port node map
    for i, if_id in ipairs(if_id_array) do
        local port = if_set[if_id].lower.aka(_("port"))

        -- If port exists and is applicable
        if port.name.exists() and
           webui_mods.switch.port.is_applicable(port) then
            local port_path = port.realpath()

            port_id = port_path:match("^/if/table/(%d+)$")
            if port_id == nil then
                error(_("invalid port path \"%s\""):format(port_path))
            end
            -- We need to reference the ports through the interfaces in
            -- order to correctly show the context in the error messages
            port_map[port_id] = port
        end
    end

    -- Fill in port ID array
    for port_id, port in pairs(port_map) do
        table.insert(port_id_array, port_id)
    end

    -- Sort by port weight
    table.sort(port_id_array,
               function (a, b)
                    local ap = port_map[a]
                    local bp = port_map[b]
                    local aw = webui_mods.switch.port.get_weight(ap) or
                               2147483647 -- INT32_MAX
                    local bw = webui_mods.switch.port.get_weight(bp) or
                               2147483647 -- INT32_MAX

                    return (aw < bw)
               end)

    -- Convert to iterator
    ipairs_f, ipairs_s, ipairs_i = ipairs(port_id_array)
    return function ()
        ipairs_i, port_id = ipairs_f(ipairs_s, ipairs_i)

        if port_id ~= nil then
            return port_id, port_map[port_id]
        end
    end
end


return webui_mods.switch.if_set
