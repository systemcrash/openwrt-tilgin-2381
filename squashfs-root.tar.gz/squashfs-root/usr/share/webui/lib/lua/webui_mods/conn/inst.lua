---
-- WebUI module library - connection instance
-- @release $Id: inst.lua 140714 2009-11-25 08:30:52Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local conn_type         = require("webui_mods.conn.type")
local webui_mods        = {}
webui_mods.conn         = {}
webui_mods.conn.inst    = {}


function webui_mods.conn.inst.ppool_memb(h, c)
    local id, node
    local conn_path         = c.get_path()
    local prio_name_node
    local memb_list         = h.ppool.create()
    local ppool_list        = c.get_root().connection.fallback.ppool.
                                    iaka(_("prioritized fallback pool #%s"))
    local ppool
    local ppool_name
    local ppool_conn_path
    local memb_node

    for id, node in
        c.pfpool.aka(_("prioritized fallback pool set")).
                 iaka(_("pool #%s membership priority")).as_iter() do

        prio_name_node = node.name.aka("name");
        if prio_name_node.exists() then
            ppool = ppool_list[id]
            ppool_name = ppool.name.aka(_("name")).get_string()

            memb_node = memb_list[ppool_name].create()
            memb_node.priority = prio_name_node.get_string()

            ppool_conn_path = ppool.current.
                                aka(_("current connection path")).get_link()
            memb_node.current = (ppool_conn_path == conn_path)
        end
    end
end


function webui_mods.conn.inst.smmr(h, c)
    local ok, e
    local status_layer
    local c_addr
    local addr

    h.name          = c.name.aka(_("name")).get_string()
    h.type          = c.type.name.aka(_("type")).get_string()
    h.description   = c.description.aka(_("description")).get_string()
    h.uptime        = c.uptime.aka(_("uptime")).as_string()
    h.status        = c.status.name.aka(_("operating status")).get_string()
    h.admin         = c.admin.aka(_("administrative status")).get_boolean()
    h.base, h.level = conn_type.range(c.type)

    status_layer = c.status_layer.type.name.aka(_("operating status layer"))
    if status_layer.exists() then
        h.status_layer = status_layer.get_string()
    end

    c_addr = c.ip.addr.aka(_("IP address"))
    if c_addr.exists() then
        addr = c_addr.get()
        if addr:get_type() ~= crm.value_type.INVALID then
            h.ip.addr = addr:get_octets_as_ip_addr()
        end
    end

    webui_mods.conn.inst.ppool_memb(h, c)
end


return webui_mods.conn.inst
