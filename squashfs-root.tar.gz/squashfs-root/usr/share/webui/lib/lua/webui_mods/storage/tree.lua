---
-- WebUI module library - storage tree.
-- @release $Id: $
--

local crm                       = require("webui.crm")
local webui_mods                = {}
webui_mods.storage              = {}
webui_mods.storage.tree         = {}


function webui_mods.storage.tree.get_path(hdf)
    local unit_id, unit
    local dir_id, dir

    for unit_id, unit in hdf.unit.iter() do
        for dir_id, dir in unit.dir.iter() do
            if dir.as_boolean() then
                return "/storage/unit/" .. unit_id ..
                       "/fs/dir/table/" .. dir_id
            end
        end
    end

    return ""
end


function webui_mods.storage.tree.smmr(hdf, mit)
    local h_unit_list, unit_id, c_unit, h_unit
    local h_dir_list, dir_id, c_dir, h_dir

    h_unit_list = hdf.unit.create()
    for unit_id, c_unit in mit.storage.unit.aka(_("storage unit set")).
                                            iaka(_("storage unit #%s")).
                                            as_iter() do
        h_unit = h_unit_list[unit_id].create()
        h_unit.name = c_unit.name.get_string()
        h_unit.manage_dirs = c_unit.fs.manage_dirs.get_boolean()
        h_unit.active = c_unit.fs.mount_oper.get_boolean()
        h_dir_list = h_unit.dir.create()
        
        for dir_id, c_dir in c_unit.fs.dir.table.
                                aka(_("folder set")).
                                iaka(_("folder #%s")).as_iter() do
            h_dir = h_dir_list[dir_id].create()
            h_dir.name = c_dir.name.aka(_("name")).get_string()
        end
    end
end


function webui_mods.storage.tree.slct(hdf, path)
    local unit_id, dir_id

    if path:len() == 0 then
        return
    end

    unit_id, dir_id = path:match("^/storage/unit/([^/]+)/fs/dir/table/([^/]+)")

    if unit_id and dir_id then
        hdf.unit[unit_id].dir[dir_id] = true
    else
        error(string.format(_("invalid storage folder path \"%s\""), path))
    end
end

return webui_mods.storage.tree
