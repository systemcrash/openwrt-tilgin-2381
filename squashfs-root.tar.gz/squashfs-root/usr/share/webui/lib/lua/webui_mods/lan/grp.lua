---
-- WebUI module library - LAN group
-- @release $Id: grp.lua 177591 2016-01-15 14:11:56Z piotr.lavrov $
--


local crm           = require("webui.crm")
local webui_mods    = {}
webui_mods.lan      = {}
webui_mods.lan.grp  = {}


function webui_mods.lan.grp.smmr(h, c)
    h.name = c.name.aka(_("name")).get_string()
end

--~ Convert generic octets presentatin to IPv6 address presentation
--~
--~ @param  str   string with hexadecimal presentation of bytes separated by
--~               white spaces
--~
--~ @return res   String in canonical IPv6 address format

function webui_mods.lan.grp.convert_unknown_to_ipv6(str)
  local i = 0
  local res = ""
  local len = string.len(str)
  local end_symbol_pos = (len + 1) / 3
  for token in string.gmatch(str, "[^%s]+") do
    i = i + 1
    res = res .. token
    if i % 2 == 0 and i ~= end_symbol_pos then
      res = res .. ":"
    end
  end
  return res
end

local function fetch_client(h, c)
    local c_sched_list = c.hg_schedule.aka(_("schedule set")).table
    local h_sched_list = h.sched.create()
    local ipv6_list    = c.ipv6.aka("IPv6 address set")

    h.type      = c.type.name.aka("type").get_string()
    h.media     = c.media.name.aka("media").get_string()
    h.hostname  = c.hostname.aka("hostname").get_string()
    h.ip        = c.ip.aka("IP address").get_octets_as_ip_addr()
    h.mac       = c.mac.aka("MAC address").get_octets_as_mac_addr()
    h.duid      = c.duid.aka("DUID").get_octets_as_string()
    h.static    = c.static.aka("\"static\" flag").get_boolean()
    h.active    = c.active.aka("\"active\" flag").get_boolean()
    h.in_use    = c.in_use.aka("\"in use\" flag").get_boolean()

    for ipv6 in ipv6_list.as_iter() do
        h.ipv6 = webui_mods.lan.grp.convert_unknown_to_ipv6(ipv6)
        break
    end

    for sid, snode in c_sched_list.as_iter() do
        local daymask, daynum
        local hour_start, hour_end, min_start, min_end


        hour_start    = snode.hour_start.aka(_("start hour")).get_u8()
        hour_end      = snode.hour_end.aka(_("end hour")).get_u8()
        min_start     = snode.min_start.aka(_("start minute")).get_u8()
        min_end       = snode.min_end.aka(_("end minute")).get_u8()
        daymask       = snode.daymask.aka(_("daymask")).get_u8()

        h_sched_list[sid].create()
        h_sched_list[sid].hour_start    = string.format("%02d", hour_start)
        h_sched_list[sid].hour_end      = string.format("%02d", hour_end)
        h_sched_list[sid].min_start     = string.format("%02d", min_start)
        h_sched_list[sid].min_end       = string.format("%02d", min_end)

        h_sched_list[sid].day.create()
        for daynum = 1,7,1 do
            h_sched_list[sid].day[daynum] = daymask % 2
            daymask = daymask / 2
        end
    end
end

function webui_mods.lan.grp.fetch_client_list(h, c)
    local c_list = c.lan_client.aka(_("client set")).iaka(_("client #%s"))
    local h_list = h.client.create()

    for client_id, c_client in c_list.as_iter() do
        fetch_client(h_list[client_id].create(), c_client)
    end
end


local function add_client(c, h_client)
    local h_hostname    = h_client.hostname.aka(_("hostname"))
    local hostname
    local h_ip          = h_client.ip.aka(_("IP address"))
    local ip
    local h_mac         = h_client.mac.aka(_("MAC address"))
    local mac

    if h_hostname.is_blank() and h_ip.is_blank() and h_mac.is_blank then
        return
    end

    hostname = crm.value.string(h_hostname.get())
    ip = h_ip.is_blank() and crm.value.octets_from_array{0, 0, 0, 0}
                          or h_ip.as_crm_ip_addr()
    mac = h_mac.is_blank() and crm.value.octets_from_array{0, 0, 0, 0, 0, 0}
                            or h_mac.as_crm_mac_addr()

    c.add_lan_client.aka(_("reserve new client")).
                     exec{hostname = hostname, ip = ip, mac = mac}
end

function webui_mods.lan.grp.apply_client_list(c, h)
    local c_list = c.lan_client.aka(_("client set")).iaka(_("client #%s"))
    local h_list = h.client.iaka("client #%s")

    for client_id, h_client in h_list.iter() do
        local c_client = c_list[client_id]

        if c_client.static.aka(_("\"static\" flag")).get_boolean() then
            if not h_client.static.as_boolean() then
                c.del_lan_client.aka("free").
                                 exec({index = crm.value.u32(client_id)})
            end
        else
            if h_client.static.as_boolean() then
                c.add_lan_client.
                    aka(_("reserve client #%s"):format(client_id)).
                    exec{
                     hostname = c_client.hostname.aka(_("hostname")).get(),
                     ip       = c_client.ip.aka(_("IP address")).get(),
                     mac      = c_client.mac.aka(_("MAC address")).get()}
            end
        end
    end

    add_client(c, h.new_client.aka(_("new client")))
end


return webui_mods.lan.grp


