---
-- WebUI module library - connection and fallback pool selection
-- @release $Id:$
--

local crm               = require("webui.crm")
local conn_type         = require("webui_mods.conn.type")
local webui_mods        = {}
webui_mods.conn         = {}
webui_mods.conn.tree    = require("webui_mods.conn.tree")
webui_mods.conn.fppool  = require("webui_mods.conn.fppool")
webui_mods.conn.slct    = {}


function webui_mods.conn.slct.id(hdf, path, mit)
    local ppool_id

    if not path or path:len() == 0 then
        return
    end

    ppool_id = path:match("^/connection/fallback/ppool/([^/]+)/current")
    if ppool_id then
        hdf.conn_type = "ppool"
        webui_mods.conn.fppool.slct_id(hdf, ppool_id, mit)
    else
        webui_mods.conn.tree.slct_path(hdf, path)
        hdf.conn_type = "dev"
    end
end


function webui_mods.conn.slct.get_path(hdf)
    local conn_type = hdf.conn_type.get()

    if conn_type == "ppool" then
        return webui_mods.conn.fppool.get_path(hdf)
    elseif conn_type == "dev" then   
        return webui_mods.conn.tree.get_path(hdf)
    end

    return ""
end

return webui_mods.conn.slct
