---
-- WebUI module library - packet filter entry
-- @release $Id: key.lua 139693 2009-10-26 11:09:08Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local webui_mods        = {}
webui_mods.pf           = {}
webui_mods.pf.filter    = {}
webui_mods.pf.key_set   = require("webui_mods.pf.key_set")
webui_mods.pf.action    = require("webui_mods.pf.action")


function webui_mods.pf.filter.get_action_type(c)
    local c_action_type = c.action_type.aka(_("action type"))
    local long_type = c_action_type.get_string()
    local short_type = long_type:match("^packet_filter_action_(.*)$")

    if not short_type then
        error(crm.err.Node(c_action_type,
                           _("%%s: unknown action type \"%s\""):
                            format(long_type)))
    end

    return short_type
end


function webui_mods.pf.filter.set_action_type(c, short_type)
    local long_type = "packet_filter_action_" .. short_type

    c.set_action.aka(_("set action type")).
        exec({type = crm.value.string(long_type)})
end


function webui_mods.pf.filter.match(c, key_type_list, action_type_map)
    -- Check if the filter has a creator
    if c.has_creator() then
        return false
    end

    -- Check if the filter has any unsupported keys
    if key_type_list then
        local used_key_type_map
        local used_key_type

        used_key_type_map = c.key.aka(_("key set")).get_set_as_map()
        for used_key_type in pairs(used_key_type_map) do
            local found = false
            for i, key_type in ipairs(key_type_list) do
                if key_type == used_key_type then
                    found = true
                    break
                end
            end
            if not found then
                return false
            end
        end
    end

    -- Check if the filter has an unsupported action
    if action_type_map and
       not action_type_map[webui_mods.pf.filter.get_action_type(c)] then
        return false
    end

    return true
end


function webui_mods.pf.filter.apply(c, h, key_type_list, extra_fn)
    c.label.aka(_("label")).set_string(h.label.aka(_("label")).get())
    if h.key.as_boolean() then
        webui_mods.pf.key_set.apply(c, h, key_type_list)
    end

    webui_mods.pf.action.apply(
        webui_mods.pf.filter.get_action_type(c),
        c.action.aka(_("action")),
        h.action.aka(_("action")))

    if extra_fn then
        extra_fn(c, h)
    end

    c.admin.aka(_("administrative status")).
        set_boolean(h.admin.as_boolean())
end


function webui_mods.pf.filter.fetch(h, c, key_type_list, extra_fn)
    h.label = c.label.aka(_("label")).get_string()
    h.oper  = c.oper.aka(_("operating status")).get_boolean()
    h.admin = c.admin.aka(_("administrative status")).get_boolean()

    webui_mods.pf.key_set.fetch(h, c, key_type_list)

    webui_mods.pf.action.fetch(
        webui_mods.pf.filter.get_action_type(c),
        h.action, c.action.aka(_("action")))

    if extra_fn then
        extra_fn(h, c)
    end
end


function webui_mods.pf.filter.init(c, label, action_type)
    c.label.aka(_("label")).set_string(label)
    webui_mods.pf.filter.set_action_type(c, action_type)
end


return webui_mods.pf.filter
