---
-- WebUI module library - connection type
-- @release $Id: type.lua 157044 2011-08-31 15:35:14Z marina.maslova $
--

local oo                = require("loop.simple")
local crm               = require("webui.crm")
local webui_mods        = {}
webui_mods.conn         = {}
webui_mods.conn.type    = {}


function webui_mods.conn.type.range(t)
    local base  = 3 -- Based on 3rd level by default
    local roof  = 2 -- Tops at 2nd level by default
    local name

    for name in t.layer.as_iter() do
        if name:sub(1, 2) == "ip" then
            roof = 3
        elseif name == "eth_if" then
            base = 2
        end
    end

    return base, roof
end


return webui_mods.conn.type
