---
-- WebUI module library - switch filter set
-- @release $Id: flow.lua 139693 2009-10-26 11:09:08Z nikolai.kondrashov $
--

local crm                       = require("webui.crm")
local webui_mods                = {}
webui_mods.pf                   = {}
webui_mods.pf.filter_set        = require("webui_mods.pf.filter_set")
webui_mods.switch               = {}
webui_mods.switch.filter        = require("webui_mods.switch.filter")
webui_mods.switch.filter_set    = {}


function webui_mods.switch.filter_set.apply(c, h)
    webui_mods.pf.filter_set.apply(
        c, h,
        {
            action_type_map = webui_mods.switch.filter.action_type_map,
            key_type_list = webui_mods.switch.filter.key_type_list
        })
end


function webui_mods.switch.filter_set.fetch(h, c)
    webui_mods.pf.filter_set.fetch(
        h, c,
        {
            action_type_map = webui_mods.switch.filter.action_type_map,
            key_type_list = webui_mods.switch.filter.key_type_list
        })
end


function webui_mods.switch.filter_set.add(c, name)
    local index

    index = c.add.aka(_("create")).exec({}, {"index"}):as_string()
    webui_mods.switch.filter.init(c.table[index].aka(_("new filter")), name)

    return index
end


function webui_mods.switch.filter_set.add(c, label)
    return webui_mods.pf.filter_set.add(c, label, "drop")
end


return webui_mods.switch.filter_set

