---
-- WebUI module library - QoS flow
-- @release $Id: flow.lua 139693 2009-10-26 11:09:08Z nikolai.kondrashov $
--

local crm                   = require("webui.crm")
local webui_mods            = {}
webui_mods.pf               = {}
webui_mods.pf.filter_set    = require("webui_mods.pf.filter_set")
webui_mods.qos              = {}
webui_mods.qos.flow         = require("webui_mods.qos.flow")
webui_mods.qos.flow_set     = {}


function webui_mods.qos.flow_set.apply(c, h)
    webui_mods.pf.filter_set.apply(
        c, h,
        {
            action_type_map = webui_mods.qos.flow.action_type_map,
            key_type_list = webui_mods.qos.flow.key_type_list,
            extra_apply_fn = webui_mods.qos.flow.extra_apply
        })
end


function webui_mods.qos.flow_set.fetch(h, c)
    local flow_id, c_flow, h_flow, prev_h_flow

    -- Fetch
    webui_mods.pf.filter_set.fetch(
        h, c,
        {
            action_type_map = webui_mods.qos.flow.action_type_map,
            key_type_list = webui_mods.qos.flow.key_type_list,
            extra_fetch_fn = webui_mods.qos.flow.extra_fetch
        })

    -- Sort
    h.list.sort(function (a, b)
                        local a_ordinal = a.ordinal.as_number()
                        local b_ordinal = b.ordinal.as_number()

                        return (a_ordinal > b_ordinal)
                                    and 1
                                    or (a_ordinal < b_ordinal)
                                        and -1
                                        or 0
                     end)

    -- Link ordinals
    for flow_id, h_flow in h.list.iter() do
        if prev_h_flow then
            prev_h_flow.next_ordinal = h_flow.ordinal.as_number()
            h_flow.prev_ordinal = prev_h_flow.ordinal.as_number()
        end
        prev_h_flow = h_flow
    end
end


function webui_mods.qos.flow_set.add(c, label)
    return webui_mods.pf.filter_set.add(c, label, "cs")
end


return webui_mods.qos.flow_set
