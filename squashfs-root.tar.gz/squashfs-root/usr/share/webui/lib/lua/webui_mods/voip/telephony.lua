---
-- Helper functions for the Telephony management.
-- @release $Id: telephony.lua 170235 2014-11-28 07:27:44Z marina.maslova $
--

local tel = {}

tel.dect_registred_limit = 5

tel.dect_calls = "Calls_from_Phone_DECT_"
tel.dect_internal = "Internal_Number_Phone_DECT_"
tel.dect_in_call = "Phone_DECT_"

tel.fxs_calls = "Calls_from_Phone_"
tel.fxs_name = "Display_Name_Phone_"
tel.fxs_internal = "Internal_Number_Phone_"
tel.fxs_in_call = "Phone_"
tel.fxs_enable = "Enable_Phone_"

--~ Index mapping /dect/gs/X -> /recon/pm/table/Calls_from_Phone_DECT_Y:
--~ Y = X - 1
function map_dect_idx(idx)
    return idx - 1
end

--~ Get FXS number
--~ @param mit  CRM mit
--~ 
--~ @return FXS number
function fxs_num(mit)
    return tonumber(mit.pm.factory.fxs_ports.get():tostring()) - 1
end

--~ Try to get account param value.
--~ @param mit      CRM mit
--~ @param dect     @c true if the param is needed for dect and
--~                 @c false for FXS
--~ @param index    Device index
--~ @param param    String with parameter name
--~ 
--~ @return res, val, accoun
--~         res:     @c true on success
--~         val:     parameter value
--~         account: account name
function tel_try_get_account_param(mit, dect, index, param)
    local idx
    local res = false
    local val = nil
    local account = nil
    local calls

    if dect then
        idx = map_dect_idx(index)
        calls = tel.dect_calls
    else
        idx = index
        calls = tel.fxs_calls
    end

    if mit.recon.pm.table[calls .. idx].exists() then
        account = mit.recon.pm.table[calls .. idx].get():tostring()

        res, val  = pcall(mit.voip.account[account].param[param].get)
        if res then
            val = val:as_string()
        end
    end

    return res, val, account
end

--~ Wrapper function to get account param value for FXS, see
--~ tel_try_get_account_param() for details.
function fxs_try_get_account_param(mit, dect_index, param)
    return tel_try_get_account_param(mit, false, dect_index, param)
end

--~ Wrapper function to get account param value for DECT, see
--~ tel_try_get_account_param() for details.
function dect_try_get_account_param(mit, dect_index, param)
    return tel_try_get_account_param(mit, true, dect_index, param)
end

--~ Try to set account param value.
--~ @param mit      CRM mit
--~ @param dect     @c true if the param is set for dect and
--~                 @c false for FXS
--~ @param index    Device index
--~ @param param    String with parameter name
--~ @param value    Value to be set
--~ 
--~ @return res, val, accoun
--~         res:     @c true on success
--~         val:     Previous parameter value
--~         account: account name
function tel_try_set_account_param(mit, dect, index, param, value)
    local idx
    local res = false
    local val = nil
    local account

    if dect then
        idx = map_dect_idx(index)
    else
        idx = index
    end

    res, val, account = tel_try_get_account_param(mit, dect, index, param)
    if res then
        mit.voip.account[account].param[param].set_string(value)
    else
        error("Bad account")
    end

    return res, val, account
end

--~ Set account param value for each account which associated
--~ with given phone for incoming calls.
--~ @param mit      CRM mit
--~ @param dect     @c true if the param is set for dect and
--~                 @c false for FXS
--~ @param index    Device index
--~ @param param    String with parameter name
--~ @param value    Value to be set
--~ 
function tel_set_account_param_in(mit, dect, idx, param, value)
    local acc, acc_idx
    local phone

    if dect then
        phone = tel.dect_in_call .. map_dect_idx(idx)
    else
        phone = tel.fxs_in_call .. idx
    end

    for acc_idx, acc in mit.voip.account.as_iter() do
        local phone_list = acc.param.Calls_from.get_set_as_map()
        if phone_list[phone] then
            acc.param[param].set_string(value)
        end
    end
end

--~ Get account param value for first account which associated
--~ with given phone for incoming calls.
--~ @param mit      CRM mit
--~ @param dect     @c true if the param is set for dect and
--~                 @c false for FXS
--~ @param index    Device index
--~ @param param    String with parameter name
--~
--~ @return val      parameter value or nil
--~
function tel_get_account_param_in(mit, dect, idx, param)
    local acc, acc_idx
    local phone

    if dect then
        phone = tel.dect_in_call .. map_dect_idx(idx)
    else
        phone = tel.fxs_in_call .. idx
    end

    for acc_idx, acc in mit.voip.account.as_iter() do
        local phone_list = acc.param.Calls_from.get_set_as_map()
        if phone_list[phone] then
            return acc.param[param].get_string()
        end
    end
    return nil
end

--~ Wrapper function to set account param value for DECT, see
--~ tel_try_set_account_param() for details.
function dect_try_set_account_param(mit, dect_index, param, value)
    return tel_try_set_account_param(mit, true, dect_index, param, value)
end

--~ Wrapper function to set account param value for FXS, see
--~ tel_try_set_account_param() for details.
function fxs_try_set_account_param(mit, dect_index, param, value)
    return tel_try_set_account_param(mit, false, dect_index, param, value)
end

--~ Retrieve DECT list.
--~ @param mit          CRM mit
--~ @param dect_phones  Form item to get DECT list
--~ @param param        Account parameter to be obtained for each DECT, can
--~                     be @c nil to get @c PhoneNumber
--~ 
--~ DECTs number
function retrieve_dects(mit, dect_phones, param)
    local dev
    local mdev
    local account
    local num
    local idx
    local res
    local val
    local field
    local count = 0

    if param == nil then
        param = "PhoneNumber"
        field = "phone_num"
    else
        field = param
    end

    for idx in mit.dect.hs.as_iter() do
        count = count + 1
        dev = dect_phones[idx].create()
        dev.name = mit.dect.hs[idx].name.get_string()
        dev.idx = idx

        num = map_dect_idx(idx)
        dev.in_call = tel.dect_in_call .. num
        if mit.recon.pm.table[tel.dect_internal .. num].exists() then
            dev.internal_num = mit.recon.pm.table[tel.dect_internal .. num].get_string()
        end

        if param ~= "BusyCallWait" then
            res, val, account = dect_try_get_account_param(mit, idx, param)
        else
            local cwp = "CW_" .. tel.dect_in_call .. num
            if mit.recon.pm.table[cwp].exists() then
                val = mit.recon.pm.table[cwp].get_string()
            else
                val = 0
            end
            res = true
            account = ""
        end

        if res then
            dev[field] = tostring(val)
            dev.account = account
        else
            dev[field] = ""
            dev.account = ""
        end
    end

    return count
end

--~ Retrieve FXS list.
--~ @param mit          CRM mit
--~ @param devices      Form item to get FXS list
--~ @param param        Account parameter to be obtained for each FXS, can
--~                     be @c nil to get @c PhoneNumber
function retrieve_phones(mit, devices, param)
    local dev
    local limit = fxs_num(mit)
    local idx
    local str
    local res
    local field

    if param == nil then
        param = "PhoneNumber"
        field = "phone_num"
    else
        field = param
    end

    for idx = 0, limit do
        res, str  = pcall(mit.recon.pm.table[tel.fxs_enable .. idx].get_string)

        if (res and (str == "1")) or not res then
            dev = devices[idx].create()
            dev.name = mit.recon.pm.table[tel.fxs_name .. idx].get_string()
            dev.internal_num = mit.recon.pm.table[tel.fxs_internal .. idx].get_string()
            dev.idx = idx

            dev.account = mit.recon.pm.table[tel.fxs_calls .. idx].get():tostring()
            dev.in_call = tel.fxs_in_call .. idx

            if param ~= "BusyCallWait" then
                res, str  = pcall(mit.voip.account[dev.account].param[param].get_string)
            else
                local cwp = "CW_" .. tel.fxs_in_call .. idx

                res, str  = pcall(mit.recon.pm.table[cwp].get_string)
            end

            if res then
                dev[field] = str
            end
        end
    end
end

return tel
