---
-- WebUI module library - packet action
-- @release $Id: key.lua 139693 2009-10-26 11:09:08Z nikolai.kondrashov $
--

local crm                   = require("webui.crm")
local webui_mods            = {}
webui_mods.pf               = {}
webui_mods.pf.action        = {}
webui_mods.pf.action.type   = {}

local action_type = webui_mods.pf.action.type

--
-- "reject" action
--
action_type.reject = {}
action_type.reject.title = _("reject")

function action_type.reject.apply(c, h)
    c.icmp_type.aka(_("ICMP type")).set_string(h.icmp_type.get())
end

function action_type.reject.fetch(h, c)
    h.icmp_type = c.icmp_type.name.aka(_("ICMP type")).get_string()
end

--
-- "drop" action
--
action_type.drop = {}
action_type.drop.title = _("drop")

--
-- "cs" action
--
action_type.cs = {}
action_type.cs.title = _("classify")

function action_type.cs.apply(c, h)
    local dscp, ether_prio

    if h.dscp.is_blank() then
        dscp = -1
    else
        dscp = h.dscp.aka(_("DSCP")).req_range(0, 63).as_number()
    end

    if h.ether_prio.is_blank() then
        ether_prio = -1
    else
        ether_prio = h.ether_prio.aka(_("Ethernet priority")).
                        req_range(0, 7).as_number()
    end

    c.dscp.aka(_("DSCP")).set_s8(dscp)
    c.ether_prio.aka(_("Ethernet priority")).set_s8(ether_prio)
    c.prio.aka(_("internal priority")).
        set_u8(h.prio.aka(_("internal priority")).req_range(0, 7))
end


function action_type.cs.fetch(h, c)
    local dscp, ether_prio

    dscp = c.dscp.aka(_("DSCP")).as_number()
    ether_prio = c.ether_prio.aka(_("Ethernet priority")).as_number()

    h.dscp = (dscp >= 0) and dscp or ""
    h.ether_prio = (ether_prio >= 0) and ether_prio or ""
    h.prio = c.prio.aka(_("internal priority")).as_string()
end


--
-- Retrieve action type descriptor.
--
function webui_mods.pf.action.get_desc(t)
    local d = action_type[t]

    if not d then
        error(_("unknown type \"%s\""):format(t))
    end

    return d
end


--
-- "apply" muxer
--
function webui_mods.pf.action.apply(t, c, h)
    local d = webui_mods.pf.action.get_desc(t)

    if d.apply then
        d.apply(c, h)
    end
end


--
-- "fetch" muxer
--
function webui_mods.pf.action.fetch(t, h, c)
    local d = webui_mods.pf.action.get_desc(t)

    h.type = t
    h.title = d.title

    if d.fetch then
        d.fetch(h, c)
    end
end


return webui_mods.pf.action
