---
-- WebUI module library - connection device
-- @release $Id: dev.lua 140725 2009-11-25 11:10:38Z nikolai.kondrashov $
--


local crm           = require("webui.crm")
local webui_mods    = {}
webui_mods.conn     = {}
webui_mods.conn.dev = {}

local base_type_list    = {"eth_port", "atm_port"}

function webui_mods.conn.dev.base_type(dev)
    return dev.link.prop.conn_stack.stack.name.get_string()
end


function webui_mods.conn.dev.smmr(h, c)
    local if_path
    local if_id

    h.type = webui_mods.conn.dev.base_type(c)
    h.name = c.link.name.aka(_("name")).get_string()
    if_path = c.link.aka(_("interface")).realpath()
    if_id = if_path:match("^/if/table/([^/]+)")
    if if_id == nil then
        error(string.format(_("invalid interface path \"%s\""), if_path))
    end
    h["if"] = if_id
end


return webui_mods.conn.dev
