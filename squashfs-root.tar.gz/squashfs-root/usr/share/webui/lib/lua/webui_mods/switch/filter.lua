---
-- WebUI module library - switch filter
-- @release $Id: flow.lua 139693 2009-10-26 11:09:08Z nikolai.kondrashov $
--

local crm                   = require("webui.crm")
local webui_mods            = {}
webui_mods.switch           = {}
webui_mods.switch.filter    = {}
webui_mods.pf               = {}
webui_mods.pf.filter        = require("webui_mods.pf.filter")


webui_mods.switch.filter.key_type_list = {
    "ether_type",
    "ip_tos",
    "ip_proto",
    "src_port",
    "dst_port",
}

webui_mods.switch.filter.action_type_map = {
    drop = true
}


function webui_mods.switch.filter.match(c)
    return webui_mods.pf.filter.match(
            c,
            webui_mods.switch.filter.key_type_list,
            webui_mods.switch.filter.action_type_map)
end


function webui_mods.switch.filter.apply(c, h)
    webui_mods.pf.filter.apply(c, h, webui_mods.switch.filter.key_type_list)
end


function webui_mods.switch.filter.fetch(h, c)
    webui_mods.pf.filter.fetch(h, c, webui_mods.switch.filter.key_type_list)
end


function webui_mods.switch.filter.init(c, label)
    webui_mods.pf.filter.init(c, label, "drop")
end


return webui_mods.switch.filter

