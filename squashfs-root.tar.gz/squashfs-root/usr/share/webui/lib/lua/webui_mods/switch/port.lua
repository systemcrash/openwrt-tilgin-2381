---
-- WebUI module library - Switch port
-- @release $Id: port.lua 140714 2009-11-25 08:30:52Z nikolai.kondrashov $
--


local webui_mods        = {}
webui_mods.switch       = {}
webui_mods.switch.port  = {}


function webui_mods.switch.port.get_weight(c_port)
    local mit       = c_port.get_root()
    local name      = c_port.name.aka(_("name")).get_string()
    local weight    = mit.pm.factory.webui.port_order[name]

    return weight.exists() and tonumber(weight.get_string()) or nil
end


function webui_mods.switch.port.is_applicable(c_port)
    local t         = c_port.get_transaction()
    local port_type = c_port.type.aka(_("type")).get_string()

    return t:subtypeof(port_type, "eth_port")
end


return webui_mods.switch.port
