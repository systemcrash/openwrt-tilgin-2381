---
-- WebUI module library - connection fallback pool
-- @release $Id:$
--

local crm               = require("webui.crm")
local conn_type         = require("webui_mods.conn.type")
local webui_mods        = {}
webui_mods.conn         = {}
webui_mods.conn.fppool  = {}

function webui_mods.conn.fppool.parse_path(path)
    return path:match("^/connection/fallback/ppool/([^/]+)/current")
end

function webui_mods.conn.fppool.list(h, mit)
    local id, node
    local prio_name_node
    local hppool_list        = h.ppool.create()
    local cppool_list        = mit.connection.fallback.ppool.
                                aka(_("prioritized fallback pool #%s"))
    local ppool_name
    local memb_node

    for id, node in
        cppool_list.aka(_("prioritized fallback pool set")).as_iter() do

        prio_name_node = node.name.aka("name");
        if prio_name_node.exists() then
            ppool_name = prio_name_node.get_string()
            hppool_list[ppool_name].create()
        end
    end
end

function webui_mods.conn.fppool.slct_id(hdf, id, mit)
    local name = mit.connection.fallback.ppool[id].name

    if not name.exists() then
        return
    end

    name = name.get_string()
    hdf.ppool[name] = true
end

function webui_mods.conn.fppool.get_path(hdf)
    local ppool_name, ppool

    for ppool_name, ppool in hdf.ppool.iter() do
        if ppool.as_boolean() then
            return "/connection/fallback/ppool/" .. ppool_name .. "/current"
        end
    end

    return ""
end

return webui_mods.conn.fppool
