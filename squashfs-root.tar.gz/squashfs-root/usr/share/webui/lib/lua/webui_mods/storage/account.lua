---
-- WebUI module library - auxiliary software routines.
-- @release $Id: account.lua 134345 2009-06-04 10:15:44Z nikolai.kondrashov $
--

local webui_mods                = {}
webui_mods.storage              = {}
webui_mods.storage.account      = {}
webui_mods.storage.account.req  = {}


function webui_mods.storage.account.req.name(node)
    return node.req_regex(
            _("a string containing only latin letters, numbers, " ..
              "underscores, hyphens or national characters"),
            "^[a-zA-Z0-9\128-\255_-]*$")
end

function webui_mods.storage.account.req.password(node)
    return node.req_regex(
            _("a string containing only standard, " ..
              "printable ASCII characters"),
            "^[\32-\126]*$")
end

return webui_mods.storage.account
