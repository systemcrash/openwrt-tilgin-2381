---
-- WebUI module library - connection tree
-- @release $Id: tree.lua 140706 2009-11-24 17:03:11Z nikolai.kondrashov $
--


local crm               = require("webui.crm")
local webui_mods        = {}
webui_mods.conn         = {}
webui_mods.conn.tree    = {}
webui_mods.conn.dev     = require("webui_mods.conn.dev")
webui_mods.conn.inst    = require("webui_mods.conn.inst")


function webui_mods.conn.tree.path_valid(path)
    return path:match("^/connection/device/table/[^/]+" ..
                      "/configured/[^/]+") ~= nil
end


function webui_mods.conn.tree.smmr(hdf, mit)
    local h_dev_list, dev_id, c_dev, h_dev
    local h_conn_list, conn_id, c_conn, h_conn

    h_dev_list = hdf.dev.create()
    for dev_id, c_dev in mit.connection.device.table.
                            aka(_("device set")).
                            iaka(_("device #%s")).as_iter() do
        h_dev = h_dev_list[dev_id].create()
        webui_mods.conn.dev.smmr(h_dev, c_dev)

        h_conn_list = h_dev.conn.create()
        for conn_id, c_conn in c_dev.configured.
                                aka(_("connection set")).
                                iaka(_("connection #%s")).
                                as_iter_readable() do
            h_conn = h_conn_list[conn_id].create()
            webui_mods.conn.inst.smmr(h_conn, c_conn)
        end
    end
end


function webui_mods.conn.tree.slct_path(hdf, path)
    local dev_id, conn_id

    if path:len() == 0 then
        return
    end

    dev_id, conn_id = path:match("^/connection/device/table/([^/]+)" ..
                                 "/configured/([^/]+)")

    if dev_id and conn_id then
        hdf.dev[dev_id].conn[conn_id] = true
    else
        error(string.format(_("invalid connection path \"%s\""), path))
    end
end


function webui_mods.conn.tree.get_path(hdf)
    local dev_id, dev
    local conn_id, conn

    for dev_id, dev in hdf.dev.iter() do
        for conn_id, conn in dev.conn.iter() do
            if conn.as_boolean() then
                return "/connection/device/table/" .. dev_id ..
                       "/configured/" .. conn_id
            end
        end
    end

    return ""
end


return webui_mods.conn.tree


