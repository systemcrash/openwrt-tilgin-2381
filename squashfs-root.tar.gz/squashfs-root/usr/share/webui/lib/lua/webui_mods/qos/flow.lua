---
-- WebUI module library - QoS flow
-- @release $Id: flow.lua 139865 2009-10-30 11:40:41Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local webui_mods        = {}
webui_mods.qos          = {}
webui_mods.qos.flow     = {}
webui_mods.pf           = {}
webui_mods.pf.filter    = require("webui_mods.pf.filter")


webui_mods.qos.flow.key_type_list = {
    "in",
    "ether_type",
    "ether_prio",
    "src_mac",
    "dst_mac",
    "ip_tos",
    "ip_proto",
    "ip_len",
    "src_ip",
    "dst_ip",
    "src_port",
    "dst_port",
    "tcp_flags"
}

webui_mods.qos.flow.action_type_map = {
    cs = true
}


function webui_mods.qos.flow.match(c)
    return webui_mods.pf.filter.match(c,
                                      webui_mods.qos.flow.key_type_list,
                                      webui_mods.qos.flow.action_type_map)
end


function webui_mods.qos.flow.extra_apply(c, h)
    if h.ordinal.exists() then
        c.ordinal.aka(_("ordinal number")).
            set_u32(h.ordinal.aka(_("ordinal number")).
                            req_range(1, 2147483647)) -- 1-INT32_MAX
    end
end


function webui_mods.qos.flow.apply(c, h)
    webui_mods.pf.filter.apply(c, h,
                               webui_mods.qos.flow.key_type_list,
                               webui_mods.qos.flow.extra_apply)
end


function webui_mods.qos.flow.extra_fetch(h, c)
    h.ordinal  = c.ordinal.as_string()
end


function webui_mods.qos.flow.fetch(h, c)
    webui_mods.pf.filter.fetch(h, c,
                               webui_mods.qos.flow.key_type_list,
                               webui_mods.qos.flow.extra_fetch)
end


function webui_mods.qos.flow.init(c, label)
    webui_mods.pf.filter.init(c, label, "cs")
end


return webui_mods.qos.flow
