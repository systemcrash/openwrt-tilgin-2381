---
-- WebUI module library - interface tree
-- @release $Id: tree.lua 164766 2013-10-30 16:04:20Z elena.vengerova $
--

local webui_mods        = {}
webui_mods.iface        = {}
webui_mods.iface.tree   = {}
webui_mods.conn         = {}
webui_mods.conn.type    = require("webui_mods.conn.type")

local domain = {}

domain.conn = {}
function domain.conn.load(tree, mit)
    local h_dev_list, h_dev
    local h_conn_list, h_conn

    h_dev_list = tree.list.dev.list.create()
    for dev_id, c_dev in mit.connection.device.table.
                            aka(_("device set")).
                            iaka(_("device #%s")).as_iter() do
        h_dev = h_dev_list[dev_id].create()
        h_dev.name = c_dev.link.name.aka(_("name")).get_string()

        h_conn_list = h_dev.list.create()
        for conn_id, c_conn in c_dev.configured.
                                aka(_("connection set")).
                                iaka(_("connection #%s")).
                                as_iter_readable() do
            h_conn = h_conn_list[conn_id].create()

            h_conn.name = c_conn.name.aka(_("name")).get_string()
            h_conn.base, h_conn.roof =
                webui_mods.conn.type.range(c_conn.type)
            h_conn.oper = c_conn.oper.aka(_("operating status")).
                                                        get_boolean()
        end
    end
end


function domain.conn.slct(tree, path)
    local dev_id, conn_id

    -- XXX not exactly robust
    dev_id, conn_id = path:match("^/connection/device/table/([^/]+)" ..
                                 "/configured/([^/]+)/if")

    if dev_id and conn_id then
        tree.list.dev.list[dev_id].list[conn_id] = true
        return true
    else
        return false
    end
end


function domain.conn.path(tree)
    local list = {}

    for dev_id, dev in tree.list.dev.list.iter() do
        for conn_id, conn in dev.list.iter() do
            if conn.as_boolean() then
                table.insert(list,
                             "/connection/device/table/" .. dev_id ..
                             "/configured/" .. conn_id .. "/if")
            end
        end
    end

    return list
end


domain.lan_group = {}
function domain.lan_group.load(tree, mit)
    local h_lan_group_group
    local h_lan_group_list, h_lan_group

    h_lan_group_group = tree.list.lan_group.create()
    h_lan_group_group.name = _("LAN group")
    h_lan_group_list = h_lan_group_group.list.create()
    for lan_group_id, c_lan_group in
            mit.lan.group.aka(_("LAN group set")).
                          iaka(_("LAN group #%s")).
                          as_iter_readable() do
        if c_lan_group.visible() then
            h_lan_group = h_lan_group_list[lan_group_id].create()
            h_lan_group.name = c_lan_group.name.aka(_("name")).get_string()
            h_lan_group.oper = (c_lan_group.ipif.get_link():len() > 0)
            h_lan_group.base = 2
            h_lan_group.roof = c_lan_group.manage_ip.get_boolean() and 3 or 2
        end
    end
end


function domain.lan_group.slct(tree, path)
    -- XXX not exactly robust
    local lan_group_id = path:match("^/lan/group/([^/]+)/ipif")

    if lan_group_id then
        tree.list.lan_group.list[lan_group_id] = true
        return true
    else
        return false
    end
end


function domain.lan_group.path(tree)
    local list = {}

    for lan_group_id, lan_group in tree.list.lan_group.list.iter() do
        if lan_group.as_boolean() then
            table.insert(list, "/lan/group/" .. lan_group_id .. "/ipif")
        end
    end

    return list
end


domain.system = {}
function domain.system.load(tree, mit)
    local h_system_group
    local h_system_list, c_iface_name, h_iface

    h_system_group = tree.list.system.create()
    h_system_group.name = _("System")
    h_system_list = h_system_group.list.create()
    for iface_id, c_iface in
        mit["if"].table.aka(_("interface set")).
                        iaka(_("interface #%s")).as_iter() do
        c_iface_name = c_iface.prop.linux.sys_name.aka(_("system name"))
        if c_iface_name.exists() then
            local t             = c_iface.get_transaction()
            local c_iface_type  = c_iface.type.aka(_("type")).get_string()
            local suitable_type = t:subtypeof(c_iface_type, "net_if") or
                                  t:subtypeof(c_iface_type, "ppp_if")
            local eth_if        = t:subtypeof(c_iface_type, "eth_if")
            local has_ip        = c_iface.prop.ip.exists()
            local iface_name    = c_iface_name.get_string()

            if suitable_type and #iface_name > 0 then
                h_iface = h_system_list[iface_id].create()
                h_iface.name = iface_name
                h_iface.oper = c_iface.oper.get_boolean()
                -- FIXME this is dumb and possibly wrong
                h_iface.base = eth_if and 2 or 3
                h_iface.roof = has_ip and 3 or 2
            end
        end
    end
end


function domain.system.slct(tree, path)
    -- XXX not exactly robust
    local iface_id = path:match("^/if/table/([^/]+)")

    if iface_id then
        tree.list.system.list[iface_id] = true
        return true
    else
        return false
    end
end


function domain.system.path(tree)
    local list = {}

    for iface_id, iface in tree.list.system.list.iter() do
        if iface.as_boolean() then
            table.insert(list, "/if/table/" .. iface_id)
        end
    end

    return list
end


function webui_mods.iface.tree.load(tree, mit, domain_set)
    for domain_name, domain in pairs(domain) do
        if not domain_set or domain_set[domain_name] then
            domain.load(tree, mit)
        end
    end
end


function webui_mods.iface.tree.slct(tree, path, domain_set)
    if #path == 0 then
        return false
    end

    for domain_name, domain in pairs(domain) do
        if not domain_set or domain_set[domain_name] then
            if domain.slct(tree, path) then
                return true
            end
        end
    end

    error(_("invalid interface path \"%s\""):format(path))
end


function webui_mods.iface.tree.path(tree, domain_set)
    local list = {}

    for domain_name, domain in pairs(domain) do
        if not domain_set or domain_set[domain_name] then
            for index, value in ipairs(domain.path(tree)) do
                table.insert(list, value)
            end
        end
    end

    return unpack(list)
end


return webui_mods.iface.tree
