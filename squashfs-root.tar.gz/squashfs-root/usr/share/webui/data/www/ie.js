/**
 * @brief Internet Explorer specific JavaScript code.
 *
 * Copyright (C) 2007-2008 Tilgin AB
 *
 * @author Nikolai Kondrashov <Nikolai.Kondrashov@oktetlabs.ru>
 *
 * @(#) $Id:  $
 */

/*
 * Generate class name for input type.
 */
function ie_input_type_class(type)
{
    return "input-" + type;
}

/*
 * Remove names and values from all buttons on the form, and add hidden
 * input with the name and value of the button that was clicked.
 *
 * This is a little dance around IE quirks and bugs so please be careful
 * trying to "fix" it.
 */
function ie_button_onclick()
{
    var button              = window.event.srcElement;
    if (!button)
        return true;
    /* Seems to be the only way to retrieve the "value" attribute */
    var button_value_node   = button.attributes.getNamedItem("value");
    var button_list         = button.form.getElementsByTagName("BUTTON");
    var hidden_input        = document.createElement("INPUT");

    hidden_input.type = "hidden";
    hidden_input.className = ie_input_type_class(hidden_input.type);
    hidden_input.name = button.name;
    if (button_value_node)
        hidden_input.value = button_value_node.nodeValue;

    for (i = 0; i < button_list.length; i++)
    {
        var value_node;

        button_list[i].removeAttribute("name");

        /*
         * Seems to be the only way to remove the "value" attribute for
         * sure.
         */
        value_node = button_list[i].attributes.getNamedItem("value");
        if (value_node)
            button_list[i].removeAttributeNode(value_node);
    }

    /*
     * This seems to be the place inserting into which doesn't cause layout
     * quirks
     */
    button.form.insertBefore(hidden_input, button.form.firstChild);

    return true;
}


/**
 * Attach button onclick handler.
 */
function ie_fix_attach_onclick(button, orig_onclick, new_onclick)
{
    if (!orig_onclick)
        button.onclick = new_onclick;
    else
        button.onclick = function (e) {
            return new_onclick(e) && orig_onclick(e);
        }
}


/**
 * Fix "submit" button behavior in all document forms.
 */
function ie_fix_form_buttons()
{
    var button_list = document.getElementsByTagName("BUTTON");

    for (var i = 0; i < button_list.length; i++)
    {
        var button = button_list[i];

        if (button.type != "submit")
            continue;

        ie_fix_attach_onclick(button,
                              button.onclick,
                              ie_button_onclick);
    }
}


/**
 * Assign classes for different INPUT types.
 */
function ie_fix_classify_input()
{
    var input_list = document.getElementsByTagName("INPUT");

    for (i = 0; i < input_list.length; i++)
    {
        var input = input_list[i];
        element_add_class(input, ie_input_type_class(input.type));
    }
}


/**
 * Apply all IE fixes
 */
function ie_fix()
{
    ie_fix_form_buttons();
    ie_fix_classify_input();
}


/**
 * Attach fixing routine to the window onload handler
 */
object_attach_handler(window, "load",
                      function () {ie_fix(); return true;},
                      true)


