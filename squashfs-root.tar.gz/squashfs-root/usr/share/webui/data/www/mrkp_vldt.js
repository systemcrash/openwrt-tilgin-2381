/**
 * @brief WebUI template markup validation functions
 *
 * Copyright (C) 2007 Tilgin AB
 *
 * @author Nikolai Kondrashov <Nikolai.Kondrashov@oktetlabs.ru>
 *
 * @(#) $Id: $
 */

/**
 * Validate simple element; in effect an element which should contain some
 * non-whitespace text and no child elements.
 */
function mrkp_vldt_simple_element(e, title, textRequired)
{
    var gotText = false;

    for (var n = e.firstChild; n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Comment */
            case 8:
                break;

            /* Text content */
            case 3:
                if (!n.nodeValue.isblank())
                    gotText = true;
                break;

            /* Element */
            case 1:
                console.error("%s contains markup", title, e);
                break;

            /* Anything else */
            default:
                console.error("Unknown node type %s", n.nodeType, n);
                break;
        }
    }

    if (textRequired && !gotText)
        console.error("%s has no text", title, e);
}


/**
 * Validate compound control fieldset
 */
function mrkp_vldt_control_fieldset(control_fieldset)
{
    var gotAny  = false;

    for (var n = control_fieldset.firstChild;
         n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Comment */
            case 8:
                break;

            /* Text content */
            case 3:
                /* If it has anything except whitespace */
                if (!n.nodeValue.isblank())
                    console.error("Bare text", n);
                break;

            /* Element */
            case 1:
                mrkp_vldt_fieldset_element(n);
                gotAny = true;
                break;

            /* Anything else */
            default:
                console.error("Unknown node type %s", n.nodeType, n);
                break;
        }
    }

    if (!gotAny)
        console.error("Empty");
}


/**
 * Validate control markup.
 */
function mrkp_vldt_control(control)
{
    if (control.tagName != "DL")
        return;

    console.group("Compound control", control);
    for (var n = control.firstChild; n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Element */
            case 1:
                if (n.tagName == "DD")
                {
                    console.group("Compound control fieldset", n);
                    mrkp_vldt_control_fieldset(n);
                    console.groupEnd();
                }

                break;

            /* Anything else */
            default:
                /* Everything other could be checked by generic validator */
                break;
        }
    }
    console.groupEnd();
}


/**
 * Validate label markup.
 */
function mrkp_vldt_label(label)
{
    var content;

    mrkp_vldt_simple_element(label, "Label", false);

    /* Remove leading and trailing space */
    content = label.textContent.replace(/^\s+|\s+$/g, "");

    /* If label is not empty */
    if (content.length > 0)
    {
        if (content.charAt(content.length - 1) != ':')
            console.error("Label", label, "doesn't end with a colon");
        else if (content.length == 1)
            console.error("Empty label text", label);
    }
}


/**
 * Validate helper markup.
 */
function mrkp_vldt_helper(helper)
{
    mrkp_vldt_simple_element(helper, "Helper", true);
}


/**
 * Validate field wrapping LABEL element
 */
function mrkp_vldt_field_wrap_label(wrap_label, label_fn, control_fn)
{
    for (var n = wrap_label.firstChild; n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Comment */
            case 8:
                break;

            /* Text content */
            case 3:
                /* If it has anything except whitespace */
                if (!n.nodeValue.isblank())
                    console.error("Wrapping", wrap_label,
                                  "has bare text", n);
                break;

            /* Element */
            case 1:
                if (element_has_class(n, "label"))
                    label_fn(n);
                else if (element_has_class(n, "control"))
                    control_fn(n);
                else
                    console.error("Unexpected element", n);

                break;

            /* Anything else */
            default:
                console.error("Unknown node type %s", n.nodeType, n);
                break;
        }
    }
}


/**
 * Validate field markup.
 */
function mrkp_vldt_field(field)
{
    var gotLabel        = false;
    var gotControl      = false;
    var gotHelper       = false;
    var gotWrapLabel    = false;

    var label_fn = function(label) {
        if (label.tagName == "SPAN")
        {
            if (gotControl || gotHelper)
                console.error("Misplaced label", label);
            else if (gotLabel)
                console.error("Excessive label", label);

            mrkp_vldt_label(label);
        }
        else
            console.error("Invalid label element", label);

        gotLabel = true;
    }

    var control_fn = function(control) {
        if (gotHelper)
            console.error("Misplaced control", control);
        else if (gotControl)
                console.error("Excessive control", control);

        mrkp_vldt_control(control);

        gotControl = true;
    }

    var helper_fn = function(helper) {
        if (helper.tagName == "SPAN")
        {
            if (gotHelper)
                console.error("Excessive helper", helper);

            mrkp_vldt_helper(helper);
        }
        else
            console.error("Invalid helper element", helper);
        gotHelper = true;
    }

    for (var n = field.firstChild; n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Comment */
            case 8:
                break;

            /* Text content */
            case 3:
                /* If it has anything except whitespace */
                if (!n.nodeValue.isblank())
                    console.error(field, "has bare text", n);
                break;

            /* Element */
            case 1:
                if (element_has_class(n, "label"))
                    label_fn(n);
                else if (element_has_class(n, "control"))
                    control_fn(n);
                else if (element_has_class(n, "helper"))
                    helper_fn(n);
                else if (n.tagName == "LABEL")
                {
                    if (gotLabel || gotControl || gotHelper)
                        console.error("Spurious wrapping LABEL", n);
                    else if (gotWrapLabel)
                        console.error("Excessive wrapping LABEL", n);

                    mrkp_vldt_field_wrap_label(n, label_fn, control_fn);

                    gotWrapLabel = true;
                }
                else
                    console.error("Unexpected element", n);

                break;

            /* Anything else */
            default:
                console.error("Unknown node type %s", n.nodeType, n);
                break;
        }
    }

    if (!gotLabel)
        console.error("Field has no label", field);
    if (!gotControl)
        console.error("Field has no control", field);
}


/**
 * Validate button set markup.
 */
function mrkp_vldt_button_set(button_set)
{
    var gotButton   = false;

    for (var n = button_set.firstChild; n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Comment */
            case 8:
                break;

            /* Text content */
            case 3:
                /* If it has anything except whitespace */
                if (!n.nodeValue.isblank())
                    console.error(button_set, "has bare text", n);
                break;

            /* Element */
            case 1:
                if (n.tagName == "BUTTON")
                    gotButton = true;
                else if (n.tagName != "INPUT" || n.type != "hidden")
                    console.error("Unexpected element", n);

                break;

            /* Anything else */
            default:
                console.error("Unknown node type %s", n.nodeType, n);
                break;
        }
    }

    if (!gotButton)
        /* At least legend must be present */
        console.error("Button set has no buttons", button_set);
}


/**
 * Validate fieldset element markup.
 */
function mrkp_vldt_fieldset_element(e)
{
    if (e.tagName != "DIV")
    {
        console.error("Unexpected element", e);
        return;
    }

    if (element_has_class(e, "field"))
        mrkp_vldt_field(e);
    else if (element_has_class(e, "button-set"))
        mrkp_vldt_button_set(e);
    else
        console.error("Unknown DIV class", e);
}


/**
 * Validate fieldset markup.
 */
function mrkp_vldt_fieldset(fieldset)
{
    var gotAny          = false;

    for (var n = fieldset.firstChild; n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Comment */
            case 8:
                break;

            /* Text content */
            case 3:
                /* If it has anything except whitespace */
                if (!n.nodeValue.isblank())
                    console.error("Bare text", n);
                break;

            /* Element */
            case 1:

                if (n.tagName == "LEGEND")
                {
                    if (gotAny)
                        console.error("Misplaced legend", n);
                    mrkp_vldt_simple_element(n, "Legend", true);
                }
                else
                {
                    if (!gotAny)
                        console.error("Expecting legend instead", n);
                    mrkp_vldt_fieldset_element(n);
                }

                gotAny = true;
                break;

            /* Anything else */
            default:
                console.error("Unknown node type %s", n.nodeType, n);
                break;
        }
    }

    if (!gotAny)
        /* At least legend must be present */
        console.error("Missing legend");
}


/**
 * Validate error message markup
 */
function mrkp_vldt_error_msg(msg)
{
    mrkp_vldt_simple_element(msg, "Error message", true);
}


/**
 * Validate error text markup
 */
function mrkp_vldt_error_txt(text)
{
    mrkp_vldt_simple_element(text, "Error text", true);
}


/**
 * Validate error message markup
 */
function mrkp_vldt_error_box(box)
{
    var gotText = false;

    for (var n = box.firstChild; n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Comment */
            case 8:
                break;

            /* Text content */
            case 3:
                /* If it has anything except whitespace */
                if (!n.nodeValue.isblank())
                    console.error("Bare text", n);
                break;

            /* Element */
            case 1:

                if (n.tagName == "PRE" && element_has_class(n, "error-txt"))
                {
                    if (gotText)
                        console.error("Extra error text", n);
                    gotText = true;
                    mrkp_vldt_error_txt(n);
                    break;
                }

                console.error("Unexpected element", n);
                break;

            /* Anything else */
            default:
                console.error("Unknown node type %s", n.nodeType, n);
                break;
        }
    }

    if (!gotText)
        /* At least message must be present */
        console.error("Missing error text");
}


/**
 * Validate error markup
 */
function mrkp_vldt_error(error)
{
    var gotMsg  = false;
    var gotBox  = false;

    for (var n = error.firstChild; n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Comment */
            case 8:
                break;

            /* Text content */
            case 3:
                /* If it has anything except whitespace */
                if (!n.nodeValue.isblank())
                    console.error("Bare text", n);
                break;

            /* Element */
            case 1:

                if (n.tagName == "DIV")
                {
                    if (element_has_class(n, "error-msg"))
                    {
                        if (gotMsg)
                            console.error("Extra error message", n);
                        gotMsg = true;
                        mrkp_vldt_error_msg(n);
                        break;
                    }
                    if (element_has_class(n, "error-box"))
                    {
                        if (gotBox)
                            console.error("Extra error box", n);
                        gotBox = true;
                        if (!gotMsg)
                            console.error("Misplaced error box", n);
                        mrkp_vldt_error_box(n);
                        break;
                    }
                }

                console.error("Unexpected element", n);
                break;

            /* Anything else */
            default:
                console.error("Unknown node type %s", n.nodeType, n);
                break;
        }
    }

    if (!gotMsg)
        /* At least message must be present */
        console.error("Missing error message");
}


/**
 * Validate form markup.
 */
function mrkp_vldt_form(form)
{
    var noMoreErrors    = false;
    var action;

    action = form.attributes.getNamedItem("action");

    if (action != null && action.nodeValue != null && 
        action.nodeValue.length != 0 &&
        action.nodeValue.charAt(0) != '#')
        console.error("Invalid action '%s'", action.nodeValue);

    for (var n = form.firstChild; n != null; n = n.nextSibling)
    {
        switch (n.nodeType)
        {
            /* Comment */
            case 8:
                break;

            /* Text content */
            case 3:
                /* If it has anything except whitespace */
                if (!n.nodeValue.isblank())
                    console.error("Bare text", n);
                break;

            /* Element */
            case 1:
                if (n.tagName == "DIV" && element_has_class(n, "error"))
                {
                    if(noMoreErrors)
                        console.error("Misplaced error output", n);

                    console.group("Error", n);
                    mrkp_vldt_error(n);
                    console.groupEnd();
                    break;
                }

                if (n.tagName == "FIELDSET")
                {
                    var l = n.getElementsByTagName("LEGEND")[0];

                    if (l == null)
                        console.group("(missing legend)", n);
                    else
                        console.group(l.textContent, n);

                    mrkp_vldt_fieldset(n);
                    console.groupEnd();
                }
                else
                {
                    mrkp_vldt_fieldset_element(n);
                }

                noMoreErrors = true;

                break;

            /* Anything else */
            default:
                console.error("Unknown node type %s", n.nodeType, n);
                break;
        }
    }
}

/**
 * Validate page content markup.
 *
 * Check that headers go in the right order and both forms and headers
 * belong to the #content directly.
 */
function mrkp_vldt_content(content)
{
    var elementList;
    var start_level     = 1
    var level           = start_level;

    /* Retrieve all child elements */
    elementList = content.getElementsByTagName("*");

    /* For each element */
    for (var i = 0; i < elementList.length; i++)
    {
        var e = elementList[i];
        var matchList;

        matchList = e.tagName.match(/^H([1-6])$/i);

        if (matchList != null)
        {
            var hLevel = parseInt(matchList[1], 10);

            if (hLevel <= start_level)
            {
                console.error("Invalid heading level %s", hLevel, e);
                continue;
            }

            if (hLevel > (level + 1))
            {
                console.error("Missing %s intermediate level header(s)",
                              hLevel - level - 1);
                for (var gLevel = level + 1; gLevel < hLevel; gLevel++)
                    console.group("(missing header)");
            }
            else if (hLevel <= level)
            {
                for (var gLevel = hLevel; gLevel >= level; gLevel--)
                    console.groupEnd();
            }

            if (e.parentNode != content)
                console.error("Misplaced section heading", e);

            console.group(e.textContent, e);

            level = hLevel;
        }
        else if (e.tagName == "FORM")
        {
            if (e.parentNode != content)
                console.error("Misplaced form", e);

            console.group(e);
            mrkp_vldt_form(e);
            console.groupEnd();
        }
    }

    /* Check for any bare text */
    for (var n = content.firstChild; n != null; n = n.nextSibling)
        if (n.nodeType == 3 && !n.nodeValue.isblank())
            console.error("Bare text", n);
}

/**
 * Validate page markup.
 */
function mrkp_vldt()
{
    /* If there is no firebug */
    if (!window.console || !console.firebug)
        return;

    /* Validate page content */
    console.group(document.title);
    mrkp_vldt_content(document.getElementById("content"));
    console.groupEnd();
}

/**
 * Attach validation routine to the window onload handler
 */
object_attach_handler(window, "load",
                      function () {mrkp_vldt(); return true;},
                      true)


