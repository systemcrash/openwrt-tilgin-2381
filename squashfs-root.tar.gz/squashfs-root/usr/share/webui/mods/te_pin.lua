---
-- Terminal equipment PIN setup WebUI module.
-- @release $Id:$
--

local crm   = require("webui.crm")
local te_pin = {}

function te_pin.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()
    local usb_upper         = mit.port.USB.upper
    local upper_id
    local node
    local admin
    local anew
    local code
    local puk
    local status
    local result = nil

    upper_id = query.id.get()
    if not upper_id then
        error(_("Failed to get interface id"))
    end

    node = usb_upper[upper_id].iface.prop.te.link.pin
    status = node.status.name.aka(_("status")).get_string()

    admin = form.admin.aka(_("administrative state")).get()
    if admin then
        node.admin.aka(_("administrative state")).set_string(admin)
    end

    code = form.code.aka(_("PIN code")).get()
    if code then
        node.code.aka(_("PIN code")).set_string(code)
        if status ~= "READY" then
            node.valid.subscribe_change(
                nil, 1000,
                function (mapi, path, old, new)
                    if (new:get_string() ~= "") then
                        result = true
                    end
                end)                
        end
    end

    anew = form.anew.aka(_("new PIN code")).get()
    if anew then
        node.anew.aka(_("new PIN code")).set_string(anew)
    end

    puk = form.puk.aka(_("PIN code")).get()
    if puk then
        node.puk.aka(_("PUK code")).set_string(puk)
    end

    t:close()

    if (code and (status ~= "READY")) then
        local max_time = 10

        while (not result and max_time > 0) do
            crm.handle_events()
            os.execute("sleep 1")
            max_time = max_time - 1
        end

        if result then
            prvt.pin_ready = true
        end
    end
end


function te_pin.fetch(conf, query, prvt, form)

    if prvt.pin_ready.as_boolean() then
        form.pin_ready = true
        return
    end

    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local usb_upper         = mit.port.USB.upper
    local upper_id
    local node
    local h_mode_list

    upper_id = query.id.get()
    if not upper_id then
        error(_("Failed to get interface id"))
    end

    node           = usb_upper[upper_id].iface.prop.te.link.pin
    h_mode_list    = form.te_facility_lock.create()

    for mode_id, c_mode in
        mit.enum.te_facility_lock.aka(_("TE facility lock modes")).as_iter() do
            local h_mode = h_mode_list[c_mode.value.as_string()].create()
        
            h_mode.name = c_mode.name.get_string()
    end

    form.status = node.status.name.aka(_("status")).get_string()
    form.oper   = node.oper.name.aka(_("operating state")).get_string()
    form.admin  = node.admin.name.aka(_("administrative state")).get_string()
    form.code   = node.code.aka(_("PIN code")).get_string()
    form.anew   = node.anew.aka(_("new PIN code")).get_string()
    form.puk    = node.puk.aka(_("PUK code")).get_string()

    t:close()
end


return te_pin
