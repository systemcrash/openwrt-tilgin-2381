---
-- Modem setup WebUI module.
-- @release $Id: modem.lua 141232 2009-12-01 16:46:07Z nikolai.kondrashov $
--

local crm   = require("webui.crm")
local modem = {}

function modem.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()
    local port  = mit.port.DSL.aka(_("DSL port"))

    if not port.exists() then
        port = mit.port.WAN.aka(_("WAN port"))
    end

    -- Transfer modulation
    port.modulation_admin.aka(_("administrative modulation")).
        set_string(form.modulation_admin.
                    aka(_("administrative modulation")).req_nonempty())

    t:close()
end


function modem.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local port              = mit.port.DSL.aka(_("DSL port"))
    local h_modulation_list = form.modulation_list.create()

    if not port.exists() then
        port = mit.port.WAN.aka(_("WAN port"))
    end

    -- Transfer modulation set
    for modulation_id, c_modulation in
        mit.enum.dsl_modulation.aka(_("DSL modulation set")).as_iter() do
        local h_modulation      =
                h_modulation_list[c_modulation.value.as_string()].create()
        local modulation_name   = c_modulation.name.get_string()

        h_modulation.name   = modulation_name
        h_modulation.title  = modulation_name:gsub("_", " ")
    end

    -- Transfer operating and administrative modulation
    form.modulation         = port.modulation.name.
                                aka(_("operating modulation")).
                                get_string()
    form.modulation_admin   = port.modulation_admin.name.
                                aka(_("administrative modulation")).
                                get_string()

    t:close()
end


return modem
