---
-- Scheduling LAN clients blocking WebUI module.
-- @release $Id:$
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local webui_mods        = {}
webui_mods.lan          = {}
webui_mods.lan.grp_set  = require("webui_mods.lan.grp_set")
local lan_sched_list    = {}

local function apply_sched(pnode, snode, item)
    local hour_start, hour_end, min_start, min_end
    local daymask, daynum
    local index, ok, e

    if (pnode == nil) == (snode == nil) then
        error(_("Unexpected usage of apply_sched() function"))
    end

    if (snode == nil) and (item.hour_start.is_empty() or
                           item.min_start.is_empty() or
                           item.hour_end.is_empty() or
                           item.min_end.is_empty()) then
        return
    end

    hour_start  = item.hour_start.aka(_("start hour")).req_range(0, 24).as_number()
    hour_end    = item.hour_end.aka(_("end hour")).req_range(0, 24).as_number()
    min_start   = item.min_start.aka(_("start minute")).req_range(0, 59).as_number()
    min_end     = item.min_end.aka(_("end minute")).req_range(0, 59).as_number()

    if (hour_start > hour_end) or
       (hour_start == hour_end and min_start > min_end) then
       error(_("Start time should be less than end time"))
    end

    daymask = 0
    for daynum = 1,7,1 do
        daymask = daymask + (2 ^ (daynum - 1)) * (item.day[daynum].as_number() or 0)
    end

    if snode == nil then
        index = pnode.add.aka(_("create")).exec({}, {"index"})
        snode = pnode.table[index:as_string()]
    end

    ok, e =  pcall(function ()
        snode.hour_start.aka(_("start hour")).set_u8(hour_start)
        snode.hour_end.aka(_("end hour")).set_u8(hour_end)
        snode.min_start.aka(_("start min")).set_u8(min_start)
        snode.min_end.aka(_("end min")).set_u8(min_end)
        snode.daymask.aka(_("daymask")).set_u8(daymask)
    end)

    if not ok then
        if pnode ~= nil then
            pnode.del.exec({index = index}, {})
        end
        error(e)
    end
end

function lan_sched_list.apply(conf, query, form, prvt)
    local action, cli_id, grp_id, s, f
    local c_cli, h_cli, c_sched, h_sched, sid, snode
    local t, mit

    action = form.action.get()
    s, f, grp_id, cli_id = string.find(action, "#(%d+):(%d+)")

    if not grp_id or not cli_id then
        return
    end

    t   = crm.transaction():webui_open_rw()
    mit = t:mit()
    c_cli = mit.lan.group.iaka(_("LAN group #%s"))[grp_id].lan_client.iaka(_("LAN client #%s"))[cli_id]

    c_sched = c_cli.hg_schedule.aka(_("schedule set")).table
    for sid, snode in c_sched.as_iter() do
        local hour_start, hour_end, min_start, min_end, start_time, end_time
        local daymask, daynum

        h_sched = form.sched[sid]
        if h_sched.delete.as_boolean() then
            c_cli.hg_schedule.del.exec({index = crm.value.u32(sid)}, {})
        else
            apply_sched(nil, snode, h_sched)
        end
    end

    apply_sched(c_cli.hg_schedule, nil, form.new_sched)

    t:close()

end


function lan_sched_list.fetch(conf, query, prvt, form)
        local t     = crm.transaction():webui_open_ro()
        local mit   = t:mit()

        webui_mods.lan.grp_set.smmr(form, mit)
        webui_mods.lan.grp_set.fetch_client_list(form, mit)
        t:close()
end


return lan_sched_list


