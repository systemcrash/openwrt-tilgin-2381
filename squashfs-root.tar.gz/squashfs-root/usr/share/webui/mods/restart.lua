---
-- System restart WebUI module.
-- @release $Id:$
--

local crm       = require("webui.crm")
local restart   = {}


function restart.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()

    mit.system.reboot.aka(_("restart timeout")).set_s32(2000)

    t:close()
end


function restart.fetch(conf, query, prvt, form)
    local t     = crm.transaction():webui_open_ro()
    local mit   = t:mit()

    form.restart_timeout = mit.system.reboot.
                            aka(_("restart timeout")).as_string()

    t:close()
end


return restart
