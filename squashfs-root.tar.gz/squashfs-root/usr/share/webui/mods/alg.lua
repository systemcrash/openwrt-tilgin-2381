---
-- Application level gateway management WebUI module.
-- @release $Id: alg.lua 157220 2011-09-08 10:41:04Z marina.maslova $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local alg = {}


local function apply_sip(c_sip, h_sip)
    c_sip.admin.set_boolean(h_sip.admin.as_boolean())

    c_sip.lan_signaling_port.aka(_("signaling port")).set_u16(
        h_sip.lan_signaling_port.aka(_("signaling port")).
                                    req_range(1, 65535))
    c_sip.pfpool.set_link("/connection/fallback/ppool/" ..
                          h_sip.pfpool.get())
end


function alg.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local alg       = t:mit().alg

    alg.admin.set_boolean(form.admin.as_boolean())
    apply_sip(alg.sip.aka(_("SIP")), form.sip)

    t:close()
end


local function fetch_ppool_list(h_list, c_list)
    for id, c_ppool in c_list.as_iter() do
        h_list[id] = c_ppool.name.get_string()
    end
end


local function fetch_sip(h_sip, c_sip)
    local pfpool_path, pfpool_id

    h_sip.admin = c_sip.admin.get_boolean()
    h_sip.lan_signaling_port        = c_sip.lan_signaling_port.as_number()

    pfpool_path = c_sip.pfpool.get_link()
    if #pfpool_path > 0 then
        pfpool_path = c_sip.get_transaction():realpath(pfpool_path)
        pfpool_id = pfpool_path:
                        match("^/connection/fallback/ppool/([0-9]+)$")
        if pfpool_id == nil then
            error(("Invalid prioritized connection " ..
                   "fallback pool path \"%s\""):format(pfpool_path))
        end
        h_sip.pfpool = pfpool_id
    end
end


function alg.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local alg       = mit.alg

    form.oper   = alg.oper.get_boolean()
    form.admin  = alg.admin.get_boolean()

    fetch_ppool_list(form.pfpool.create(),
                     mit.connection.fallback.ppool)

    fetch_sip(form.sip.create(), alg.sip.aka(_("SIP")))

    t:close()
end


return alg
