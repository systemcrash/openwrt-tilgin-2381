---
-- Storage user creating WebUI module.
-- @release $Id: storage_user_new.lua 134347 2009-06-04 10:16:41Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local req               = require("webui_mods.sec.users").req
local vpn_users_new  = {}



function vpn_users_new.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local ac        = t:mit().ipsec_accounts
    local username
    local password
    local index
    local users
    local ok, e

    username = req.username(form.username.aka(_("username"))).get()
    password = req.password(form.password.aka(_("password"))).get()

    index = ac.users.add.exec({}, {"index"})
    users = ac.users.table[index:as_string()]

    ok, e = pcall(function ()
        users.username.aka(_("username")).set_string(username)
        users.password.aka(_("password")).set_string(password)       
    end)

    if not ok then
        ac.users.del.exec({index = index}, {})
        error(e)
    end

    t:close()
end


return vpn_users_new