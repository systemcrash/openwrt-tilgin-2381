----
-- DSL status WebUI module.
-- @release $Id: sniffer_list.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--
local crm               = require("webui.crm")
local service_suspend   = {}


local function service_iter(mit)
    local iter_fn   = mit.update.suspend.table.
                        aka(_("service set")).
                        iaka(_("service #%s")).as_iter()

    return function ()
        while true do
            local suffix, node = iter_fn()

            if not suffix then
                return nil
            end

            if node.get_link() ~= "/httpd" and node.get_link() ~= "/config/save" then
                return suffix, node
            end
        end
    end
end


function service_suspend.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()

    local suspended = form.suspended.as_boolean()

    for service_id, c_service in service_iter(mit) do
        c_service.suspended.set_boolean(suspended)
    end

    t:close()
end


function service_suspend.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()

    local h_service_list    = form.service.create()
    local h_service
    local service_path

    form.no_suspend = mit.update.suspend.no_suspend.
                            aka(_("global suspension flag")).get_boolean()

    if (form.no_suspend.as_boolean()) then
        t:close()
        return
    end

    for service_id, c_service in service_iter(mit) do
        h_service = h_service_list[service_id].create()
        h_service.mangled_path = c_service.get_link():sub(2):gsub("/", "_")
        h_service.oper = c_service.oper.aka(_("operating status")).
                                            get_boolean()
        h_service.admin = c_service.admin.aka(_("administrative status")).
                                            get_boolean()
        h_service.suspended = c_service.suspended.
                                            aka(_("suspension status")).
                                            get_boolean()
    end

    t:close()
end


return service_suspend
