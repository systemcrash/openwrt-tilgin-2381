---
-- L2TP user creating WebUI module.
-- @release $Id: $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local l2tp_server_user_new  = {}


function l2tp_server_user_new.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local l2tp        = t:mit().l2tp
    local index
    local user
    local ok, e
    local context = query.context.get()
    if not context and not (context == "ppp" or context == "l2tp") then
        error(_("Incorrect context."))
    end
    local username = form.username.aka(_("name")).get()
    local secret = form.secret.aka(_("password")).req_nonempty().get()
    local pap = false
    local chap = false
    if context == "ppp" then
       pap = form.pap.aka(_("PAP authentication")).as_boolean()
       chap = form.chap.aka(_("CHAP authentication")).as_boolean()
    end

    if context == "ppp" then
        index = l2tp.ppp_user.add.exec({}, {"index"})
        user = l2tp.ppp_user.table[index:as_string()]
    elseif context == "l2tp" then
        index = l2tp.l2tp_user.add.exec({}, {"index"})
        user = l2tp.l2tp_user.table[index:as_string()]
    end
    ok, e = pcall(function ()
        user.username.aka(_("name")).set_string(username)
        user.secret.aka(_("password")).set_string(secret)
        user.pap.aka(_("PAP authentication")).set_boolean(pap)
        user.chap.aka(_("CHAP authentication")).set_boolean(chap)
    end)

    if not ok then
        if context == "ppp" then
            l2tp.ppp_user.del.exec({index = index}, {})
        elseif context == "l2tp" then
            l2tp.l2tp_user.del.exec({index = index}, {})
        end
        error(e)
    end

    t:close()
end


return l2tp_server_user_new


