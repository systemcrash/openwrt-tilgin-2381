---
-- Multicast statistics WebUI module.
-- @release $Id: $
--

local crm                    = require("webui.crm")
local status_multicast   = {}

function status_multicast.fetch(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_ro()
    local igmp          = t:mit().igmp
    local h_group       = form.mgroup.create()

    local gid, c_group

    form.admin = igmp.admin.get_boolean()
    form.oper = igmp.oper.get_boolean()

    for gid, c_group in igmp.group.as_iter() do
        local h_host, h_port
        local hid, pid
        local c_host, c_port

        h_group[gid].create()
        h_group[gid].addr = c_group.addr.aka(_("address")).get_octets_as_ip_addr()
        h_group[gid].timer = c_group.timer.as_string()
        h_host = h_group[gid].host.create()
        h_port = h_group[gid].portset.create()

        for pid, c_port in t:mit().port.as_iter() do
            if c_port.number.exists() then
                local number = c_port.number.as_string()

                h_port[number].create()
                h_port[number].name = c_port.name.aka("port name").get_string()
                h_port[number].used = false
            end
        end

        for hid, c_host in c_group.host.as_iter() do
            local port

            h_host[hid].create()
            h_host[hid].mac = c_host.mac.aka("MAC address").get_octets_as_mac_addr()
            port = c_host.port.aka("port").as_string()
            h_host[hid].port = h_port[port].name.get()
            h_port[port].used = true
        end
    end

    t:close()
end


return status_multicast
