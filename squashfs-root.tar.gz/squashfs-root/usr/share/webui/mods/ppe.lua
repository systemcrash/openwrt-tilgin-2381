---
-- PPE management WebUI module.
-- @release $Id: ppe.lua 177881 2016-01-22 14:13:23Z piotr.lavrov $
--

local crm   = require("webui.crm")
local ppe   = {}


function ppe.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local ppe       = t:mit().ppe
    local c_dp_list = ppe.directpath

    ppe.admin.set_boolean(form.admin.as_boolean())

    for dp_id, h_dp in form.directpath.iter() do
        c_dp_list[dp_id].admin.set_boolean(h_dp.admin.as_boolean())
    end

    t:close()
end


function ppe.fetch(conf, query, prvt, form)
    local t     = crm.transaction():webui_open_ro()
    local ppe   = t:mit().ppe

    form.admin = ppe.admin.get_boolean()
    form.oper = ppe.oper.get_boolean()

    if ppe.directpath.exists() then
        local h_dp_list = form.directpath.create()

        for dp_id, c_dp in ppe.directpath.as_iter() do
            local h_dp = h_dp_list[dp_id].create()

            h_dp.admin = c_dp.admin.get_boolean()
            h_dp.iface_name = c_dp.iface.ssid.get_string()
        end
    end

    t:close()
end


return ppe
