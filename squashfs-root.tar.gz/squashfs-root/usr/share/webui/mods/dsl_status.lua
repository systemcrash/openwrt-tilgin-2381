----
-- DSL status WebUI module.
-- @release $Id: sniffer_list.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--
local int           = require("webui.int")
local crm           = require("webui.crm")
local dsl_status    = {}

function dsl_status.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local port      = mit.port.DSL.aka(_("DSL port"))
    local std       = port.standard.name.aka(_("standard")).
                                                get_string():gsub("_", " ")
    local encaps    = port.encaps.name.aka(_("encapsulation")).
                                                get_string():gsub("_", " ")

    if not port.exists() then
        port = mit.port.WAN.aka(_("WAN port"))
    end

    form.oper       = port.oper.aka(_("operating status")).get_boolean()
    form.line_type  = port.line_type.name.aka(_("line type")).
                                                get_string():gsub("_", " ")

    form.standard = std .. ((string.find(std, "993") and " (VDSL)") or
                            ((std == "Unknown") and "") or " (ADSL)" )

    form.encaps = (string.find(encaps, "ATM") and "ATM") or "PTM"

    form.hw_rev     = port.hw_rev.aka(_("hardware revision")).get_string()
    form.fw_rev     = port.fw_rev.aka(_("firmware revision")).get_string()

    if port.drv_vinax_rev.exists() then
        form.drv_vinax_rev  = port.drv_vinax_rev.
                                aka(_("Vinax driver revision")).get_string()
    else
         form.drv_vrx_rev  = port.drv_vrx_rev.
                                aka(_("VRX driver revision")).get_string()  
    end

    form.drv_api_rev    = port.drv_api_rev.
                            aka(_("API driver revision")).get_string()

    form.profile        = port.profile.name.aka(_("profile")).get_string()

    form.us_curr_rate   = port.us_curr_rate.
                            aka(_("upstream rate")).as_string()
    form.ds_curr_rate   = port.ds_curr_rate.
                            aka(_("downstream rate")).as_string()
    form.us_max_rate    = port.us_max_rate.
                            aka(_("maximum upstream rate")).as_string()
    form.ds_max_rate    = port.ds_max_rate.
                            aka(_("maximum downstream rate")).as_string()
    form.init_status    = port.dsl_init_status.
                                aka(_("initialization status")).
                                get_boolean()

    -- FIXME keep precision!
    form.us_attenuation = port.us_attenuation.
                            aka(_("upstream attenuation")).
                            get_int_u32() 
    form.ds_attenuation = port.ds_attenuation.
                            aka(_("downstream attenuation")).
                            get_int_u32() 
    form.us_noise_margin = port.us_noise_margin.
                            aka(_("upstream noise margin")).
                            as_number() 
    form.ds_noise_margin = port.ds_noise_margin.
                            aka(_("downstream noise margin")).
                            as_number() 

    t:close()
end

return dsl_status
