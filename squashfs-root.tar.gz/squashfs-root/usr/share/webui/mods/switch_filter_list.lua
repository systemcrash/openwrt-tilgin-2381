---
-- Switch filter list WebUI module.
-- @release $Id: switch_filter_list.lua 138178 2009-09-15 16:41:26Z nikolai.kondrashov $
--

local crm                       = require("webui.crm")
local hdf                       = require("webui.hdf")
local webui_mods                = {}
webui_mods.switch               = {}
webui_mods.switch.filter_set    = require("webui_mods.switch.filter_set")

local switch_filter_list = {}


function switch_filter_list.apply(conf, query, form, prvt)
    local t = crm.transaction():webui_open_rw()

    webui_mods.switch.filter_set.apply(
        t:mit().ethernet.switch.super.filter, form)

    t:close()
end


function switch_filter_list.fetch(conf, query, prvt, form)
    local t = crm.transaction():webui_open_ro()

    webui_mods.switch.filter_set.fetch(
        form, t:mit().ethernet.switch.super.filter)

    t:close()
end


return switch_filter_list
