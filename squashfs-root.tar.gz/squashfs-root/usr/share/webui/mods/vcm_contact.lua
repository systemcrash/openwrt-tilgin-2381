---
-- VCM contact WebUI module.
-- @release $Id: vcm_contact.lua 145274 2010-04-01 08:48:34Z nikolai.kondrashov $
--

local oo                = require("loop.simple")
local err               = {}
err.Abstract            = require("err.Abstract")
local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local vcm_contact = {}


function vcm_contact.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()
    local ok, e, se

    ok, e = pcall(function ()
        mit.config.provisioning.control.contact.aka(_("contact")).exec()
    end)

    if not ok then
        if oo.instanceof(e, err.Abstract) then
            se = e:match(crm.err.Status)
            if se then
                if se.rc == crm.status.EOPNOTSUPP then
                    error(_("management protocol is not yet discovered"))
                else
                    if se.rc == crm.status.EBUSY then
                        error(_("ACS contact is already in progress"))
                    end
                end
            end
        end
        error(e)
    end

    t:close()
end


function vcm_contact.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local server    = mit.config.provisioning.server.aka(_("server"))

    form.state = mit.update.state.name.aka(_("state")).get_string()
    form.server.addr = server.addr.aka(_("address")).get_octets_as_ip_addr()
    form.server.fqdn = server.fqdn.aka(_("domain name")).get_string()
    form.server.origin = server.origin.name.aka(_("origin")).get_string()

    t:close()
end


return vcm_contact

