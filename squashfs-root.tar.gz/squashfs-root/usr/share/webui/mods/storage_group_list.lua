---
-- Storage group list WebUI module.
-- @release $Id: storage_group_list.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm                   = require("webui.crm")
local hdf                   = require("webui.hdf")
local req                   = require("webui_mods.storage.account").req
local storage_group_list    = {}


local function apply_account(ac, c_account, h_account)
    local id
    local user

    c_account.name.aka(_("name")).
        set_string(req.name(h_account.name.aka(_("name"))).get())
    c_account.admin.aka(_("administrative status")).
        set_boolean(h_account.admin_status.as_boolean())

    for id, user in h_account.user.iter() do
        if user.selected.as_boolean() then
            ac.user.table[id].del_group.exec(
                {group = crm.value.link(c_account.get_path())})
        end
    end

    for id, user in h_account.new_user.iter() do
        if user.selected.as_boolean() then
            ac.user.table[id].add_group.exec(
                {group = crm.value.link(c_account.get_path())})
        end
    end
end


function storage_group_list.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local ac        = t:mit().storage.ac

    local id
    local h_account

    for id, h_account in form.account.iter() do
        local c_account = ac.group.table[id]

        if c_account.exists() then
            if h_account.delete.as_boolean() then
                ac.group.del.exec(
                    {link = crm.value.link(c_account.get_path())})
            else
                apply_account(ac, c_account, h_account)
            end
        end
    end

    t:close()
end


local function user_has_group(user, group_id)
    local id
    local node

    for id, node in user.group.as_iter() do
        if node.deref().get_name() == group_id then
            return true
        end
    end

    return false
end


local function fetch_group_user_list(item, group_id, user_set)
    local id
    local user

    for id, user in user_set.as_iter() do
        if user_has_group(user, group_id) then
            item[id] = ""
        end
    end
end


local function fetch_account_list(item, node)
    local id
    local na
    local ia

    for id, na in node.as_iter() do
        ia = item[id]
        ia.name         = na.name.get_string()
        ia.oper_status  = na.oper.get_boolean()
    end
end


function storage_group_list.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_rw()
    local ac        = t:mit().storage.ac
    local id
    local node
    local item

    for id, node in ac.group.table.as_iter() do
        item = form.account[id].create()

        item.name               = node.name.get_string()
        item.oper_status        = node.oper.get_boolean()
        item.admin_status       = node.admin.get_boolean()

        fetch_group_user_list(item.user, id, ac.user.table)
    end

    fetch_account_list(form.user, ac.user.table)

    t:close()
end


return storage_group_list
