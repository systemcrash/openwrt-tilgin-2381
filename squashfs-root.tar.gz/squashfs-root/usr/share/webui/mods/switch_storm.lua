---
-- Switch storm protection management WebUI module.
-- @release $Id: switch_storm.lua 150476 2010-10-25 11:25:52Z nikolai.kondrashov $
--


local crm                   = require("webui.crm")
local hdf                   = require("webui.hdf")
local webui_mods            = {}
webui_mods.switch           = {}
webui_mods.switch.if_set    = require("webui_mods.switch.if_set")
local switch_storm          = {}


local function apply_port(h_global, c_port, h_port)
    local bcast, mcast

    if h_global.as_boolean() then
        bcast = h_global.bcast.as_boolean()
        mcast = h_global.mcast.as_boolean()
    else
        bcast = h_port.bcast.as_boolean()
        mcast = h_port.mcast.as_boolean()
    end

    c_port.storm_bcast.
            aka(_("broadcast storm protection flag")).set_boolean(bcast)
    c_port.storm_mcast.
            aka(_("multicast storm protection flag")).set_boolean(mcast)
end

function switch_storm.apply(conf, query, form, prvt)
    local t             = crm.transaction():webui_open_rw()
    local mit           = t:mit()
    local h_port_list   = form.port.iaka(_("port #%s"))

    -- Apply ports
    for port_id, c_port in
        webui_mods.switch.if_set.as_port_iter(
            mit.ethernet.switch.super.available.
                aka(_("interface set")).iaka(_("interface #%s"))) do
        apply_port(form.global, c_port, h_port_list[port_id])
    end

    t:close()
end


local function fetch_port(h_global, h_port, c_port)
    local storm_global = c_port.storm_global.
                            aka(_("global storm protection flag"))

    if (storm_global.get_boolean()) then
        h_global.set(true)
    end

    h_port.name = c_port.name.aka(_("name")).get_string()
    h_port.bcast = c_port.storm_bcast.
                            aka(_("broadcast storm protection flag")).
                            get_boolean()
    h_port.mcast = c_port.storm_mcast.
                            aka(_("multicast storm protection flag")).
                            get_boolean()
end


function switch_storm.fetch(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_ro()
    local mit           = t:mit()
    local h_port_list   = form.port.create()

    -- Fetch ports
    for port_id, c_port in
        webui_mods.switch.if_set.as_port_iter(
            mit.ethernet.switch.super.available.
                aka(_("interface set")).iaka(_("interface #%s"))) do
        fetch_port(form.global.create(),
                   h_port_list[port_id].create(), c_port)
    end

    t:close()
end


return switch_storm
