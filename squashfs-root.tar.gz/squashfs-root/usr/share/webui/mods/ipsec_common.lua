---
-- IPSEC common configuration module
-- @release $Id:$
--

local crm   = require("webui.crm")
local ipsec_common     = {}

function ipsec_common.apply(conf, query, form, prvt)
    local t                 = crm.transaction():webui_open_rw()
    local ipsec             = t:mit().security.ipsec

    ipsec.force_keepalive.aka(_("force keepalive"))
        .set_boolean(form.force_keepalive.as_boolean())
    ipsec.keepalive.aka(_("keepalive interval"))
        .set(form.keepalive.aka(_("keep alive interval"))
            .req_range(1, 10000).as_crm_u32())

    t:close()
end

function ipsec_common.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local ipsec             = t:mit().security.ipsec

    form.force_keepalive = ipsec.force_keepalive.aka(_("Force keep alive"))
        .get_boolean()
    form.keepalive = ipsec.keepalive.aka(_("Keepalive interval"))
        .as_string()

    t:close()
end


return ipsec_common
