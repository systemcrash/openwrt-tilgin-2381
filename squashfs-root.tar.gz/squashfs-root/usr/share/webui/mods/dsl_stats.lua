----
-- DSL statistics WebUI module.
-- @release $Id: sniffer_list.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--
local int       = require("webui.int")
local crm       = require("webui.crm")
local dsl_stats = {}

local interval_type = {
    {n = "showtime",    t = _("showtime")},
    {n = "quarterhour", t = _("15 minutes")},
    {n = "day",         t = _("24 hours")},
    {n = "total",       t = _("total")},
}

local param = {
--  {n = "rx_blocks",           t = _("received blocks (superframes)")},
--  {n = "tx_blocks",           t = _("transmitted blocks (superframes)")},
    {n = "full_init",           t = _("full line initialization attempts")},
    {n = "full_init_errors",    t = _("full line initialization errors")},
    {n = "short_init",          t = _("line initialization attempts")},
    {n = "short_init_errors",   t = _("line initialization errors")},
    {n = "init_timeouts",       t = _("line initialization timeouts")},
    {n = "lof",             t = _("loss of framing (LOF) errors")},
    {n = "loss",            t = _("loss of signal (LOS) errors, seconds")},
    {n = "lcd",             t = _("lost cell delineation (LCD) errors")},
    {n = "ncd",             t = _("no cell delineation (NCD) errors")},
    {n = "fec",             t = _("forward error correction (FEC) errors")},
    {n = "hec",             t = _("header error control (HEC) errors")},
    {n = "crc",             t = _("CRC-8 errors")},
    {n = "es",          t = _("errors, seconds (ES)")},
    {n = "ses",         t = _("severe errors, seconds (SES)")},
    {n = "uas",         t = _("unavailable, seconds (UAS)")},
}

local function fetch_interval(h_interval, c_interval)
    for i, p in ipairs(param) do
        h_interval[p.n].n = c_interval[1][p.n].as_string()
        h_interval[p.n].f = c_interval[2][p.n].as_string()
    end
end

local function fetch_type(h_type, c_type)
    for interval_id, c_interval in c_type.as_iter() do
        local valid = c_interval[1].valid.get_boolean() and
                      c_interval[2].valid.get_boolean()

        if valid then
            local near_end_elapsed  = c_interval[1].elapsed.get_int_u32()
            local far_end_elapsed   = c_interval[2].elapsed.get_int_u32()
            local elapsed   = (near_end_elapsed > far_end_elapsed)
                                and near_end_elapsed
                                 or far_end_elapsed

            if elapsed > int.u32(0) then
                local h_interval = h_type[interval_id].create()
                local duration = ("%.2u:%.2u:%.2u"):format(
                                    tostring(elapsed / int.u32(60 * 60)),
                                    tostring(elapsed % int.u32(60 * 60) /
                                             int.u32(60)),
                                    tostring(elapsed % int.u32(60)))

                h_interval.set(duration)
                fetch_interval(h_interval, c_interval)
            end
        end
    end
end

function dsl_stats.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local port      = mit.port.DSL.aka(_("DSL port"))
    local show_type = query.type.get() or "showtime"

    if not port.exists() then
        port = mit.port.WAN.aka(_("WAN port"))
    end

    -- Output parameter table
    for i, p in ipairs(param) do
        form.param[p.n] = p.t
    end

    -- Output interval types along with their data
    for i, t in ipairs(interval_type) do
        local h_t = form.type[t.n].create()
        local c_t = port.stat.aka(_("interval set"))[t.n].aka(t.t)

        h_t.set(t.t)
        fetch_type(h_t, c_t)
    end

    -- Output type shown
    form.type = show_type

    t:close()
end


return dsl_stats
