---
-- Main terminal equipment WebUI module.
-- @release $Id:$
--

local crm   = require("webui.crm")
local te_main = {}

local function get_pconn(mit, iface)
    local pconn      = nil
    local dev        = nil
    local conn       = nil
    local eth        = false
    local valid      = false

    for dev_id, c_dev in mit.connection.device.table.as_iter() do
        if iface == c_dev.link.get_link() then
            for conn_id, c_conn in c_dev.configured.as_iter() do 

                if c_conn.layer.pppos.type.exists() then
                    valid = true
                    eth = false
                else 
                    if c_conn.layer.pdn.type.exists() then
                        valid = true
                        eth = true
                    else
                        valid = false
                    end
                end
                if valid then
                    pconn       = c_conn
                    dev         = dev_id
                    conn        = conn_id
                end
            end
        end
    end

    if valid then
        return pconn, dev, conn, eth
    else
        return nil
    end
end

local function check_conn_pref(mit, pdev, pconn)
    local pprio = mit.connection.device.table[pdev].configured[pconn].
                        pfpool.default.value.get_s32()

    for dev_id, c_dev in mit.connection.device.table.as_iter() do
        for conn_id, c_conn in c_dev.configured.as_iter() do 
            if (dev_id ~= pdev or conn_id ~= pconn) and 
                c_conn.pfpool.default.value.get_s32() <= pprio then
                return false
            end
        end
    end
    return true
end

local function change_conn_pref(mit, pdev, pconn, enable)
    local pprio = "primary"
    local dprio = "secondary"

    if not enable then
        pprio = "quinary"
        dprio = "quaternary"
    end
    
    for dev_id, c_dev in mit.connection.device.table.as_iter() do
        for conn_id, c_conn in c_dev.configured.as_iter() do 
            if (dev_id == pdev and conn_id == pconn) then
                c_conn.pfpool.default.set_string(pprio)
            else
                if c_conn.pfpool.default.name.get_string() == pprio then
                     c_conn.pfpool.default.set_string(dprio)
                end
            end
        end
    end
end

function te_main.apply(conf, query, form, prvt)
    local t             = crm.transaction():webui_open_rw()
    local mit           = t:mit()
    local usb_upper     = mit.port.USB.upper
    local upper_id
    local pconn
    local dev
    local conn
    local eth

    upper_id = form.id.get()
    if not upper_id then
         error(_("Failed to get interface id"))
    end

    pconn, dev, conn, eth = get_pconn(mit, usb_upper[upper_id].iface.get_link())
    if (pconn) then
        local apn_type  = form.mt_list[upper_id].conn.apn_type.get()
        local apn_idx   = form.mt_list[upper_id].conn.apn.get()
        local pref      = form.mt_list[upper_id].conn.pref.as_boolean()
        local username
        local password
        local hidd_password = nil

        if (apn_type ~= "") then
            local apn 

            if (apn_type == "wellknown") then
                apn = usb_upper[upper_id].iface.prop.te.link.plmn.settings.apn[apn_idx]

                if apn.exists() then
                    apn = apn.name.get_string()    
                end

                username = usb_upper[upper_id].iface.prop.te.link.plmn.settings.
                                apn[apn_idx].username
                password = usb_upper[upper_id].iface.prop.te.link.plmn.settings.
                                apn[apn_idx].password

                if username.exists() then
                    username = username.get_string()
                else
                    username = ""
                end

                if password.exists() then
                    password = password.get_string()
                else
                    password = ""
                end
            else
               apn = apn_idx
               username = form.mt_list[upper_id].conn.username.get()
               password = form.mt_list[upper_id].conn.password.get()
               hidd_password = form.mt_list[upper_id].conn.hidd_password.get()
            end

            if eth then
                pconn.layer.pdn.up_param.apn.set_string(apn)
            else
                pconn.layer.ppp.param.username.set_string(username)
                if password ~= hidd_password then
                    pconn.layer.ppp.param.password.set_string(password)
                end
                pconn.layer.pppos.param.apn.set_string(apn)
            end
        end
      
        if pref ~= check_conn_pref(mit, dev, conn) then
            change_conn_pref(mit, dev, conn, pref)
        end

        pconn.admin.set_boolean(
            form.mt_list[upper_id].conn.admin.as_boolean())
    end

    t:close()
end

function te_main.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local usb_upper         = mit.port.USB.upper

    for id, c_upper in usb_upper.as_iter() do
        local type =  c_upper.iface.type.as_string()
        if type == "usb_serial_if" or type == "usb_eth_if" then
            if #c_upper.iface.usb_dev.get_link() ~= 0 then
                local item          = form.mt_list[id].create()
                local te_node       = c_upper.iface.prop.te.link
                local manuf         = te_node.mt.manuf.aka(_("manufacturer")).get_string()
                local model         = te_node.mt.model.aka(_("model")).get_string()
                local pconn
                local dev
                local conn
                local eth
                local apn_list
                local stat_valid

                if model:find(manuf) ~= nil then
                    item.name = model
                else
                    item.name = manuf .. " " .. model
                end

                item.revision       = te_node.mt.revision.aka(_("revision")).get_string()
                item.serial         = te_node.mt.serial.aka(_("serial")).get_string()
                item.status         = te_node.pin.status.name.get_string()
                item.long_oper      = te_node.plmn.long_oper.get_string()
                item.numeric_oper   = te_node.plmn.numeric_oper.get_string()
                stat_valid          = te_node.stat.valid.get_boolean()

                if stat_valid then
                    -- get statistics
                    item.uptime         = te_node.stat.uptime.aka(_("uptime")).as_string()
                    item.upload_speed   = te_node.stat.upload_speed.
                                                aka(_("upload speed")).as_string()
                    item.download_speed = te_node.stat.download_speed.
                                                aka(_("download speed")).as_string()
                    item.sent           = te_node.stat.out_bytes.aka(_("sent bytes")).as_string()
                    item.received       = te_node.stat.in_bytes.aka(_("received bytes")).as_string()
                    item.upload_max     = te_node.stat.upload_max.
                                                aka(_("upload max")).as_string()
                    item.download_max   = te_node.stat.download_max.
                                                aka(_("download max")).as_string()
                end

                pconn, dev, conn, eth = get_pconn(mit, c_upper.iface.get_link())
                if (pconn) then
                    item.conn = {}
    
                    if eth then
                        item.conn.username = "n/a"
                        item.conn.password = "n/a"
                        item.conn.apn      = pconn.layer.pdn.up_param.apn.get_string()
                    else
                        item.conn.username = pconn.layer.ppp.param.username.get_string()
                        item.conn.password = pconn.layer.ppp.param.password.get_string()
                        item.conn.apn      = pconn.layer.pppos.param.apn.get_string()
                    end

                    item.conn.admin    = pconn.admin.get_boolean()
                    item.conn.status   = pconn.status.name.get_string()
                    item.conn.dev      = dev
                    item.conn.idx      = conn
                    item.conn.pref     = check_conn_pref(mit, dev, conn)
                    item.conn.apn_type = "custom"
    
                    if te_node.plmn.settings.apn.exists() then
                        apn_list = item.conn.apn_list.create()
                        for id, c_node in te_node.plmn.settings.apn.
                                            aka(_("List of wellknown APNs")).as_iter() do
                            local h_node = apn_list[id].create()
    
                            h_node.name = c_node.name.get_string()

                            if c_node.username.exists() then
                                h_node.username = c_node.username.get_string()
                            else
                                h_node.username = ""
                            end
    
                            if c_node.password.exists() then
                                h_node.password = c_node.password.get_string()
                            else
                                h_node.password = ""
                            end
                            
                            if (h_node.name.get() == item.conn.apn.get() and
                                (eth or 
                                 (h_node.username.get() == item.conn.username.get() and
                                  h_node.password.get() == item.conn.password.get()))) then
                                item.conn.apn_type = "wellknown"
                            end
                        end
                    end
    
                    if (item.conn.apn_type ~= "wellknown" and 
                        item.conn.password) then
                        -- Hide password
                        item.conn.password = string.gsub(tostring(item.conn.password), "(.)",
                                                         function(a) return '*' end)
                    end

                    if not stat_valid then
                        item.uptime         = pconn.
                                                uptime.aka(_("uptime")).as_string()
                        item.sent           = c_upper.iface.prop.stat.
                                                out_bytes.aka(_("sent bytes")).as_string()
                        item.received       = c_upper.iface.prop.stat.
                                                in_bytes.aka(_("received bytes")).as_string()
                    end
                end
            end
        end
    end

    t:close()
end


return te_main
