---
-- Storage folder editing WebUI module.
-- @release $Id: storage_folder_edit.lua 165708 2014-01-21 06:42:23Z andrew.rybchenko $
--

local crm                   = require("webui.crm")
local hdf                   = require("webui.hdf")
local int                   = require("webui.int")

local storage_folder_edit   = {}

local function apply_ac_perm(node, item)
    local perm = {"EXEC"}

    if item.write.as_boolean() then
        perm[#perm + 1] = "WRITE"
    end

    if item.read.as_boolean() then
        perm[#perm + 1] = "READ"
    end

    node.set_string(table.concat(perm, "_"))
end


local function apply_ac_list(node, item)
    local entry_id
    local entry_item

    for entry_id, entry_item in item.iter() do
        local entry_node = node.table[entry_id]

        if entry_item.delete.as_boolean() then
            node.del.exec(
                {link = crm.value.string(entry_node.get_path())})
        else
            apply_ac_perm(entry_node.perm, entry_item.perm)
        end
    end
end


local function apply_ac_new_entry(account_set, node, item)
    local index
    local entry

    index = node.add.exec({}, {"index"})

    entry = node.table[index:as_string()]

    entry.link.set_link(account_set[item.account.id.get()].get_path())
    apply_ac_perm(entry.perm, item.perm)
end


local function apply_ac(storage, node, item)
    node.smb_auth_req   = item.smb_auth_req.as_crm_boolean()
    node.http_auth_req  = item.http_auth_req.as_crm_boolean()

    apply_ac_list(node.user, item.user)
    if not item.new_user.account.id.is_empty() then
        apply_ac_new_entry(storage.ac.user.table,
                             node.user, item.new_user)
    end

    apply_ac_list(node.group, item.group)
    if not item.new_group.account.id.is_empty() then
        apply_ac_new_entry(storage.ac.group.table,
                             node.group, item.new_group)
    end

end


local function fetch_mediatypes(form, enum_mediapath_type, mediapath_table)
    local item, id, mtype
    
    -- Get media types from CRM enum
    local id, mtype
    local i = 1
    form.mediatype = {}
    
    for id, mtype in enum_mediapath_type.as_iter() do
        form.mediatype[i] = mtype.name.get_string()
        i = i + 1
    end
     
    -- Check if this directory is used as a DLNA media directory    
    local mdir, dir
    
    for id, mdir in mediapath_table.as_iter() do
        dir  = mdir.st_dir.get_link()
                
        if dir == tostring(form.strgpath) then
          form.sel_mediatype = mdir.type.name.get_string()
          break;
        end
    end
end


function apply_mediatypes(node, sel_mediatype, dlna)
    -- Check if this directory is used as a DLNA media directory    
    local id, did, mdir, mtype, dir
    local is_media_dir = false
    local is_same_mediatype = false
    
    for id, mdir in dlna.mediapath.table.as_iter() do
        dir  = mdir.st_dir.get_link()
        mtype = mdir.type.name.get_string()
        
        if dir == node.get_path() then
          -- This directory is used as a DLNA media directory
          is_media_dir = true
          did = id
          if sel_mediatype == mtype then      
            -- This DLNA media directory is used for the selected type of 
            -- media
            is_same_mediatype = true
            break;
          end
        end
    end
     
    -- Check if something need to be changed
    if not(is_media_dir and is_same_mediatype) then
      -- Something has changed
      
      -- First delete if something changed and not new media directory
      if is_media_dir then
        dlna.mediapath.del.exec({index = crm.value.u32(did)}, {})
      end
      
      -- Add again or create if mediatype has changed or if new media 
      -- directory, and mediatype is not "none"
      if sel_mediatype ~= "none" and not is_same_mediatype then
         dlna.mediapath.add.exec(
                               {st_dir = crm.value.string(node.get_path()),
                                type = crm.value.string(sel_mediatype)})
      end

      -- Alert the DLNA module that the mediapaths has changed
      dlna.rescan_media.exec()
    end
end


function storage_folder_edit.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()
    local storage   = mit.storage
    local unit      = storage.unit[query.unit.req_nonempty().get()]
    local ac        = storage.ac
    local node      = unit.fs.dir.table[query.folder.req_nonempty().get()]
    local sel_mediatype = form.sel_mediatype.req_nonblank().get()
    local rescan    = "0"

    if form.delete.as_boolean() then
        unit.fs.dir.del.exec({link = crm.value.link(node.get_path())})
        prvt.deleted = true
    else
        if unit.fs.mount_oper.get_boolean() and
           unit.fs.manage_dirs.get_boolean() then
            node.name.aka(_("name")).
                set_string(form.name.req_nonblank().get())
        end

        node.enabled = form.enabled.as_crm_boolean()

        apply_ac(storage, node.ac, form.ac)
    end
        
    -- Apply mediapaths and notify the DLNA module if thery are changed
    apply_mediatypes(node, sel_mediatype, mit.dlna)

    -- If the "Rescan" button was clicked request a rescan of mediafiles
    if form.rescan.get() == "1" then
      -- Alert the DLNA module to rescan mediapaths
      mit.dlna.rescan_media.exec()
    end

    t:close()
end


local function fetch_fs(item, node)
    local size
    local used

    item.type = node.type.name.get_string()

    size = node.size.get_int_u64()
    used = node.used.get_int_u64()

    item.size.value, item.size.unit = size:decimal_scaled_bytes()
    item.used.value, item.used.unit = used:decimal_scaled_bytes()
    item.free.value, item.free.unit = (size - used):decimal_scaled_bytes()

    item.mount_oper     = node.mount_oper.get_boolean()
    item.mount_admin    = node.mount_admin.get_boolean()
    item.manage_dirs    = node.manage_dirs.get_boolean()
end


local function fetch_volume(item, node)
    local oper

    item.type       = "volume"
    item.name       = node.name.aka(_("name")).get_string()
    item.admin      = node.admin.aka(_("administrative status")).
                                                    get_boolean()
    item.connected  = node.connected.aka(_("connection status")).
                                                    get_boolean()
    oper            = node.oper.aka(_("operating status")).
                                                    get_boolean()
    item.oper       = oper

    if oper then
        item.capacity.value, item.capacity.unit =
            node.capacity.aka(_("capacity")).
                get_int_u64():decimal_scaled_bytes()
    end

    fetch_fs(item.fs, node.fs)
end


local function fetch_ac_perm(item, node)
    local value = node.value.as_number()

    -- Check 3rd bit
    item.read = (value >= 4 and value <= 7)
    -- Check 2nd bit
    item.write = (value == 2 or value == 3 or value == 6 or value == 7)
end


local function fetch_ac_account(item, node)
    item.name           = node.name.get_string()
    item.id             = node.get_name()
    item.oper_status    = node.oper.get_boolean()
end


local function fetch_ac_entry(item, node)
    fetch_ac_account(item.account, node.link.deref())
    fetch_ac_perm(item.perm, node.perm)
end


local function fetch_ac_list(item, node)
    local entry_id
    local entry_node

    for entry_id, entry_node in node.as_iter() do
        if #entry_node.link.get_link() ~= 0 then
            fetch_ac_entry(item[entry_id], entry_node)
        end
    end
end


local function fetch_ac(item, node)
    item.smb_auth_req   = node.smb_auth_req.get_boolean()
    item.http_auth_req  = node.http_auth_req.get_boolean()

    fetch_ac_list(item.user, node.user.table)
    fetch_ac_list(item.group, node.group.table)
end


local function fetch_account_list(item, node)
    local id
    local na
    local ia

    for id, na in node.as_iter() do
        ia = item[id]
        ia.name         = na.name.get_string()
        ia.oper_status  = na.oper.get_boolean()
    end
end

function storage_folder_edit.fetch(conf, query, prvt, form)
    if prvt.deleted.as_boolean() then
        return
    end

    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()
    local storage   = mit.storage
    local unit      = storage.unit[query.unit.req_nonempty().get()]
    local ac        = storage.ac
    local node      = unit.fs.dir.table[query.folder.req_nonempty().get()]

    form.name       = node.name.get_string()
    form.path       = node.path.get_string()
    form.enabled    = node.enabled.get_boolean()
    form.strgpath   = node.get_path()
    form.sel_mediatype  = "none"
    
    fetch_volume(form.unit, unit)
    fetch_ac(form.ac, node.ac)
    fetch_account_list(form.user, ac.user.table)
    fetch_account_list(form.group, ac.group.table)

    fetch_mediatypes(form, mit.enum.mediapath_type, 
                     mit.dlna.mediapath.table)

    form.rescan = mit.dlna.rescan.get_boolean() or
                  mit.dlna.scanning.get_boolean()

    t:close()
end

return storage_folder_edit
