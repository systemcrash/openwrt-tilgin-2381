---
-- Storage setup WebUI module.
-- @release $Id: storage_setup.lua 170864 2015-01-05 18:41:59Z michael.kochkin $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local storage_setup     = {}
local webui_mods        = {}
webui_mods.storage      = {}
webui_mods.storage.tree = require("webui_mods.storage.tree")

local function apply_langroups(form, netif_table, dlna)    
    local id1, id2, fgroup, cgroup, is_used, should_be_used
    local group_selected, group_exist
    local has_changed = false;
      
    group_selected = false
    group_exist = false
    
    -- Add groups not already used
    for id1, fgroup in form.langroup.iter() do              
        if fgroup.as_number() == 1 then                 
            group_selected = true
            
            -- Check if this LAN group is already used
            is_used = false
            for id2, cgroup in netif_table.table.as_iter() do
                if cgroup.group.get_link() == id1 then
                    -- The group cgroup is already used by the DLNA server
                    is_used = true
                end            
            end
                 
            if not is_used then
                -- This LAN group should be added
                netif_table.add.exec({group = crm.value.link(id1)})                    
                has_changed = true
            end
        end
    end
 
    if not group_selected and form.admin.as_boolean() then
        -- At least one LAN group must be selected
        for id2, cgroup in netif_table.table.as_iter() do
             group_exist = true
             break
        end
        
        if not group_exist then
            dlna.admin.set_boolean(crm.value.boolean(false))
            form.admin = false
        end
        
        error(_("At least 1 LAN group must be selected for the DLNA Media server."))
    else
        -- Remove groups that are not used
        for id2, cgroup in netif_table.table.as_iter() do
            should_be_used = false
            
            for id1, fgroup in form.langroup.iter() do
                if cgroup.group.get_link() == id1 then
                    should_be_used = true
                end
            end
        
            if not should_be_used then
                -- This LAN group should be removed
                netif_table.del.exec({index = crm.value.u32(id2)})                    
                has_changed = true
            end 
        end
    end
    
end

function storage_setup.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()
    local storage   = mit.storage
    local f_http    = form.http.aka(
                            string.format(_("access via %s"), "HTTP"))
    local f_smb     = form.smb.aka(
                            string.format(_("access via %s"), "SMB"))
    local f_dlna    = form.dlna.aka(
                            string.format(_("access via %s"), "DLNA Media server"))
    local c_http    = mit.httpd.storage.aka(
                            string.format(_("access via %s"), "HTTP"))
    local c_https   = mit.httpd.storage_s.aka(
                            string.format(_("access via %s"), "HTTPS"))
    local c_smb     = mit.samba.aka(
                            string.format(_("access via %s"), "SMB"))
    local c_dlna    = mit.dlna.aka(
                            string.format(_("access via %s"), "DLNA Media server"))
    local c_langroup_table  = mit.lan.group.aka(_("LAN Groups"))
    local c_netif_table     = mit.dlna.lan.aka(_("DLNA Media server served LAN groups"))

    storage.service.admin.aka(_("administrative status")).
        set_boolean(form.admin.as_boolean())
    storage.http_services.auth_req.
        aka(_("HTTP authentication requirement status")).
            set_boolean(f_http.auth_req.as_boolean())

    c_http.admin.aka(_("administrative status")).
        set_boolean(f_http.admin.as_boolean())
    if c_https.exists() then
        c_https.admin.aka(_("administrative status")).
            set_boolean(f_http.admin.as_boolean())
    end

    if c_smb.exists() then
        c_smb.admin.aka(_("administrative status")).
            set_boolean(f_smb.admin.as_boolean())
        c_smb.workgroup.aka(_("workgroup")).
            set_string(f_smb.workgroup.aka(_("workgroup")).
                       req_nonblank().get())
        c_smb.netbios_name.aka(_("server name")).
            set_string(f_smb.netbios_name.aka(_("server name")).
                       req_nonblank().get())
        c_smb.server_string.aka(_("server description")).
            set_string(f_smb.server_string.aka(_("server description")).get())
    end

    c_dlna.admin.aka(_("administrative status")).
        set_boolean(f_dlna.admin.as_boolean())
    c_dlna.db_dir.aka(_("subdir")).
        set_string(f_dlna.subdir.aka(_("subdir")).get())
    c_dlna.name.aka(_("server name")).
        set_string(f_dlna.name.aka(_("server name")).req_nonblank().get())
    c_dlna.st_dir.aka(_("work directory")).
        set_link(webui_mods.storage.tree.get_path(f_dlna.storage))

    apply_langroups(f_dlna, c_netif_table, c_dlna)

    t:close()
end

local function fetch_langroups(form, langroup_table, netif_table)
    local id1, id2, group, netif
    local i = 1
    local j = 1
    form.available_langroup = {}
 
    -- Reset the checked parameters
    for id1, group in langroup_table.as_iter() do
        if group.managed_by.name.get_string() == "LAN" and group.visible() then
            form.available_langroup[i].checked = 0
            i = i + 1
        end
    end
    
    i = 1
    
    for id1, group in langroup_table.as_iter() do
        if group.managed_by.name.get_string() == "LAN" and group.visible() then
            form.available_langroup[i] = group.get_path()
            form.available_langroup[i].name = group.name.get_string()
            
            if tostring(form.available_langroup[i].name) == "" then
              form.available_langroup[i].name = _("unnamed").."/"..tostring(id1)
            end

            for id2, netif in netif_table.as_iter() do
               if netif.group.get_link() == group.get_path() then
                    form.available_langroup[i].checked = 1          
               end
            end
            
            i = i + 1
        end 
    end

end

function storage_setup.fetch(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_rw()
    local mit           = t:mit()
    local http          = mit.httpd.storage.aka(
                                string.format(_("access via %s"), "HTTP"))
    local smb           = mit.samba.aka(
                                string.format(_("access via %s"), "SMB"))
    local dlna          = mit.dlna.aka(
                                string.format(_("access via %s"), "DLNA Media server"))
    local extfs         = mit.extfs.aka(_("auxiliary software"))
    local langroup_table  = mit.lan.group.aka(_("LAN Groups"))
    local netif_table     = mit.dlna.lan.table.aka(_("DLNA Media server served LAN groups"))
    local scanning

    form.oper = mit.storage.service.oper.aka(_("operating status")).
                                                            get_boolean()
    form.admin = mit.storage.service.admin.aka(_("administrative status")).
                                                            get_boolean()
    if extfs.exists() and extfs.supported.get_boolean() then
        form.aux_sw_hosted = extfs.oper.aka(_("operating status")).
                                                        get_boolean()
    end

    form.http.auth_req = mit.storage.http_services.auth_req.
                         aka(_("HTTP authentication requirement status")).
                            get_boolean()
    form.http.oper = http.oper.aka(_("operating status")).
                            get_boolean()
    form.http.admin = http.admin.aka(_("administrative status")).
                            get_boolean()

    if smb.exists() then
        form.smb.oper = smb.oper.aka(_("operating status")).
                                get_boolean()
        form.smb.admin = smb.admin.aka(_("administrative status")).
                                get_boolean()
        form.smb.workgroup = smb.workgroup.aka(_("workgroup")).
                                get_string()
        form.smb.netbios_name = smb.netbios_name.aka(_("server name")).
                                    get_string()
        form.smb.server_string = smb.server_string.aka(_("server description")).
                                    get_string()
    end

    form.dlna.oper = dlna.oper.aka(_("operating status")).get_boolean()
    form.dlna.admin = dlna.admin.aka(_("administrative status")).
                        get_boolean()
    form.dlna.subdir = dlna.db_dir.aka(_("subdir")).get_string()
    form.dlna.name = dlna.name.aka(_("server name")).get_string()

    webui_mods.storage.tree.smmr(form.dlna.storage.create(), mit)
    webui_mods.storage.tree.slct(form.dlna.storage, dlna.st_dir.get_link())
 
    fetch_langroups(form.dlna, langroup_table, netif_table)
 
    form.scanning = mit.dlna.scanning.get_boolean()
 
    t:close()
end


return storage_setup
