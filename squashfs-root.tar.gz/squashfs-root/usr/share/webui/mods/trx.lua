---
-- Transceiver configuration and status WebUI module.
-- @release $Id:$
--

local crm   = require("webui.crm")
local hdf   = require("webui.hdf")
local trx   = {}


function trx.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()
    local port  = mit.port.WAN

    port.fb_tx_admin.aka(_("administrative status")).
        set_boolean(form.admin.as_boolean())

    t:close()
end


function trx.fetch(conf, query, prvt, form)
    local t     = crm.transaction():webui_open_ro()
    local mit   = t:mit()
    local port  = mit.port.WAN
    local prop  = port.prop.fiber

    form.admin = port.fb_tx_admin.aka(_("administrative status")).get_boolean()
    form.vendor_name = prop.vendor_name.aka(_("vendor")).get_string()
    form.part_number = prop.part_number.aka(_("part number")).get_string()
    form.temperature = prop.temperature.aka(_("temperature")).get_string()
    form.vcc = prop.vcc.aka(_("supply voltage")).get_string()
    form.tx_bias = prop.tx_bias.aka(_("TX bias current")).get_string()
    form.tx_power = prop.tx_power.aka(_("TX output power")).get_string()
    form.rx_power = prop.rx_power.aka(_("RX input power")).get_string()
    form.tx_fault = prop.tx_fault.aka(_("TX fault flag")).get_boolean()
    form.rx_los = prop.rx_los.aka(_("RX LOS flag")).get_boolean()

    t:close()
end


return trx
