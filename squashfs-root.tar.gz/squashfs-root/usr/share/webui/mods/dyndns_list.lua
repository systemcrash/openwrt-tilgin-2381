---
-- Dyndns records list WebUI module.
-- @release $Id:$
--

local crm               = require("webui.crm")
local dyndns_list       = {}

local server_list = {
    {
        name = "DynDNS", 
        url= "https://[USERNAME]:[PASSWORD]@members.dyndns.org/nic/update?hostname=[DOMAIN](&myip=[IP])",
        service_provider = "dyndns"
    },
    {
        name = "NoIP", 
        url = "https://[USERNAME]:[PASSWORD]@dynupdate.no-ip.com/nic/update?hostname=[DOMAIN](&myip=[IP])",
        service_provider = "noip"
    },
    {   
        name = "ChangeIP", 
        url = "https://[USERNAME]:[PASSWORD]@nic.changeip.com/nic/update?u=[USERNAME]&p=[PASSWORD]&cmd=update&hostname=[DOMAIN](&ip=[IP])",
        service_provider = "changeip"
    },
    {
        name = "DNSdynamic", 
        url = "https://[USERNAME]:[PASSWORD]@www.dnsdynamic.org/api/?hostname=[DOMAIN](&myip=[IP])",
        service_provider = "dnsdynamic"
    },
    {
        name = "EntryDNS",
        url = "https://entrydns.net/records/modify/[TOKEN](?ip=[IP])",
        service_provider = "entrydns"
    },
    {
        name = "DuckDNS",
        url = "https://www.duckdns.org/update?domains=[DOMAIN]&token=[TOKEN](&ip=[IP])",
        service_provider = "duckdns"
    }
}


function dyndns_list.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local dyndns    = t:mit().dyndns

    local id
    local h_rec

    for id, h_rec in form.record.iter() do
        local c_rec = dyndns.table[id]

        if c_rec.exists() then
            if h_rec.delete.as_boolean() then
                dyndns.del.exec(
                    {link = crm.value.link(c_rec.get_path())})
            elseif h_rec.renew.as_boolean() then
                c_rec.renew.aka(_("dyndns renew")).exec()
            else
                c_rec.admin.aka(_("administrative status")).
                    set_boolean(h_rec.admin.as_boolean())
            end
        end
    end

    t:close()
end

function dyndns_server_get_name(form, url)
    local itm_id
    local itm
    local new_itm
    local found = false
    for itm_id, itm in ipairs(server_list) do
        new_itm = form.dyndns_server[itm.service_provider].create()
        new_itm.name = itm.name
        new_itm.server = itm.url
        if url == itm.url then
            return itm.name
        end
    end
    return _("Custom")
end 

function dyndns_list.fetch(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_ro()
    local mit           = t:mit()
    local id
    local node
    local item

    for id, node in mit.dyndns.table.as_iter() do
        item = form.record[id].create()
        item.friendlyname = node.friendlyname.get_string()
        item.hostname     = node.hostname.get_string()
        item.service_provider = dyndns_server_get_name(form, node.server.get_string())
        item.oper         = node.oper.get_boolean()
        item.admin        = node.admin.get_boolean()
    end

    t:close()
end


return dyndns_list
