---
-- Certificate generation page module.
-- @release $Id:$
--
local crm   = require("webui.crm")
local webui_mods        = {}

local certificates_gen     = {}

local months_list = {
    {name = "January", index = 1, days = 31},
    {name = "February", index = 2, days = 28},
    {name = "March", index = 3, days = 31},
    {name = "April", index = 4, days = 30},
    {name = "May", index = 5, days = 31},
    {name = "June", index = 6, days = 30},
    {name = "July", index = 7, days = 31},
    {name = "August", index = 8, days = 30},
    {name = "September", index = 9, days = 31},
    {name = "October", index = 10, days = 30},
    {name = "November", index = 11, days = 30},
    {name = "December", index = 12, days = 31},
}

function check_date(day, month, year)
    local days_in_current_month
    if month < 1 or month > 12 then
        return false
    end
    days_in_current_month = months_list[month].days
    if month == 2 then
        -- check for leap years
        if (year % 100)  == 0 or (year % 4) == 0 then
            days_in_current_month = 29
        end
    end
    if day < 1 or day > days_in_current_month then
        return false
    end
    if year > 2099 or year < 1970 then
        return false
    end        
    return true
end

function is_power_of_two(num)
    local tmp = 1
    while tmp <= num do
        if tmp == num then
            return true
        end
        tmp = tmp * 2
    end
    return false
end

function safelen(str)
    if str == nil then
        return 0
    end
    return string.len(str)
end

function certificates_gen.apply(conf, query, form, prvt)
    local t                 = crm.transaction():webui_open_rw()
    local root              = t:mit().security.certificate

    local encryption_
    local sign_ = form.sign.as_boolean()
    local name_ = form.name.get()
    local password_ = form.password.get()
    local numbits_ = tonumber(form.numbits.get())

    if name_ == nil or name == "" then
        error(_("Invalid name"))
    end 
    local startdate_day = tonumber(form.startdate_day.get())
    local startdate_month = tonumber(form.startdate_month.get())
    local startdate_year = tonumber(form.startdate_year.get())

    local enddate_day = tonumber(form.enddate_day.get())
    local enddate_month = tonumber(form.enddate_month.get())
    local enddate_year = tonumber(form.enddate_year.get())

    --numbits sanity check
    if numbits_ < 512 or is_power_of_two(numbits_) == false then
        error(_("Number of bits should be a power of 2"))
    end

    --date sanity check
    if check_date(startdate_day, startdate_month, startdate_year) == false or 
        check_date(enddate_day, enddate_month, enddate_year) == false then
        error(_("Invalid validity period"))
    end

    local startdate_ = string.format(_("%04d%02d%02d000000Z"), startdate_year, startdate_month, startdate_day)
    local enddate_ = string.format(_("%04d%02d%02d000000Z"), enddate_year, enddate_month, enddate_day)

    local serial_ = form.serial.get()
    local countryName_ = form.countryName.get()
    local stateOrProvinceName_ = form.stateOrProvinceName.get()
    local localityName_ = form.localityName.get()
    local organizationName_ = form.organizationName.get()
    local organizationalUnitName_ = form.organizationalUnitName.get()
    local commonName_ = form.commonName.get()
    local emailAddress_ = form.emailAddress.get()

    if safelen(countryName_) == 0 or safelen(stateOrProvinceName_) == 0 or 
        safelen(localityName_) == 0 or safelen(organizationName_) == 0 or 
        safelen(organizationalUnitName_) == 0 or safelen(commonName_) == 0 or 
        safelen(emailAddress_) == 0 then
        error(_("One or more mandatory fields are empty"))
    end

    if safelen(password_) == 0 then
        encryption_ = "none"
    else
        encryption_ = "des3"
    end

    local id = form.cacert.get()
    local calink 
    if safelen(id) == 0 then
        calink = nil
    else
        calink = crm.value.link("/security/certificate/store/table/" .. id)
    end
    root.gen_certificate.aka(_("Generate certificate")).exec(
    {
        sign = crm.value.boolean(sign_),
        ca = calink,
        name = crm.value.string(name_),
        password = crm.value.string(password_),
        encryption = crm.value.string(encryption_),
        numbits = crm.value.u32(numbits_),
        startdate = crm.value.string(startdate_),
        enddate = crm.value.string(enddate_),
        serial = crm.value.string(serial_),
        countryName = crm.value.string(countryName_),
        stateOrProvinceName = crm.value.string(stateOrProvinceName_),
        localityName = crm.value.string(localityName_),
        organizationName = crm.value.string(organizationName_),
        organizationalUnitName = crm.value.string(organizationalUnitName_),
        commonName = crm.value.string(commonName_),
        emailAddress = crm.value.string(emailAddress_)
    })

    t:close()
end

function certificates_gen.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local root              = t:mit().security.certificate
    local item
    local id
    local node
    local h_months_list     = form.months.create()
    local mon_id
    local mon

    for id, node in root.store.table.as_iter() do
        item = form.cacert[id].create()
        item.name = node.name.get_string()
    end

    form.cacert = ""

    for mon_id, mon in ipairs(months_list) do
        h_months_list[tostring(mon.index)] = mon.name
    end

    t:close()
end

return certificates_gen
