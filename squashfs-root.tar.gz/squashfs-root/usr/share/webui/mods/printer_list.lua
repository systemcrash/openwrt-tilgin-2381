---
-- Printer list WebUI module.
-- @release $Id: printer_list.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm           = require("webui.crm")
local hdf           = require("webui.hdf")
local printer_list  = {}

local function apply_printer(c_printer, h_printer)
    c_printer.admin.aka(_("administrative status")).set_boolean(
                                            h_printer.admin.as_boolean())
    c_printer.name.aka(_("name")).set_string(
        h_printer.name.aka(_("name")).
            req_regex(_("non-empty string of " ..
                        "alphanumeric or national characters, " ..
                        "spaces, underscores, dashes, or number signs"),
                      "^[%w\128-\255 _#%-]+$"))
    c_printer.port.aka(_("port")).set_u16(
                                    h_printer.port.aka(_("port")).
                                                   req_range(9100, 9115))
end


function printer_list.apply(conf, query, form, prvt)
    local t                 = crm.transaction():webui_open_rw()
    local printer_table     = t:mit().printing.printer
    local c_printer_list    = printer_table.table.iaka(_("printer #%s"))
    local h_printer_list    = form.printer.iaka(_("printer #%s"))

    for printer_id, h_printer in h_printer_list.iter() do
        if h_printer.delete.as_boolean() then
            printer_table.del.aka(_("delete printer")).
                            exec({index = crm.value.u32(printer_id)})
        else
            apply_printer(c_printer_list[printer_id], h_printer)
        end
    end

    t:close()
end


local function fetch_printer(h_printer, c_printer)
    local type

    h_printer.connected = c_printer.lp_device.
                            aka(_("printer device file path")).
                            get_string():len() > 0
    h_printer.oper = c_printer.oper.aka(_("operating status")).get_boolean()
    h_printer.admin = c_printer.admin.aka(_("administrative status")).
                                        get_boolean()

    h_printer.name = c_printer.name.aka(_("name")).get_string()
    h_printer.port = c_printer.port.aka(_("port")).as_string()

    type = c_printer["."].type.aka(_("type")).get_string()
    h_printer.type = type
    if (type == "usb_printer") then
        h_printer.manufacturer = c_printer.manufacturer.
                                    aka(_("manufacturer")).get_string()
        h_printer.product = c_printer.product.
                                    aka(_("product name")).get_string()
        h_printer.serialnumber = c_printer.serialnumber.
                                    aka(_("serial number")).get_string()
    end
end


function printer_list.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local c_printer_list    = t:mit().printing.printer.table.
                                                    iaka(_("printer #%s"))

    for printer_id, c_printer in c_printer_list.as_iter() do
        fetch_printer(form.printer[printer_id].create(), c_printer)
    end

    t:close()
end


return printer_list
