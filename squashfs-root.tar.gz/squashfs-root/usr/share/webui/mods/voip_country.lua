---
-- VoIP country WebUI module.
-- release $Id:$
--
local crm   = require("webui.crm")
local voip_country = {}

function voip_country.apply(conf, query, form, prvt)
    local t                 = crm.transaction():webui_open_rw()
    local pm_table          = t:mit().recon.pm.table

    pm_table.Country.set_string(form.country.get())
    pm_table.Polarity_Reversal.set_string(
                        form.polarity.as_boolean() and "1" or "0")
     
    t:close()
end

function voip_country.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local pm_table  = mit.recon.pm.table

    local list, id, node

    form.country = pm_table.Country.get_string()
    form.polarity = pm_table.Polarity_Reversal.get_string() == "1"

    list = form.voip_country_list.create()
    for id, node in mit.pm.factory.country.as_iter() do
        list[id].name = node.get_string()
    end

    t:close()
end

return voip_country
