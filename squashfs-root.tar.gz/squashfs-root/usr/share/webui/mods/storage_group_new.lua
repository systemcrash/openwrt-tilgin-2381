---
-- Storage group creating WebUI module.
-- @release $Id: storage_group_new.lua 134347 2009-06-04 10:16:41Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local req               = require("webui_mods.storage.account").req
local storage_group_new = {}


function storage_group_new.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local ac        = t:mit().storage.ac
    local name
    local index
    local group
    local ok, e

    name        = req.name(form.name.aka(_("name"))).get()

    index = ac.group.add.exec({}, {"index"})
    group = ac.group.table[index:as_string()]

    ok, e = pcall(function ()
        group.name.aka(_("name")).set_string(name)
        group.admin.aka(_("administrative status")).set_boolean(true)
    end)

    if not ok then
        ac.group.del.exec({index = index}, {})
        error(e)
    end

    t:close()
end


return storage_group_new



