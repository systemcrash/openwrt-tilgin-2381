---
-- Switch filter editing WebUI module.
-- @release $Id: switch_filter_edit.lua 138138 2009-09-11 16:13:42Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local webui_mods        = {}
webui_mods.switch       = {}
webui_mods.switch.filter     = require("webui_mods.switch.filter")

local switch_filter_edit = {}

local function get_id_and_filter(mit, query)
    local filter_id   = query.filter.req_range(1, 2147483647).  -- 1-INT32_MAX
                                                        get()
    local c_filter    = mit.ethernet.switch.super.filter.table[filter_id]

    if not c_filter.exists() or
       not webui_mods.switch.filter.match(c_filter) then
       error(_("filter not found"))
    end

    return filter_id, c_filter
end


function switch_filter_edit.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()

    local filter_id, c_filter   = get_id_and_filter(mit, query)

    if form.delete.as_boolean() then
        mit.ethernet.switch.super.filter.del.aka(_("delete")).
            exec({index = crm.value.u32(filter_id)})
        prvt.deleted = true
    else
        webui_mods.switch.filter.apply(c_filter, form)
    end

    t:close()
end


function switch_filter_edit.fetch(conf, query, prvt, form)
    if prvt.deleted.as_boolean() then
        return
    end

    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()

    local filter_id, c_filter   = get_id_and_filter(mit, query)

    webui_mods.switch.filter.fetch(form, c_filter)

    t:close()
end


return switch_filter_edit
