---
-- Terminal equipment PLMN setup WebUI module.
-- @release $Id:$
--

local crm   = require("webui.crm")
local te_plmn = {}

local function refresh(crm, trans, te_node)
    local result    = nil

    te_node.present.sync.name.subscribe_change(
        nil, 2000,
        function (mapi, path, old, new)
            if (new:get_string() == "ok") then
                result = true
            elseif (new:get_string() == "failed") then
                result = false
            end
        end)

    te_node.present.refresh.exec()
    trans:close()

    repeat
        crm.handle_events()
    until result ~= nil

    if not result then
        error(_("Refresh failed"))
    end
end

function te_plmn.apply(conf, query, form, prvt)
    local t             = crm.transaction():webui_open_rw()
    local mit           = t:mit()
    local usb_upper     = mit.port.USB.upper
    local upper_id
    local node
    local mode_admin
    local action

    upper_id = query.id.get()
    if not upper_id then
        error(_("Failed to get interface id"))
    end

    node = usb_upper[upper_id].iface.prop.te.link.plmn

    action = form.action.get()
    if action == "refresh" then
        refresh(crm, t, node)
        return
    elseif action == "deregister" then
        node.mode_admin.aka(_("mode admin")).set_string("dereg")
        t:close()
        return
    end

    mode_admin = form.mode_admin.get()
    if mode_admin == "manual" then
        if form.manual_auto.as_boolean() then
            mode_admin = "manual_auto"
        end
        
        for id, op in form.op_list.iter() do
            if op.selected then
                node.name_admin.aka(_("operator name")).set_string(op.selected.get())
                node.format_admin.aka(_("format admin")).set_string("numeric")
            end
        end
    end

    if mode_admin then
        node.mode_admin.aka(_("mode admin")).set_string(mode_admin)
    end

    -- We don't need to submit these settings in case of get_list
    if action ~= "get_list" then
        node.act_choice_admin.aka(_("act_choice admin")).set_string(
                        form.act_choice_admin.aka(_("act_choice admin")).get())
        node.roaming_allowed.aka(_("roaming allowed")).set_boolean(
                        form.roaming_allowed.aka(_("roaming allowed")).as_boolean())
    end

    if mode_admin == "manual" or mode_admin == "manual_auto" then
        if node.present.sync.name.aka(_("sync")).get_string() ~= "ok" then
            refresh(crm, t, node)
            return
        end
    end

    t:close()
end


function te_plmn.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local usb_upper         = mit.port.USB.upper
    local upper_id
    local node
    local h_mode_list
    local h_op_list
    local h_act_choice_list
    local manual_auto       = false
    local mode_admin
    local rssi

    upper_id = query.id.get()
    if not upper_id then
        error(_("Failed to get interface id"))
    end

    node                = usb_upper[upper_id].iface.prop.te.link.plmn
    h_mode_list         = form.te_plmn_mode.create()
    h_act_choice_list   = form.te_act_choice.create()
    h_op_list           = form.op_list.create()

    -- Fetching enums
    for id, c_node in
        mit.enum.te_plmn_mode.aka(_("PLMN modes")).as_iter() do
            local h_node = h_mode_list[c_node.value.as_string()].create()
        
            h_node.name = c_node.name.get_string()
    end

    for id, c_node in
        mit.enum.te_act_choice.aka(_("act_choice")).as_iter() do
            local h_node = h_act_choice_list[c_node.value.as_string()].create()
        
            h_node.name = c_node.name.get_string()
    end

    -- Get operative info
    form.numeric_oper = node.numeric_oper.aka(_("numeric oper")).get_string()
    form.long_oper    = node.long_oper.aka(_("long oper")).get_string()
    form.mode_oper    = node.mode_oper.name.aka(_("mode oper")).get_string()
    form.reg_status   = node.reg_status.name.aka(_("registration status")).get_string()
    form.lac          = node.lac.aka(_("lac")).as_string()
    form.cell_id      = node.cell_id.aka(_("cell id")).as_string()

    rssi              = node.rssi.aka(_("rssi")).get_s8()
    if rssi ~= -1 then
        rssi = rssi * 100 / 31
    end
    form.rssi = rssi

    form.access_tech  = node.access_tech.name.aka(_("access_tech")).get_string()

    form.act_choice_oper  = node.act_choice_oper.name.
                                aka(_("act_choice_oper")).get_string()
    form.act_choice_admin  = node.act_choice_admin.name.
                                aka(_("act_choice_admin")).get_string()

    form.roaming_allowed = node.roaming_allowed.get_boolean()

    -- Parse operators
    mode_admin = node.mode_admin.name.aka(_("admin oper")).get_string()

    if mode_admin == "manual_auto" then
        manual_auto = true
        mode_admin = "manual"
    end

    form.mode_admin = mode_admin

    if mode_admin == "manual" then
        -- In some states oper could be empty, so fetch it from admin 
        if #form.numeric_oper == 0 and #form.long_oper == 0 then
            form.numeric_oper = node.name_admin.aka(_("name_admin")).get_string()
        end

        form.manual_auto = manual_auto

        -- Fetching operators list
        for id, c_node in
            node.present.list.aka(_("Available operators")).as_iter() do
                local h_node = h_op_list[id].create()
            
                h_node.numeric      = c_node.numeric.get_string()
                h_node.long         = c_node.long.get_string()
                h_node.access_tech  = c_node.access_tech.name.get_string()
                h_node.stat         = c_node.stat.name.get_string()
        end
    end

    t:close()
end


return te_plmn
