---
-- Storage user list WebUI module.
-- @release $Id: storage_user_list.lua 162075 2012-11-27 23:49:44Z marina.maslova $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local req               = require("webui_mods.storage.account").req
local storage_user_list = {}


local function apply_account(ac, c_account, h_account)
    local id
    local group
    local password = h_account.password.aka(_("password")).get()
    local hidd_password = h_account.hidd_password.
                            aka(_("hidden password")).get()

    c_account.name.aka(_("name")).
        set_string(req.name(h_account.name.aka(_("name"))).get())

    if password ~= hidd_password then
        c_account.password.aka(_("password")).
            set_string(req.password(h_account.password).get())
    end
    c_account.admin.aka(_("administrative status")).
        set_boolean(h_account.admin_status.as_boolean())
    c_account.allow_http_access.
        set_boolean(h_account.allow_http_access.as_boolean())
    c_account.allow_smb_access.
        set_boolean(h_account.allow_smb_access.as_boolean())

    for id, group in h_account.group.iter() do
        if group.selected.as_boolean() then
            c_account.del_group.exec(
                {group = crm.value.link(ac.group.table[id].get_path())})
        end
    end

    for id, group in h_account.new_group.iter() do
        if group.selected.as_boolean() then
            c_account.add_group.exec(
                {group = crm.value.link(ac.group.table[id].get_path())})
        end
    end
end


function storage_user_list.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local ac        = t:mit().storage.ac

    local id
    local h_account

    for id, h_account in form.account.iter() do
        local c_account = ac.user.table[id]

        if c_account.exists() then
            if h_account.delete.as_boolean() then
                ac.user.del.exec(
                    {link = crm.value.link(c_account.get_path())})
            else
                apply_account(ac, c_account, h_account)
            end
        end
    end

    t:close()
end


local function fetch_user_group_list(item, node)
    local id
    local group

    for id, group in node.as_iter() do
        item[group.deref().get_name()] = ""
    end
end


local function fetch_account_list(item, node)
    local id
    local na
    local ia

    for id, na in node.as_iter() do
        ia = item[id]
        ia.name         = na.name.get_string()
        ia.oper_status  = na.oper.get_boolean()
    end
end


function storage_user_list.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_rw()
    local ac        = t:mit().storage.ac
    local id
    local node
    local item

    for id, node in ac.user.table.as_iter() do
        item = form.account[id].create()

        item.name               = node.name.get_string()
        item.password           = string.gsub(tostring(node.password.get_string()),
                                              "(.)", function(a) return '*' end)
        item.oper_status        = node.oper.get_boolean()
        item.admin_status       = node.admin.get_boolean()
        item.allow_http_access  = node.allow_http_access.get_boolean()
        item.allow_smb_access   = node.allow_smb_access.get_boolean()

        fetch_user_group_list(item.group, node.group)
    end

    fetch_account_list(form.group, ac.group.table)

    t:close()
end


return storage_user_list
