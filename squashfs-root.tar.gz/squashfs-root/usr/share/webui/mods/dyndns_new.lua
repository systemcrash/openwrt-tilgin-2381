---
-- Dyndns creating WebUI module.
-- @release $Id: $
--

local crm               = require("webui.crm")
local dyndns_new        = {}

function dyndns_new.apply(conf, query, form, prvt)
    local t        = crm.transaction():webui_open_rw()
    local dyndns   = t:mit().dyndns
    local friendlyname 
    local server_type
    local url
    local index
    local rec, ok, e

    form.friendlyname.req_nonempty()

    friendlyname = form.friendlyname.aka(_("friendlyname")).get()

    server_type = form.server.type.get()
    if server_type == "wellknown" then
        url = form.server.wellknown.aka(_("server wellknown")).get()
    elseif server_type == "custom" then
        url = form.server.custom.aka(_("server custom")).get()
    elseif server_type == "" then
        error(_("Server type is not set"))
    else
        error(_("Invalid server type"))
    end

    index = dyndns.add.aka(_("create")).exec(
        {
            friendlyname = crm.value.string(friendlyname),
            server = crm.value.string(url)
        }, 
        {
            "index"
        }
    )
    rec = dyndns.table[index:as_string()]

    ok, e = pcall(function ()
        rec.friendlyname.aka(_("name")).set_string(friendlyname)
        rec.server.aka(_("server")).set_string(url)
        rec.admin.aka(_("administrative status")).set_boolean(false)
    end)

    if not ok then
        dyndns.del.exec({index = index}, {})
        error(e)
    end

    prvt.id = index:as_string()

    t:close()
end

local server_list = {
    {
        name = "DynDNS", 
        url= "https://[USERNAME]:[PASSWORD]@members.dyndns.org/nic/update?hostname=[DOMAIN](&myip=[IP])",
        service_provider = "dyndns"
    },
    {
        name = "NoIP", 
        url = "https://[USERNAME]:[PASSWORD]@dynupdate.no-ip.com/nic/update?hostname=[DOMAIN](&myip=[IP])",
        service_provider = "noip"
    },
    {   
        name = "ChangeIP", 
        url = "https://[USERNAME]:[PASSWORD]@nic.changeip.com/nic/update?u=[USERNAME]&p=[PASSWORD]&cmd=update&hostname=[DOMAIN](&ip=[IP])",
        service_provider = "changeip"
    },
    {
        name = "DNSdynamic", 
        url = "https://[USERNAME]:[PASSWORD]@www.dnsdynamic.org/api/?hostname=[DOMAIN](&myip=[IP])",
        service_provider = "dnsdynamic"
    },
    {
        name = "EntryDNS",
        url = "https://entrydns.net/records/modify/[TOKEN](?ip=[IP])",
        service_provider = "entrydns"
    },
    {
        name = "DuckDNS",
        url = "https://www.duckdns.org/update?domains=[DOMAIN]&token=[TOKEN](&ip=[IP])",
        service_provider = "duckdns"
    }
}

function dyndns_server_fetch(form)
    local itm_id
    local itm
    local new_itm
    for itm_id, itm in ipairs(server_list) do
        new_itm = form.dyndns_server[itm.service_provider].create()
        new_itm.name = itm.name
        new_itm.server = itm.url
    end
end 

function dyndns_new.fetch(conf, query, prvt, form)
    form.created_id = prvt.id

    dyndns_server_fetch(form)
end

return dyndns_new

