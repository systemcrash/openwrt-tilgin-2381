---
-- Storage volume list WebUI module.
-- @release $Id: storage_volumes.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local int               = require("webui.int")
local storage_volumes   = {}


function storage_volumes.apply_fs(d, s)
    d.mount_admin = s.mount_admin.as_crm_boolean()
    d.manage_dirs = s.manage_dirs.as_crm_boolean()
end


function storage_volumes.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()
    local id
    local node
    local item

    for id, item in form.unit.iter() do
        node = mit.storage.unit[id]

        if node.mountable.get_boolean() then
            local new_admin
            local new_name
            local old_name

            new_admin = item.admin.aka(_("administrative status")).
                                                    as_boolean()

            new_name = tostring(item.new_name.aka(_("name")).
                                req_nonblank())

            if not new_admin then
                node.admin.aka(_("administrative status")).
                    set_boolean(false)
            end

            old_name = node.name.aka(_("name")).get_string()
            -- If name is updated
            if new_name ~= old_name then
                -- Unmount volume
                node.fs.mount_admin.set_boolean(false)
                -- Set name
                node.name.aka(_("name")).set_string(new_name)
            end

            storage_volumes.apply_fs(node.fs, item.fs)

            if new_admin then
                node.admin.aka(_("administrative status")).
                    set_boolean(true)
            end

        end
    end

    t:close()
end


local function fetch_device_list(device_list, unit)
    if unit.instanceof("st_media") then
        local device = device_list[unit["."].index.as_string()].create()

        device.name         = unit.name.get_string()
        device.ejected      = unit.ejected.get_boolean()
        device.connected    = unit.connected.get_boolean()
        device.oper         = unit.oper.get_boolean()
        device.type         = "device"
    else
        local lower_id
        local lower_unit

        for lower_id, lower_unit in unit.lower.as_iter() do
            fetch_device_list(device_list, lower_unit.deref())
        end
    end
end


local function fetch_fs(d, s)
    local size
    local used

    d.type = s.type.name.get_string()

    size = s.size.get_int_u64()
    used = s.used.get_int_u64()

    d.size.value, d.size.unit = size:decimal_scaled_bytes()
    d.used.value, d.used.unit = used:decimal_scaled_bytes()
    d.free.value, d.free.unit = (size - used):decimal_scaled_bytes()

    d.mount_oper    = s.mount_oper.get_boolean()
    d.mount_admin   = s.mount_admin.get_boolean()
    d.manage_dirs   = s.manage_dirs.get_boolean()
end


local function fetch_volume(item, node)
    local name
    local oper

    name = node.name.aka(_("name")).get_string()
    item.aka(string.format("\"%s\"", name))

    item.name       = name
    item.new_name   = name
    item.admin      = node.admin.aka(_("administrative status")).
                                                    get_boolean()
    item.connected  = node.connected.aka(_("connection status")).
                                                    get_boolean()

    oper            = node.oper.aka(_("operating status")).
                                                    get_boolean()
    item.oper       = oper

    fetch_device_list(item.device.create(), node)

    if oper then
        item.capacity.value, item.capacity.unit =
            node.capacity.aka(_("capacity")).
                get_int_u64():decimal_scaled_bytes()
    end

    fetch_fs(item.fs.create(), node.fs)
end


local function select_aux_sw_volume(unit_list, extfs)
    if extfs.oper.aka(_("operating status")).get_boolean() then
        local unit = extfs.storage_unit.aka(_("storage volume"))
        if unit.deref() and unit.exists() then
            unit_list[unit.get_name()].aux_sw_hosted = true
        end
    end
end


function storage_volumes.fetch(conf, query, prvt, form)
    local t     = crm.transaction():webui_open_ro()
    local mit   = t:mit()
    local extfs = mit.extfs.aka(_("auxiliary software"))
    local id
    local node

    for id, node in mit.storage.unit.aka(_("unit set")).
                                     iaka(_("unit #%s")).as_iter() do
        if node.mountable.get_boolean() then
            fetch_volume(form.unit[id].create(), node)
        end
    end

    if extfs.exists() and extfs.supported.get_boolean() then
        select_aux_sw_volume(form.unit, extfs)
    end

    t:close()
end


return storage_volumes
