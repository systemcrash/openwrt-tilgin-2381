---
-- Wireless discovered AP list WebUI module.
-- @release $Id: qos_flow_list.lua 138178 2009-09-15 16:41:26Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local int               = require("webui.int")

local wireless_ap_list = {}


function wireless_ap_list.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()
    local count     = 0 
    local res_count = 0 
    local result    = true

    local dev_id, dev

    for dev_id, dev in mit.wlan.device.
                        aka(_("WLAN device set")).as_iter() do
        local cport = dev.radio[1].port

        count = count + 1
        cport.ap.status.name.subscribe_change(
            nil, 2000,
            function (mapi, path, old, new)
                if (new:get_string() == "READY") then
                    res_count = res_count + 1
                elseif (new:get_string() == "FAILED") then
                    result = false
                    res_count = res_count + 1
                end
            end)

        cport.ap.refresh.aka(_("refresh")).exec()
    end

    t:close()

    repeat
        crm.handle_events()
    until res_count == count

    if not result then
        error(_("Scan failed"))
    end
end


local function fetch_ap(h_ap, c_ap)
    local qual
    local qual_max

    h_ap.ssid       = c_ap.ssid.aka(_("SSID")).get_string()
    h_ap.channel    = c_ap.channel.aka(_("channel")).as_string()
    h_ap.enc        = c_ap.enc.aka(_("encryption flag")).get_boolean()
    qual            = c_ap.qual.aka(_("quality value")).get_int_u32()
    qual_max        = c_ap.qual_max.aka(_("quality range")).get_int_u32()
    h_ap.quality    = qual * 100 / qual_max
    h_ap.level      = c_ap.level.aka(_("signal level")).get_s16()
end


function wireless_ap_list.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local ap_count  = 0

    local wp_list, dev_id, dev, cport, hport

    form.age = nil
    wp_list = form.wp_list.create()
    for dev_id, dev in mit.wlan.device.
                        aka(_("WLAN device set")).as_iter() do
        cport = dev.radio[1].port
        
        if cport.ap.exists() then
            local h_ap_list, ap_id, c_ap
            local uptime

            hport = wp_list[dev_id].create()
            hport.name = dev.radio[1].frequency_band.
                        aka(_("WLAN port frequency bandwith")).get_string()

            hport.status = cport.ap.status.name.
                            aka(_("refresh status")).get_string()

            uptime = cport.ap.uptime.
                        aka(_("last refresh uptime")).get_int_u32()
            if uptime ~= int.u32(0) then
                form.age = mit.system.uptime.
                            aka(_("system uptime")).get_int_u32() - uptime
            end

            h_ap_list = hport.ap.create()
            for ap_id, c_ap in cport.ap.table.
                            aka(_("access point set")).
                            iaka("access point #%s").as_iter() do
                fetch_ap(h_ap_list[ap_id].create(), c_ap)
                ap_count = ap_count + 1
            end

            h_ap_list.sort(function (a, b)
                            local a_ssid    = a.ssid.get()
                            local b_ssid    = b.ssid.get()

                            return (a_ssid > b_ssid)
                                    and 1
                                    or (a_ssid < b_ssid)
                                        and -1
                                        or 0
                           end)
        end
    end

    form.ap_count = ap_count

    t:close()
end


return wireless_ap_list

