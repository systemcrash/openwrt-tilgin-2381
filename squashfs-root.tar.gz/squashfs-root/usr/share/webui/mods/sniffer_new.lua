---
-- Sniffer creating WebUI module.
-- @release $Id: sniffer_new.lua 134347 2009-06-04 10:16:41Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local sniffer_new  = {}


function sniffer_new.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local sniffer   = t:mit().sniffer
    local name
    local index

    name = form.name.aka(_("name")).get()

    index = sniffer.add.aka(_("create")).exec({}, {"index"})

    sniffer.table[index:as_string()].label.aka(_("name")).set_string(name)

    t:close()
end


return sniffer_new


