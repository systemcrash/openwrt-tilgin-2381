---
-- Default connection confirmation WebUI module.
-- @release $Id:$
--

local crm                   = require("webui.crm")

local conn_default_confirm = {}

function conn_default_confirm.fetch(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_ro()
    local mit           = t:mit()
    local def_conn       = mit.connection.fallback.ppool.default.current.
                            aka(_("default connection"))
    local def_conn_path  = def_conn.get_link()

    local def_conn_present   = (#def_conn_path > 0)

    form.def_conn_present = def_conn_present
    if def_conn_present then
        local def_pool_path = def_conn_path:match("^(.*)/current$")

        -- If the connection link is valid
        if def_conn.status.name.aka(_("status")).exists() then
            local def_conn_realpath = t:realpath(def_conn_path)
            local def_dev_id, def_conn_id =
                    def_conn_realpath:match(
                        "^/connection/device/table/([^/]+)" ..
                        "/configured/([^/]+)")

            if def_dev_id and def_conn_id then
                form.def_dev_id = def_dev_id
                form.def_conn_id = def_conn_id
                form.def_conn_name = def_conn.name.
                            aka(_("connection name")).get_string()
            else
                error(_("Invalid connection path \"%s\""):
                        format(def_conn_realpath))
            end
        end
    end

    t:close()

end

function conn_default_confirm.apply(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_rw()
    local mit           = t:mit()

    mit.connection.default.confirm.aka("confirm").exec()
    t:close()
end

return conn_default_confirm
