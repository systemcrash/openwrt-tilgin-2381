---
-- Printer queue list WebUI module.
-- @release $Id: printer_queue_list.lua 145294 2010-04-02 13:27:37Z nikolai.kondrashov $
--

local int           = require("webui.int")
local crm           = require("webui.crm")
local hdf           = require("webui.hdf")
local printer_queue_list  = {}


local function apply_unspooler(c_unspooler, h_unspooler)
    c_unspooler.paused.aka(_("\"paused\" flag")).
                       set_boolean(h_unspooler.paused.as_boolean())
end


local function apply_queue(c_queue, h_job_list)
    local c_job_list    = c_queue.table.aka(_("job list")).
                                        iaka(_("job #%s"))
    for job_id, h_job in h_job_list.iter() do
        local c_job = c_job_list[job_id]

        if h_job.delete.as_boolean() then
            c_queue.del.aka(_("delete job")).
                        exec{index = crm.value.u32(job_id)}
        else
            c_job.held.aka(_("\"held\" flag")).
                       set_boolean(h_job.held.as_boolean())
        end
    end
end


local function purge_queue(c_queue)
    local c_job_list    = c_queue.table.aka(_("job list")).
                                        iaka(_("job #%s"))
    for job_id, c_job in c_job_list.as_iter() do
        c_queue.del.aka(_("delete job")).exec{index = crm.value.u32(job_id)}
    end
end


local function apply_printer(c_printer, h_printer)
    local c_queue = c_printer.queue.aka(_("queue"))
    if h_printer.purge.as_boolean() then
        purge_queue(c_queue)
    else
        apply_queue(c_queue, h_printer.job.aka(_("job list")))
        apply_unspooler(c_printer.unspooler.aka(_("unspooler")),
                        h_printer.unspooler.aka(_("unspooler")))
    end
end


function printer_queue_list.apply(conf, query, form, prvt)
    local t                 = crm.transaction():webui_open_rw()
    local printer_table     = t:mit().printing.printer
    local c_printer_list    = printer_table.table.iaka(_("printer #%s"))
    local h_printer_list    = form.printer.iaka(_("printer #%s"))

    for printer_id, h_printer in h_printer_list.iter() do
        apply_printer(c_printer_list[printer_id], h_printer)
    end

    t:close()
end


local function fetch_unspooler(time, uptime, h_unspooler, c_unspooler)
    local age = uptime - c_unspooler.uptime.get_int_u32()

    h_unspooler.paused = c_unspooler.paused.aka(_("\"paused\" flag")).
                                            get_boolean()
    h_unspooler.job_id = c_unspooler.job_id.aka(_("job ID")).as_string()
    h_unspooler.started =
        os.date((age > int.u32(60 * 60 * 24)) and "%x" or "%X",
                tostring(time - age))
end


local function fetch_job(time, uptime, h_job, c_job)
    local age = uptime - c_job.uptime.get_int_u32()

    h_job.name  = c_job.name.aka(_("name")).get_string()
    h_job.prio  = c_job.prio.aka(_("priority")).as_string()
    h_job.user  = c_job.user.aka(_("user")).get_string()
    h_job.held  = c_job.held.aka(_("\"held\" flag")).get_boolean()
    h_job.size.value, h_job.size.unit =
        c_job.size.aka(_("size")).get_int_u64():binary_scaled_bytes()
    h_job.submitted =
        os.date((age > int.u32(60 * 60 * 24)) and "%x" or "%X",
                tostring(time - age))
end


local function fetch_job_list(time, uptime, h_job_list, c_job_list)
    for job_id, c_job in c_job_list.as_iter() do
        fetch_job(time, uptime, h_job_list[job_id].create(), c_job)
    end
    h_job_list.sort(function (a, b)
                        local a_prio    = tonumber(a.prio.get())
                        local b_prio    = tonumber(b.prio.get())

                        return (a_prio > b_prio)
                                and 1
                                or (a_prio < b_prio)
                                    and -1
                                    or 0
                    end)
end


local function fetch_printer(time, uptime, h_printer, c_printer)
    h_printer.name = c_printer.name.aka(_("name")).get_string()
    fetch_unspooler(time, uptime,
                    h_printer.unspooler,
                    c_printer.unspooler.aka(_("unspooler")))
    fetch_job_list(time, uptime,
                   h_printer.job.create(),
                   c_printer.queue.table.aka(_("job list")).iaka(_("job #%s")))
end


function printer_queue_list.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local time              = int.u32(os.time())
    local uptime            = mit.system.uptime.get_int_u32()
    local h_printer_list    = form.printer.create()
    local c_printer_list    = mit.printing.printer.table.
                                            iaka(_("printer #%s"))

    for printer_id, c_printer in c_printer_list.as_iter() do
        fetch_printer(time, uptime,
                      h_printer_list[printer_id].create(), c_printer)
    end

    t:close()
end


return printer_queue_list
