---
-- LAN group connection status WebUI module.
-- @release $Id: lan_connection_status.lua 151271 2010-11-30 14:23:49Z nikolai.kondrashov $
--

local crm                   = require("webui.crm")
local hdf                   = require("webui.hdf")
local webui_mods            = {}
webui_mods.conn             = {}
webui_mods.conn.tree        = require("webui_mods.conn.tree")
local lan_connection_status = {}

local function fetch_status(grp_id, form)
    local t             = crm.transaction():webui_open_ro()
    local mit           = t:mit()
    local grp           = mit.lan.group.iaka(_("LAN group #%s"))[grp_id]
    local grp_name      = grp.name.get_string()
    if #grp_name > 0 then
        grp.aka(_("LAN group \"%s\""):format(grp_name))
    end
    local rt_conn       = grp.rt_conn.
                            aka(_("routing destination connection"))
    local rt_conn_path  = rt_conn.get_link()

    local rt_conn_present   = (#rt_conn_path > 0)


    form.rt_conn_present = rt_conn_present
    if rt_conn_present then
        local rt_pool_path = rt_conn_path:match("^(.*)/current$")

        webui_mods.conn.tree.smmr(form, mit)

        -- If the connection link is valid
        if rt_conn.status.name.aka(_("status")).exists() then
            local rt_conn_realpath = t:realpath(rt_conn_path)
            local rt_dev_id, rt_conn_id =
                    rt_conn_realpath:match(
                        "^/connection/device/table/([^/]+)" ..
                        "/configured/([^/]+)")

            if rt_dev_id and rt_conn_id then
                form.rt_dev_id = rt_dev_id
                form.rt_conn_id = rt_conn_id
            else
                error(_("Invalid connection path \"%s\""):
                        format(rt_conn_realpath))
            end
        end

        -- If the connection link is through a pool
        if rt_pool_path ~= nil then
            local rt_pool = mit[rt_pool_path].
                                aka(_("routing destination pool"))
            form.rt_pool = rt_pool.name.aka(_("name")).get_string()
        end
    end

    t:close()
end

function lan_connection_status.fetch(conf, query, prvt, form)
    local grp_id    = query.connection_issue_lan_group.get()

    if grp_id ~= nil and #grp_id > 0 then
        fetch_status(grp_id, form)
    end
end

return lan_connection_status
