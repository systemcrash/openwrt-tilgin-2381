---
-- Certificate upload page module.
-- @release $Id:$
--
local crm   = require("webui.crm")
local webui_mods        = {}

local certificates_upload     = {}

function certificates_upload.apply(conf, query, form, prvt)
    local t                 = crm.transaction():webui_open_rw()
    local root              = t:mit().security.certificate

    local name_ = form.name.get()
    local password_ = form.password.get()
    local public_ = form.public.FileName.get()
    local private_ = form.private.FileName.get()

    if name_ == nil or name_ == "" then
        error(_("Invalid name"))
    end 

    if public_ == nil or public_ == "" then
        error(_("Invalid public certificate"))
    end 
    
    root.store.add.aka(_("Add certificate")).exec(
    {
        name = crm.value.string(name_),
        password = crm.value.string(password_),
        public = crm.value.string(public_),
        private = crm.value.string(private_),
        signer = crm.value.link(nil)
    })

    t:close()
end

function certificates_upload.fetch(conf, query, prvt, form)
end

return certificates_upload
