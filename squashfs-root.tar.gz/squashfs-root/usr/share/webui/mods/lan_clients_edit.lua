---
-- LAN client editing WebUI module.
-- @release $Id: lan_clients_edit.lua 163752 2013-07-04 03:27:56Z marina.maslova $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local webui_mods        = {}
webui_mods.lan          = {}
webui_mods.lan.grp_set  = require("webui_mods.lan.grp_set")
local lan_clients_edit   = {}


function lan_clients_edit.apply(conf, query, form, prvt)
    local ipv6, cli_id, grp_id, s, f

    ipv6 = form.ipv6.get()
    if ipv6 then
       s, f, grp_id, cli_id = string.find(ipv6, "(%d+):(%d+)")
       prvt.grp_id = grp_id
       prvt.cli_id = cli_id
    else
        local t     = crm.transaction():webui_open_rw()
        local mit   = t:mit()

        webui_mods.lan.grp_set.apply_client_list(mit, form)
        t:close()
    end

end


function lan_clients_edit.fetch(conf, query, prvt, form)
    local grp_id = prvt.grp_id.get()
    local cli_id = prvt.cli_id.get()

    if grp_id and cli_id then
        form.ipv6_grp_id = grp_id
        form.ipv6_cli_id = cli_id
    else
        local t     = crm.transaction():webui_open_ro()
        local mit   = t:mit()

        webui_mods.lan.grp_set.smmr(form, mit)
        webui_mods.lan.grp_set.fetch_client_list(form, mit)
        t:close()
    end
end


return lan_clients_edit


