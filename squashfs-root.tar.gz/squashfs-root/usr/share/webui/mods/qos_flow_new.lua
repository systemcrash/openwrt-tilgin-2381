---
-- QoS flow creating WebUI module.
-- @release $Id: qos_flow_new.lua 139771 2009-10-28 16:22:58Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local webui_mods        = {}
webui_mods.qos          = {}
webui_mods.qos.flow_set = require("webui_mods.qos.flow_set")
local qos_flow_new      = {}


function qos_flow_new.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()

    prvt.id = webui_mods.qos.flow_set.add(t:mit().qos.cs, 
                                          form.label.aka(_("label")).get())
    t:close()
end


function qos_flow_new.fetch(conf, query, prvt, form)
    form.created_id = prvt.id
end


return qos_flow_new


