---
-- LAN clients IPV6 configuration module.
-- @release $Id:$
---

local crm               = require("webui.crm")
local lan_clients_ipv6  = {}
local webui_mods        = {}
webui_mods.lan          = {}
webui_mods.lan.grp      = require("webui_mods.lan.grp")

function lan_clients_ipv6.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()
    local cli_id, grp_id, gdp, cli, duid, dpl

    cli_id = query.cli.get()
    grp_id = query.grp.get()
    if not cli_id or not grp_id then
        error(_("Failed to get LAN client id"))
    end

    grp = mit.lan.group[grp_id]
    cli = grp.lan_client[cli_id]
    duid = cli.duid.aka(_("DUID")).get()
    dpl = form.dpl.aka(_("deligated prefix length")).get()
    if dpl then
        prvt.dpl_applied = true
        grp.update_dpl.exec({duid=duid, dpl=crm.value.u8(dpl)}, {})
    end

    t:close()
end

function lan_clients_ipv6.fetch(conf, query, prvt, form)

    if prvt.dpl_applied.as_boolean() then
        return
    end

    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()

    local cli_id, grp_id, node, dpl
    local addr_list, prefix_list
    local addr_id, addr_node
    local prefix_id, prefix_node
    local dlg

    cli_id = query.cli.get()
    grp_id = query.grp.get()
    if not cli_id or not grp_id then
        error(_("Failed to get LAN client id"))
    end

    node        = mit.lan.group[grp_id].lan_client[cli_id]
    form.dpl    = node.dpl.aka(_("deligated prefix length")).as_string()
    form.duid   = node.duid.aka(_("DUID")).get_octets_as_string_hex()
    addr_list   = form.addr_list.create()
    prefix_list = form.prefix_list.create()

    for addr_id, addr_node in node.ipv6.as_iter() do
        addr_list[addr_id].create()
        addr_list[addr_id].addr = webui_mods.lan.grp.convert_unknown_to_ipv6(addr_id)
    end
    for prefix_id, prefix_node in mit.ip.prefix.config.table.as_iter() do
        dlg = prefix_node.delegatee.aka(_("prefix delegatee")).get_link()
        
        if node.get_path() == dlg then
            prefix_list[prefix_id].create()
            prefix_list[prefix_id].addr = prefix_node.addr.aka(_("prefix address")).get_octets_as_ip_addr()
            prefix_list[prefix_id].len = prefix_node.len.aka(_("prefix length")).as_string()
        end
    end

    t:close()
end

return lan_clients_ipv6
