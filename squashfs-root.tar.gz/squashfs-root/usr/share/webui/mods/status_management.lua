---
-- Management server connectivity status WebUI module.
-- @release $Id: status_management.lua 139343 2009-10-14 18:07:58Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local status_management = {}


function status_management.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local server    = mit.config.provisioning.server.aka(_("server"))

    form.state = mit.update.state.name.aka(_("state")).get_string()
    form.server.addr = server.addr.aka(_("address")).get_octets_as_ip_addr()
    form.server.fqdn = server.fqdn.aka(_("domain name")).get_string()
    form.server.origin = server.origin.name.aka(_("origin")).get_string()

    t:close()
end


return status_management
