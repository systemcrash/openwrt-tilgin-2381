---
-- Storage user list WebUI module.
-- @release $Id: storage_user_list.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local req               = require("webui_mods.sec.users").req
local vpn_users_list = {}


local function apply_account(ac, c_account, h_account)
    local id
    local group
    local password = h_account.password.aka(_("password")).get()
    local hidd_password = h_account.hidd_password.
                            aka(_("hidden password")).get()

    c_account.username.aka(_("username")).
        set_string(req.name(h_account.username.aka(_("username"))).get())

    if password ~= hidd_password then
        c_account.password.aka(_("password")).set_string(
                            req.password(h_account.password).get())
    end
end


function vpn_users_list.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local ac        = t:mit().ipsec_accounts.users

    local id
    local h_account
    local c_account

    for id, h_account in _form.account.iter() do
        local c_account = ac.table[id]
       print("TEST")
        if c_account.exists() then
            if h_account.delete.as_boolean() then
                ac.del.exec(
                    {link = crm.value.link(c_account.get_path())})
            else
                apply_account(ac, c_account, h_account)
            end
        end
    end

    t:close()
end


function vpn_users_list.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_rw()
    local ac        = t:mit().ipsec_accounts.users
    local id
    local node
    local item

    for id, node in ac.table.as_iter() do
        item = form.account[id].create()

        item.username   = node.username.get_string()
        item.password   = string.gsub(tostring(node.password.get_string()),
                                      "(.)", function(a) return '*' end)
    end

    t:close()
end


return vpn_users_list