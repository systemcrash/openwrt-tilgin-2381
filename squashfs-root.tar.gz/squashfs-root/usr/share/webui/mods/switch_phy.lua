---
-- Switch physical interface management WebUI module.
-- @release $Id: switch_storm.lua 138292 2009-09-18 18:15:49Z nikolai.kondrashov $
--


local crm                   = require("webui.crm")
local hdf                   = require("webui.hdf")
local webui_mods            = {}
webui_mods.switch           = {}
webui_mods.switch.if_set    = require("webui_mods.switch.if_set")
local switch_phy            = {}


local function apply_mode_adv(c_speed_adv, h_mode_adv)
    local speed, c_speed, h_speed
    local duplex, c_duplex

    for speed, c_speed in c_speed_adv.as_iter() do
        h_speed = h_mode_adv[speed]
        for duplex, c_duplex in c_speed.as_iter() do
            c_duplex.set_boolean(h_speed[duplex:lower()].as_boolean())
        end
    end
end


local function apply_autoneg(c_autoneg, h_autoneg)
    local c_rx_pause = c_autoneg.rx_pause.aka(_("RX flow control"))
    local c_tx_pause = c_autoneg.tx_pause.aka(_("TX flow control"))

    c_autoneg.enabled.aka(_("administrative status")).
        set_boolean(h_autoneg.enabled.as_boolean())

    if c_rx_pause.exists() then
        c_rx_pause.set_boolean(h_autoneg.pause.rx.as_boolean())
    end
    if c_tx_pause.exists() then
        c_tx_pause.set_boolean(h_autoneg.pause.tx.as_boolean())
    end

    apply_mode_adv(c_autoneg.speed_adv.aka(_("advertised speed")),
                    h_autoneg.mode_adv)
end


local function apply_port(c_port, h_port)
    local mode_admin = h_port.mode_admin.get()
    local speed_admin, duplex_admin = mode_admin:match("^([^/]+)/(.+)$")
    local full_duplex_admin
    local c_autoneg = c_port.prop.autoneg.aka(_("autonegotiation"))
    local h_autoneg = h_port.autoneg.aka(_("autonegotiation"))

    if not speed_admin and not duplex_admin then
        error(_("invalid mode \"%s\""):format(mode_admin))
    end

    if duplex_admin == "half" then
        full_duplex_admin = false
    elseif duplex_admin == "full" then
        full_duplex_admin = true
    else
        error(_("invalid duplex mode \"%s\""):format(duplex_admin))
    end

    c_port.speed_admin.aka(_("administrative speed")).
                        set_string(speed_admin)
    c_port.full_duplex_admin.aka(_("full duplex administrative status")).
                                set_boolean(full_duplex_admin)

    if c_autoneg.exists() then
        apply_autoneg(c_autoneg, h_autoneg)
    end
end


function switch_phy.apply(conf, query, form, prvt)
    local t             = crm.transaction():webui_open_rw()
    local mit           = t:mit()

    local h_port_list   = form.port.iaka(_("port #%s"))

    -- Apply ports
    for port_id, c_port in
        webui_mods.switch.if_set.as_port_iter(
            mit.ethernet.switch.super.available.
                aka(_("interface set")).iaka(_("interface #%s"))) do
        apply_port(c_port, h_port_list[port_id])
    end

    t:close()
end


local function fetch_mode_adv(h_mode_adv, c_speed_adv)
    local speed, c_speed, h_speed
    local duplex, c_duplex

    for speed, c_speed in c_speed_adv.as_iter() do
        h_speed = h_mode_adv[speed].create()
        for duplex, c_duplex in c_speed.as_iter() do
            duplex = duplex:lower()
            h_speed[duplex] = c_duplex.get_boolean()
        end
    end
end


local function fetch_autoneg(h_autoneg, c_autoneg)
    local c_rx_pause = c_autoneg.rx_pause.aka(_("RX flow control"))
    local c_tx_pause = c_autoneg.tx_pause.aka(_("TX flow control"))

    h_autoneg.enabled = c_autoneg.enabled.aka(_("administrative status")).
                                            get_boolean()

    if c_rx_pause.exists() then
        h_autoneg.pause.rx = c_rx_pause.get_boolean()
    end
    if c_tx_pause.exists() then
        h_autoneg.pause.tx = c_tx_pause.get_boolean()
    end

    fetch_mode_adv(h_autoneg.mode_adv,
                    c_autoneg.speed_adv.aka(_("advertised speed")))
end


local function fetch_port(h_port, c_port)
    local speed_admin, speed
    local duplex_admin, duplex
    local h_mode_list, h_speed
    local speed_id, c_speed
    local c_autoneg = c_port.prop.autoneg.aka(_("autonegotiation"))

    h_port.name = c_port.name.aka(_("name")).get_string()
    h_port.jack = c_port.jack.name.aka(_("jack name")).get_string()
    h_port.oper = c_port.oper.aka(_("operating status")).get_boolean()

    -- Transfer supported modes (supported speeds/duplex modes)
    h_mode_list = h_port.mode_supported.create()
    for speed_id, c_speed in c_port.speed_supported.
                                aka(_("supported speed set")).as_iter() do
        h_speed = h_mode_list[c_speed.value.as_string()]
        h_speed.half = true
        h_speed.full = true
    end

    -- Output administrative mode (administrative speed/duplex mode)
    speed_admin = c_port.speed_admin.value.
                        aka(_("administrative speed")).as_string()
    duplex_admin = c_port.full_duplex_admin.
                        aka(_("full duplex administrative status")).
                        get_boolean() and "full" or "half"
    h_port.mode_admin = speed_admin .. "/" .. duplex_admin

    -- Output operating mode (administrative speed/duplex mode)
    speed = c_port.speed.value.
                        aka(_("operating speed")).as_string()
    duplex = c_port.full_duplex.
                aka(_("full duplex operating status")).
                get_boolean() and "full" or "half"
    h_port.mode = speed .. "/" .. duplex

    if c_autoneg.exists() then
        fetch_autoneg(h_port.autoneg.create(), c_autoneg)
    end
end


function switch_phy.fetch(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_ro()
    local mit           = t:mit()
    local h_port_list

    -- Fetch ports
    h_port_list = form.port.create()
    for port_id, c_port in
        webui_mods.switch.if_set.as_port_iter(
            mit.ethernet.switch.super.available.
                aka(_("interface set")).iaka(_("interface #%s"))) do
        fetch_port(h_port_list[port_id].create(), c_port)
    end

    t:close()
end


return switch_phy
