---
-- QoS flow list WebUI module.
-- @release $Id: qos_flow_list.lua 142063 2009-12-18 18:06:18Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local webui_mods        = {}
webui_mods.iface        = {}
webui_mods.iface.tree   = require("webui_mods.iface.tree")
webui_mods.qos          = {}
webui_mods.qos.flow_set = require("webui_mods.qos.flow_set")

local qos_flow_list = {}


function qos_flow_list.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()

    webui_mods.qos.flow_set.apply(mit.qos.cs, form)

    t:close()
end


function qos_flow_list.fetch(conf, query, prvt, form)
    local t     = crm.transaction():webui_open_ro()
    local mit   = t:mit()

    webui_mods.iface.tree.load(form.iface.create(), mit,
                               {lan_group = true, conn = true})
    webui_mods.qos.flow_set.fetch(form, mit.qos.cs)

    t:close()
end


return qos_flow_list
