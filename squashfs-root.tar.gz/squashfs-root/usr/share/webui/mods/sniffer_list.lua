---
-- Sniffer list WebUI module.
-- @release $Id: sniffer_list.lua 154043 2011-04-26 17:17:34Z marina.maslova $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local webui_mods        = {}
webui_mods.iface        = {}
webui_mods.iface.tree   = require("webui_mods.iface.tree")
webui_mods.storage      = {}
webui_mods.storage.tree = require("webui_mods.storage.tree")

local sniffer_list = {}

local function apply_sniffer(c, h, have_storage)
    local h_admin       = h.admin.as_boolean()
    local h_new_admin   = h.new_admin.as_boolean()
    local h_if
    local c_if

    if not h_new_admin then
        c.admin.aka(_("administrative status")).set_boolean(false)
    end

    if not h_admin then
        c.label.aka(_("name")).set_string(h.label.get())
        c.promisc.aka(_("promiscuous mode")).
                    set_boolean(h.promisc.as_boolean())
        c.headers_only.aka(_("headers only")).
                        set_boolean(h.headers_only.as_boolean())
        c.filter.aka(_("filter")).set_string(h.filter.get())
        c.count.aka(_("count")).
                    set(h.count.aka(_("count")).req_number().as_crm_u32())
        c.sample.aka(_("sample")).
                    set(h.sample.aka(_("sample")).req_number().as_crm_u32())
        c.snaplen.aka(_("snap length")).
                    set(h.snaplen.aka(_("snap length")).
                                    req_number().as_crm_u32())

        h_if = h["if"].resolve()
        c_if = c["if"]

        c_if.set_link(webui_mods.iface.tree.path(h_if) or "")

        if have_storage then
            c.dir.set_link(webui_mods.storage.tree.get_path(h.storage))
        end
    end

    if h_new_admin then
        c.admin.aka(_("administrative status")).set_boolean(true)
    end
end


function sniffer_list.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()
    local id
    local item
    local have_storage      = mit.storage.exists()

    for id, item in form.sniffer.iter() do
        if item.delete.as_boolean() then
            mit.sniffer.del.aka(_("delete")).exec(
                {link = crm.value.string("/sniffer/table/" .. id)})
        else
            apply_sniffer(mit.sniffer.table[id], item, have_storage)
        end
    end

    t:close()
end

local function fetch_sniffer(item, node, have_storage)
    local path
    local admin

    item.label              = node.label.get_string()
    item.admin              = node.admin.get_boolean()
    item.promisc            = node.promisc.get_boolean()
    item.headers_only       = node.headers_only.get_boolean()
    item.state              = node.state.name.get_string()
    item.filter             = node.filter.get_string()
    item.count              = node.count.as_string()
    item.sample             = node.sample.as_string()
    item.snaplen            = node.sample.as_string()
    path                    = node.file.get_string()
    item.path               = path
    item.filename           = path:match("[^/]+$")

    webui_mods.iface.tree.slct(item["if"], node["if"].get_link())

    if have_storage then
        webui_mods.storage.tree.slct(item.storage, node.dir.get_link())
    end
end


function sniffer_list.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local id
    local node
    local item
    local have_storage  = mit.storage.exists()

    webui_mods.iface.tree.load(form.iface, mit)

    if have_storage then
        webui_mods.storage.tree.smmr(form.storage.create(), mit)
    end

    for id, node in mit.sniffer.table.aka(_("sniffer set")).
                                      iaka(_("sniffer #%s")).as_iter() do
        fetch_sniffer(form.sniffer[id].create(), node, have_storage)
    end

    t:close()
end


return sniffer_list
