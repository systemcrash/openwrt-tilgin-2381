---
-- Status storage WebUI module.
-- @release $Id:$
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local int               = require("webui.int")
local status_storage    = {}

local function fetch_device(item, node)
    local name
    local oper

    name = node.name.aka(_("name")).get_string()
    node.aka(string.format("\"%s\"", name))

    item.name       = name
    item.vendor     = node.vendor.aka(_("vendor")).get_string()
    item.model      = node.model.aka(_("model")).get_string()
    item.serial     = node.serial.aka(_("serial")).get_string()
    item.admin      = node.admin.aka(_("administrative status")).
                                                    get_boolean()
    item.ejected    = node.ejected.aka(_("ejection status")).
                                                    get_boolean()
    item.connected  = node.connected.aka(_("connection status")).
                                                    get_boolean()

    oper            = node.oper.aka(_("operating status")).
                                                    get_boolean()
    item.oper       = oper

    if oper then
        item.capacity.value, item.capacity.unit =
            node.capacity.aka(_("capacity")).
                get_int_u64():decimal_scaled_bytes()
    end
end

function status_storage.fetch(conf, query, prvt, form)
    local t     = crm.transaction():webui_open_ro()
    local mit   = t:mit()
    local id
    local node

    if not mit.storage.exists() then
        form.supported = false
        t:close()
        return
    end

    form.supported = true
    for id, node in mit.storage.unit.aka(_("unit set")).
                                     iaka(_("unit #%s")).as_iter() do
        if node.instanceof("st_media") then
            fetch_device(form.unit[id].create(), node)
        end
    end

    t:close()
end


return status_storage
