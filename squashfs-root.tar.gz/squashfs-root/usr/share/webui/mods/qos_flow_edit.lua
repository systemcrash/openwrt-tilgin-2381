---
-- QoS flow editing WebUI module.
-- @release $Id: qos_flow_edit.lua 142063 2009-12-18 18:06:18Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local webui_mods        = {}
webui_mods.iface        = {}
webui_mods.iface.tree   = require("webui_mods.iface.tree")
webui_mods.qos          = {}
webui_mods.qos.flow     = require("webui_mods.qos.flow")

local qos_flow_edit = {}

local function get_id_and_flow(mit, query)
    local flow_id   = query.flow.req_range(1, 2147483647).  -- 1-INT32_MAX
                                                        get()
    local c_flow    = mit.qos.cs.table[flow_id]

    if not c_flow.exists() or not webui_mods.qos.flow.match(c_flow) then
       error(_("flow not found"))
    end

    return flow_id, c_flow
end


function qos_flow_edit.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()

    local flow_id, c_flow   = get_id_and_flow(mit, query)

    if form.delete.as_boolean() then
        mit.qos.cs.del.aka(_("delete")).
            exec({index = crm.value.u32(flow_id)})
        prvt.deleted = true
    else
        webui_mods.qos.flow.apply(c_flow, form)
    end

    t:close()
end


function qos_flow_edit.fetch(conf, query, prvt, form)
    if prvt.deleted.as_boolean() then
        return
    end

    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()

    local flow_id, c_flow   = get_id_and_flow(mit, query)

    webui_mods.iface.tree.load(form.iface.create(), mit,
                               {lan_group = true, conn = true})
    webui_mods.qos.flow.fetch(form, c_flow)

    t:close()
end


return qos_flow_edit
