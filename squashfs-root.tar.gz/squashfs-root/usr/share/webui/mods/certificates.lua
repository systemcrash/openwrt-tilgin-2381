---
-- Certificate configuration page module.
-- @release $Id:$
--
local crm   = require("webui.crm")
local webui_mods        = {}

local certificates     = {}

function certificates.apply(conf, query, form, prvt)
    local t                 = crm.transaction():webui_open_rw()
    local root              = t:mit().security.certificate
    local item
    local id
    for id, item in form.certs.iter() do
        local mit_item = root.store.table[id]
        if item.delete.as_boolean() then
            root.store.del.exec(
                { 
                    index = crm.value.u32(id)
                })
        end
    end
    t:close()
end

function certificates.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local root              = t:mit().security.certificate
    local item
    local id
    local node

    for id, node in root.store.table.as_iter() do
        item = form.certs[id].create()
        item.name = node.name.get_string()
        item.password = node.password.get_string()
        item.issuer = node.issuer.get_string()
        item.subject = node.subject.get_string()
        item.fingerprint = node.fingerprint.get_string()
        item.valid_from = node.valid_from.get_string()
        item.valid_to = node.valid_to.get_string()
        
    end

    t:close()
end

return certificates
