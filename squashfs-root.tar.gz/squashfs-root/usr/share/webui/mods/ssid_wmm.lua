---
-- Wi-Fi multimedia (WMM) configuration WebUI module.
-- @release $Id:$
--

local crm   = require("webui.crm")
local hdf   = require("webui.hdf")
local ssid_wmm   = {}


local function apply_ac(crm_ac, form_ac)
    local id, form_cat, crm_cat

    for id, form_cat in form_ac.iter() do
        crm_cat = crm_ac[id]
        crm_cat.ecwmin.set(
            form_cat.ecwmin.req_range(0, 15).as_crm_u8())
        crm_cat.ecwmax.set(
            form_cat.ecwmax.req_range(0, 15).as_crm_u8())
        crm_cat.aifsn.set(
            form_cat.aifsn.req_range(0, 15).as_crm_u8())
        crm_cat.txop.set(
            form_cat.txop.req_range(0, 8192).as_crm_u16())
    end
end


local function apply_dscp2ac(crm_map, form_map)
    -- Don't apply, if at least one entry is read-only
    for v = 0, 7 do
        if not crm_map[v].writable() then
            return
        end
    end

    for v = 0, 7 do
        crm_map[v].set_string(form_map[v].get())
    end
end


function ssid_wmm.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()
    local id    = query.ssid.req_range(1, 2147483647).get() -- 1-INT32_MAX
    local wmm   = mit["if"].table[id].wmm
    local wmmp  = mit.wlan.port.wmm

    wmm.enabled.aka(_("administrative status")).
        set_boolean(form.enabled.as_boolean())
    apply_ac(wmmp.ac_ap_table.aka(_("access point access categories")),
             form.ac_ap.aka(_("access point access categories")))
    apply_ac(wmmp.ac_sta_table.aka(_("station access categories")),
             form.ac_sta.aka(_("station access categories")))
    apply_dscp2ac(wmmp.dscp2ac_table.
                    aka(_("DiffServ code point - access category map")).
                    iaka(_("code point %s")),
                  form.dscp2ac.
                    aka(_("DiffServ code point - access category map")).
                    iaka(_("code point %s")))

    t:close()
end


local function fetch_ac(form_ac, crm_ac)
    local id, form_cat, crm_cat

    for id, crm_cat in crm_ac.as_iter() do
        form_cat = form_ac[id].create()
        form_cat.ecwmin      = crm_cat.ecwmin.as_string()
        form_cat.ecwmax      = crm_cat.ecwmax.as_string()
        form_cat.aifsn       = crm_cat.aifsn.as_string()
        form_cat.txop  = crm_cat.txop.as_string()
    end
end


local function fetch_dscp2ac(form_readonly, form_map, crm_map)
    local readonly = false

    for v = 0, 7 do
        form_map[v] = crm_map[v].name.get_string()
        if not readonly and not crm_map[v].writable() then
            readonly = true
        end
    end
    form_readonly.set(readonly)
end


function ssid_wmm.fetch(conf, query, prvt, form)
    local t     = crm.transaction():webui_open_ro()
    local mit   = t:mit()
    local id    = query.ssid.req_range(1, 2147483647).get() -- 1-INT32_MAX
    local wmm   = mit["if"].table[id].wmm
    local wmmp  = mit.wlan.port.wmm
    form.enabled = wmm.enabled.aka(_("administrative status")).get_boolean()
    fetch_ac(form.ac_ap.create(),
             wmmp.ac_ap_table.aka(_("access point access categories")))
    fetch_ac(form.ac_sta.create(),
             wmmp.ac_sta_table.aka(_("station access categories")))
    fetch_dscp2ac(form.dscp2ac_readonly, form.dscp2ac.create(),
                  wmmp.dscp2ac_table.
                    aka(_("DiffServ code point - access category map")).
                    iaka(_("code point %s")))

    t:close()
end


return ssid_wmm
