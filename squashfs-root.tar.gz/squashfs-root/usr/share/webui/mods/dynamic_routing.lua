---
-- Dynamic routing management WebUI module.
-- @release $Id: dynamic_routing.lua 164769 2013-10-31 08:40:24Z elena.vengerova $
--
-- On the template side we refer to global interfaces by a "reference" ID.
-- Reference ID 0 means WAN interface, other values mean LAN group ID.
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local dynamic_routing   = {}

local wan_if_path       = "/connection/fallback/ppool/default/current/if"


function dynamic_routing.apply_if(crm_if, form_if)
    crm_if.recv_version.aka(_("receive version")).set_string(
                                                form_if.recv_version.get())
    crm_if.send_version.aka(_("send version")).set_string(
                                                form_if.send_version.get())
    crm_if.auth_mode.aka(_("authentication mode")).set_string(
                                                form_if.auth_mode.get())
    crm_if.auth_str.aka(_("authentication string")).set_string(
                                                form_if.auth_str.get())
    crm_if.active.aka(_("authentication string")).set_boolean(
                                                form_if.active.as_boolean())
end


function dynamic_routing.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()
    local rip   = mit.rip
    local if_id
    local form_if
    local crm_if
    local ref_if_id
    local if_path
    local ref_if_path

    -- Disable while changing
    rip.admin.aka(_("administrative status")).set_boolean(false)

    -- Transfer general parameters
    rip.version.aka(_("version")).set_string(form.version.get())
    rip.default_metric.aka(_("default metric")).set_u8(
        form.default_metric.aka(_("default metric")).req_range(1, 16).get())

    -- Transfer interface parameters
    for if_id, form_if in form.iface.iter() do
        crm_if = rip.iface.iaka(_("interface #%s"))[if_id]

        if form_if.delete.as_boolean() then
            rip.del_iface.aka(_("delete interface")).exec(
                {link = crm.value.string(crm_if.get_path())})
        else
            dynamic_routing.apply_if(crm_if, form_if)
        end
    end

    -- Add interface, if selected
    ref_if_id = tonumber(form.ref_iface.get())
    if ref_if_id ~= nil and ref_if_id >= 0 then
        if_path = rip.add_iface.aka(_("add interface")).exec({}, {"link"})
        ref_if_path = (ref_if_id == 0) and wan_if_path
                                        or ("/lan/group/" ..
                                            ref_if_id .. "/ipif")
        t:node(if_path:get_link()).iface.aka(_("interface path")).
                                            set_link(ref_if_path)
    end

    -- Enable back (if requested)
    rip.admin.aka(_("administrative status")).
                            set_boolean(form.admin.as_boolean())

    t:close()
end


function dynamic_routing.fetch_if(form_if, crm_if, ref_if_id, ref_if_name)
    form_if.ref_name = ref_if_name
    form_if.ref_id = ref_if_id

    form_if.active = crm_if.active.aka(_("status")).get_boolean()

    form_if.send_version = crm_if.send_version.name.
                                aka(_("send version")).get_string()
    form_if.recv_version = crm_if.recv_version.name.
                                aka(_("receive version")).get_string()
    form_if.auth_mode = crm_if.auth_mode.name.
                                aka(_("authentication mode")).get_string()
    form_if.auth_str = crm_if.auth_str.
                                aka(_("authentication string")).get_string()
end


function dynamic_routing.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local rip       = mit.rip
    local id
    local node
    local form_if
    local if_path
    local rip_if_id     -- RIP membership interface ID
    local ref_if_id     -- Reference interface ID
    local ref_if_name   -- Reference interface name

    form.admin = rip.admin.aka(_("administrative status")).get_boolean()
    form.oper = rip.oper.aka(_("operating status")).get_boolean()
    form.version = rip.version.name.aka(_("version")).
                                    get_string()
    form.default_metric = rip.default_metric.aka(_("default metric")).
                                    as_number()
    
    --
    -- Transfer used RIP interfaces
    --
    for id, node in rip.iface.aka(_("interface set")).
                                     iaka(_("interface #%s")).as_iter() do
        form_if = form.iface[id]
        if_path = node.iface.aka(_("path")).get_link()

        if if_path == wan_if_path then
            dynamic_routing.fetch_if(form_if.create(), node, 0, _("WAN"))
        else
            ref_if_id = if_path:match("/lan/group/([^/]+)/ipif$")
            if ref_if_id ~= nil and mit.lan.group[ref_if_id].visible() then
                ref_if_name = mit.lan.group[ref_if_id].name.aka(_("name")).
                                                                get_string()
                dynamic_routing.fetch_if(form_if.create(), node,
                                         ref_if_id, ref_if_name)
            end
        end
    end

    --
    -- Generate reference interface list
    --

    -- Output WAN pseudo-interface
    form.ref_iface[0] = _("WAN")

    -- Transfer LAN groups
    for id, node in mit.lan.group.aka(_("LAN group set")).
                                    iaka(_("LAN group #%s")).
                                        as_iter_readable() do
        if node.visible() then
            form.ref_iface[id] = node.name.aka(_("name")).get_string()
        end
    end

    t:close()
end


return dynamic_routing
