---
-- DECT CAT-iq status WebUI module.
-- @release $Id:$
--

local crm   = require("webui.crm")
local dect = {}

function dect.fetch(conf, query, prvt, form)
    local t    = crm.transaction():webui_open_ro()
    local mit  = t:mit()

    if not mit.dect.exists() then
        form.supported = false
        t:close()
        return
    end

    form.supported = true
    form.fp_enabled = mit.dect.fp_enabled.aka(_("DECT enabled")).get_boolean()
    form.fp_name = "Tilgin " .. mit.dect.fp_model.get_string() .. " CAT-iq - DECT device"
    form.hs_registered = false;
        
    for id, handset in mit.dect.hs.as_iter() do
        if handset.exists() then
            form.hs_registered = true;
            break
        end
    end

    t:close()
end

return dect

    
