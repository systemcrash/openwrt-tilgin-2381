---
-- MAC addresses list per port WebUI module.
-- @release $Id: $
--

local crm                    = require("webui.crm")
local status_port_mac_list   = {}

function status_port_mac_list.fetch(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_ro()
    local hwswitch      = t:mit().ethernet.hwswitch.get_link()
    local arl           = t:node(hwswitch).arl.table

    local h_list = form.port_mac.create()

    for ent_mac, c_mac_node in arl.as_iter() do
        local port_name
        local dynamic
        local item

        for ent_fid, c_arl_node in c_mac_node.as_iter() do
            dynamic = c_arl_node.dynamic.get_boolean()
            if dynamic then
                for port_id, c_port_node in c_arl_node.portset.as_iter() do
                    port_name =
                        t:node(c_port_node.get_link()).name.get_string()
                    if (not string.find(port_name, "mii") and
                        not string.find(port_name, "WAN")) then
                        if not h_list[port_name].exists() then
                            h_list[port_name].create()
                        end
                        if not h_list[port_name].mac_list[ent_mac].exists() then
                            item = h_list[port_name].mac_list[ent_mac].create()
                            item.mac = string.upper(string.sub(
                                    string.gsub(ent_mac, "(%x%x)", "%1:"),
                                    1, -2))
                        end
                    end
                end
            end
        end
    end

    t:close()
end


return status_port_mac_list
