---
-- Access control management WebUI module.
-- @release $Id: access_control.lua 167601 2014-07-10 06:44:33Z maxim.menshchikov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local access_control    = {}


-- Supported/allowed services and their human-readable names
local supported_service = {
    {
     id     = "ping",
     name   = _("Ping")
    },
    {
     id     = "webui_http",
     name   = _("WebUI over HTTP")
    },
    {
     id     = "webui_https",
     name   = _("WebUI over HTTPS")
    },
    {
     id     = "samba",
     name   = _("Storage over SMB")
    },
    {
     id     = "storage_http",
     name   = _("Storage over HTTP")
    },
    {
     id     = "storage_https",
     name   = _("Storage over HTTPS")
    },
    {
     id     = "snmp",
     name   = _("SNMP")
    }
}


-- WAN flag - disposition map
local disposition_map = {
    [false] = "lan",
    [true] = "wan"
}


local function apply_rule(crm_rule, form_rule)
    crm_rule.key.src_ip.ip.aka(_("address")).set(
        form_rule.address.aka(_("address")).as_crm_ip_addr())
    crm_rule.key.src_ip.prefix.aka(_("prefix")).set(
        form_rule.prefix.aka(_("prefix")).req_range(0, 32).as_crm_u8())
    crm_rule.admin.aka(_("administrative status")).set_boolean(
        form_rule.admin.as_boolean())
end

local function is_empty(s)
    return s == nil or s == ""
end

local function apply_service(crm_service, form_service, internal_name, mit)
    local wan, disposition
    local form_service_disposition
    local rule_id, form_rule, crm_rule
    local crm_rule_table    = crm_service.rule.table.iaka(_("rule #%s"))
    local form_new_rule, crm_new_rule
    local ok, e

    -- Transfer LAN and WAN policies
    crm_service.lan.set_boolean(form_service.lan.policy.as_boolean())
    crm_service.wan.set_boolean(form_service.wan.policy.as_boolean())

    local cert = form_service.certificate.aka(_("certificate")).get()
    if is_empty(cert) then
        cert = nil
    else
        cert = "/security/certificate/store/table/" .. cert
    end
    if internal_name == "webui_https" then
        mit.httpd.webui_s.certificate.aka(_("Web UI over HTTPS certificate")).set_link(cert)
    elseif internal_name == "storage_https" then
        mit.httpd.storage_s.certificate.aka(_("Storage over HTTPS certificate")).set_link(cert)
    end


    -- For each disposition (LAN, WAN)
    for wan, disposition in pairs(disposition_map) do
        form_service_disposition = form_service[disposition].
                                    aka(wan and _("WAN") or _("LAN"))

        -- Set policy
        crm_service[disposition].set_boolean(
            form_service_disposition.policy.as_boolean())

        -- For each form rule in the disposition
        for rule_id, form_rule in form_service_disposition.rule.
                                    iaka(_("rule #%s")).iter() do
            crm_rule = crm_rule_table[rule_id]

            -- If rule exists, there is no internal creator link and
            -- disposition matches
            if crm_rule.exists() and
               not crm_rule.has_creator() and
               crm_rule.key.wan.wan.get_boolean() == wan then
                -- If delete flag is set
                if form_rule.delete.as_boolean() then
                    -- Delete rule
                    crm_service.rule.del.aka(_("delete rule")).exec(
                        {index = crm.value.u32(rule_id)})
                else
                    -- Transfer parameters
                    apply_rule(crm_rule, form_rule)
                end
            end
        end

        form_new_rule = form_service_disposition.new_rule.aka(_("new rule"))
        -- If new rule has address or prefix set
        if not (form_new_rule.address.is_blank() and
                form_new_rule.prefix.is_blank()) then
            -- Create new rule
            rule_id = crm_service.rule.add.exec({}, {"index"})
            rule_id = rule_id:as_string()

            -- Try to transfer rule parameters
            ok, e = pcall(function ()
                crm_new_rule = crm_rule_table[rule_id]
                -- Set disposition
                crm_new_rule.key.wan.wan.set_boolean(wan)
                -- Transfer parameters
                apply_rule(crm_new_rule, form_new_rule)
            end)

            -- If failed
            if not ok then
                -- Delete new rule
                crm_service.rule.del.aka(_("delete rule")).exec(
                    {index = crm.value.u32(rule_id)})
                -- Re-throw the error
                error(e)
            end
        end
    end
end


function access_control.apply(conf, query, form, prvt)
    local t             = crm.transaction():webui_open_rw()
    local mit           = t:mit()
    local service_table = mit.service.instance.table
    local service_set
    local i, s

    -- Retrieve service instance set (as table[name->present])
    service_set = service_table.get_set_as_map()

    -- For each supported service
    for i, s in pairs(supported_service) do
        -- If service exists in the CRM table and is in the form
        if service_set[s.id] and form.service[s.id].exists() then
            apply_service(service_table[s.id], form.service[s.id], s.id, mit)
        end
    end

    t:close()
end


local function fetch_rule(form_rule, crm_rule)
    form_rule.address = crm_rule.key.src_ip.ip.get_octets_as_ip_addr()
    form_rule.prefix = crm_rule.key.src_ip.prefix.as_string()
    form_rule.oper = crm_rule.oper.as_number()
    form_rule.admin = crm_rule.admin.as_number()
end


local function fetch_service(form_service, 
                             crm_service, 
                             service_name,
                             internal_name,
                             mit)
    local id, crm_rule, form_rule, rule_wan

    form_service.name = service_name

    form_service.lan.policy = crm_service.lan.as_number()
    form_service.wan.policy = crm_service.wan.as_number()
    
    local cert = nil
    if internal_name == "webui_https" then            
        form_service.has_certificate = 1
        cert = mit.httpd.webui_s.certificate.get_link()
    elseif internal_name == "storage_https" then
        form_service.has_certificate = 1
        cert = mit.httpd.storage_s.certificate.get_link()
    else
        form_service.has_certificate = 0
    end
    if not is_empty(cert) then
        form_service.certificate = cert:match("^/security/certificate/store/table/([^/]+)")
    end
    
    -- For each rule
    for id, crm_rule in crm_service.rule.table.
                            iaka(_("rule #%s")).as_iter() do
        -- If rule has no internal creator
        if not crm_rule.has_creator() then
            rule_wan = crm_rule.key.wan.wan.get_boolean()
            form_rule = form_service[disposition_map[rule_wan]].
                            rule[id].create()
            fetch_rule(form_rule, crm_rule)
        end
    end

    -- Create new_rule placeholders to show html enclosed in CS "with"
    form_service.lan.new_rule.create()
    form_service.wan.new_rule.create()
end


function access_control.fetch(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_ro()
    local mit           = t:mit()
    local service_table = mit.service.instance.table
    local service_set
    local i, s
    local item

    -- Retrieve service instance set (as table[name->present])
    service_set = service_table.get_set_as_map()

    -- Retrieve certificates
    for i, s in mit.security.certificate.store.table.as_iter() do
        item = form.cert[i].create()
        item.name = s.name.get_string()
    end

    -- For each supported service
    for i, s in pairs(supported_service) do
        -- If service exists in the CRM table
        if service_set[s.id] then
            fetch_service(form.service[s.id],
                          service_table[s.id].
                            aka(string.format(_("%s service"), s.name)),
                          s.name,
                          s.id,
                          mit)
        end
    end

    t:close()
end


return access_control


