---
-- Storage auxiliary software WebUI module.
-- @release $Id: storage_aux_sw.lua 141232 2009-12-01 16:46:07Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local storage_aux_sw    = {}


function storage_aux_sw.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()
    local storage   = mit.storage
    local extfs     = mit.extfs
    local new_admin
    local unit_id

    new_admin = form.admin.as_boolean()

    if not new_admin then
        extfs.admin.aka(_("administrative status")).set_boolean(false)
    end

    unit_id = form.unit.aka(_("storage volume")).req_nonempty().get()
    if #unit_id == 0 then
        extfs.storage_unit.aka(_("storage volume")).set_link("")
    else
        local unit = storage.unit[unit_id].aka(_("storage volume"))

        if not unit.mountable.get_boolean() then
            error(_("invalid storage volume"))
        else
            extfs.storage_unit.aka(_("storage volume")).
                                set_link(unit.get_path())
        end
    end

    extfs.image.aka(_("filename")).
                    set_string(form.image.get())

    if new_admin then
        extfs.admin.aka(_("administrative status")).set_boolean(true)
    end

    t:close()
end


function storage_aux_sw.fetch_unit(list, id, unit)

    if not unit.mountable.get_boolean() then
        storage_aux_sw.fetch_unit_list(list, unit.upper)
    else
        local item = list[id].create()

        item.name = unit.name.get_string()
        item.fs.mount_oper = unit.fs.mount_oper.get_boolean()
    end
end


function storage_aux_sw.fetch_unit_list(list, set)
    local id
    local unit

    for id, unit in set.as_iter() do
        storage_aux_sw.fetch_unit(list, id, unit)
    end
end


function storage_aux_sw.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local storage   = mit.storage
    local extfs     = mit.extfs
    local unit

    storage_aux_sw.fetch_unit_list(form.unit, storage.unit)

    unit = extfs.storage_unit.aka(_("storage volume"))
    if unit.deref() then
        form.unit = unit.get_name()
    end

    form.image  = extfs.image.aka(_("filename")).get_string()
    form.oper   = extfs.oper.aka(_("operating status")).get_boolean()
    form.admin  = extfs.admin.aka(_("administrative status")).get_boolean()

    t:close()
end


return storage_aux_sw
