---
-- Wireless port management WebUI module.
-- @release $Id: qos_flow_list.lua 138178 2009-09-15 16:41:26Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")

local wireless_port = {}


function wireless_port.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()

    local port, name, phy_type_old, phy_type_new, id
    local mode_admin
    local coex = "NONE"

    local offset = "NONE"

    id = query.port.get() or "1"
    port = mit.wlan.device[id].radio[1].port
    name = mit.wlan.device[id].radio[1].frequency_band.
                        aka(_("WLAN port frequency bandwith")).get_string()

    port.admin.aka(_("administrative status")).
            set_boolean(form.admin.as_boolean())
    port.tx_power.aka(_("power level")).set_link("/enum/wlan_tx_power/" ..
                                                   form.tx_power.get())

    mode_admin = form.mode_admin.get()
    if port.coex.exists() then
       port.coex.aka(_("coexistense mode")).set_boolean(form.coex.as_boolean())
    end

    if port.rts_cts.exists() and string.find(name, "5 GHz") then
       port.rts_cts.aka(_("RTS/CTS")).set_boolean(form.rts_cts.as_boolean())
    end

    phy_type_new = form.phy_type.get()
    phy_type_old = port.phy_type.name.aka(_("current mode")).get_string()

    if phy_type_new ~= phy_type_old then
        port.phy_type.aka(_("mode")).set_string(phy_type_new)
        mode_admin = "auto"
    end

    if mode_admin == "auto" then
        local period = form.auto_rescan_period.get()

        if period ~= nil then
            port.auto_rescan_period.aka(_("period")).set_string(form.auto_rescan_period.get())
        end

        form.primary_channel.admin = "Auto"
    else if mode_admin == "manual" then
        offset = form.offset.get()
        end
    end
    port.channel.aka(_("primary channel administrative number")).
                        set_string(form.primary_channel.admin.get())

    if (port.channel_sup_below.exists() and
        mode_admin == "manual") then
        local ch_node, ch_id
        local below_not_empty = false

        for ch_id, ch_node in port.channel_sup_below.as_iter() do
            below_not_empty = true
            break
        end

        if (below_not_empty and offset ~= nil) then
            port.secondary_channel.admin_offset.
                aka(_("secondary channel administrative position")).
                set_string(offset)
        end
    end
    t:close()
end


local function sort_cb(a, b)
    local a_num = tonumber(a.name())
    local b_num = tonumber(b.name())

    return (a_num > b_num)
            and 1
            or (a_num < b_num)
                and -1
                or 0
end


function wireless_port.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local count     = 0

    local list, id, node, dev_id, dev, wp_list, cport, hport, name

    wp_list = form.wp_list.create()

    for dev_id, dev in mit.wlan.device.
                        aka(_("WLAN device set")).as_iter() do
        local below_not_empty = 0

        cport = dev.radio[1].port
        hport = wp_list[dev_id].create()
        name = dev.radio[1].frequency_band.
                        aka(_("WLAN port frequency bandwith")).get_string()
        hport.name = name
        count = count + 1

        -- Transfer power level set
        list = hport.tx_power_list.create()
        for id, node in mit.enum.wlan_tx_power.
                            aka(_("power level set")).
                            iaka(_("%s power level")).as_iter() do
            list[node.value.aka(_("value")).as_string()] = id
        end
        list.sort(sort_cb)

        -- Transfer auto rescan period set
        list = hport.auto_rescan_period_list.create()
        for id, node in mit.enum.wlan_auto_rescan_period.
                            aka(_("auto rescan period set")).
                            iaka(_("%s period")).as_iter() do
            list[node.value.aka(_("value")).as_string()] = id
        end
        list.sort(sort_cb)

        -- Transfer mode set
        list = hport.phy_type_list.create()
        if cport.phy_type_sup.exists() then
            for id, node in cport.phy_type_sup.
                                aka(_("supported mode set")).
                                iaka(_("\"%s\" mode")).as_iter() do
                list[mit.enum.wlan_phy_type[id].value.
                                aka(_("value")).as_string()] = id
            end
        else
            for id, node in mit.enum.wlan_phy_type.
                                aka(_("mode set")).
                                iaka(_("\"%s\" mode")).as_iter() do
                list[node.value.aka(_("value")).as_string()] = id
            end
        end

        -- Transfer channel set
        list = hport.channel_list_below.create()
        if cport.channel_sup_below.exists() then
            for id, node in cport.channel_sup_below.
                                aka(_("channel setting set")).
                                iaka(_("\"%s\" channel setting")).as_iter() do
                list[mit.enum.wlan_channel_value[id].value.
                                aka(_("value")).as_string()] = id
                below_not_empty = 1
            end
            list.sort(sort_cb)

            if below_not_empty == 1 then
                list = hport.channel_list_above.create()
            else
                list = hport.channel_list.create()
            end
            
            for id, node in cport.channel_sup_above.
                                aka(_("channel setting set")).
                                iaka(_("\"%s\" channel setting")).as_iter() do
                list[mit.enum.wlan_channel_value[id].value.
                                aka(_("value")).as_string()] = id
            end
            list.sort(sort_cb)
        else
            list = hport.channel_list.create()
            for id, node in mit.enum.wlan_channel_value.
                                aka(_("channel setting set")).
                                iaka(_("\"%s\" channel setting")).as_iter() do
                list[node.value.aka(_("value")).as_string()] = id
            end
            list.sort(sort_cb)
        end

        --
        -- Transfer port parameters
        --
        hport.oper = cport.oper.aka(_("operating status")).get_boolean()
        hport.admin = cport.admin.aka(_("administrative status")).get_boolean()
        if cport.coex.exists() then
            hport.coex = cport.coex.aka(_("coexistense mode")).get_boolean()
        else
            hport.coex = "none"
        end

        if cport.rts_cts.exists() and string.find(name, "5 GHz") then
            hport.rts_cts = cport.rts_cts.aka(_("RTS/CTS")).get_boolean()
        else
            hport.rts_cts = "none"
        end

        hport.tx_power = cport.tx_power.name.aka(_("power level")).get_string()
        hport.phy_type = cport.phy_type.name.aka(_("mode")).get_string()
        hport.auto_rescan_period = cport.auto_rescan_period.name.aka(_("period")).get_string()

        hport.primary_channel.admin =
            cport.channel.name.
                aka(_("primary channel administrative number")).
                get_string()
        hport.primary_channel.oper =
            cport.oper_channel.name.
                aka(_("primary channel operating number")).
                get_string()

        if below_not_empty == 1 and cport.secondary_channel.supported.get_boolean() then
            hport.secondary_channel.position.oper =
                cport.secondary_channel.oper_offset.name.
                    aka(_("secondary channel operating position")).
                    get_string()
            hport.secondary_channel.position.admin =
                cport.secondary_channel.admin_offset.name.
                    aka(_("secondary channel administrative position")).
                    get_string()
        end

        hport.country = cport.country.name.aka(_("country name")).get_string()
    end
    form.wp_count = count
    t:close()
end


return wireless_port


