---
-- Storage device list WebUI module.
-- @release $Id: storage_devices.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local int               = require("webui.int")
local storage_devices   = {}


function storage_devices.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local storage   = t:mit().storage
    local id
    local node
    local item

    for id, item in form.unit.iter() do
        node = storage.unit[id]

        if node.instanceof("st_media") then

            if item.delete.as_boolean() then
                storage.del_unit.aka("delete").exec(
                    {link = crm.value.string(node.get_path())})
            elseif item.ejected.exists() then
                local ejected = item.ejected.as_boolean()

                node.eject.aka(ejected and _("eject") or _("insert")).
                           exec({insert = crm.value.boolean(not ejected)})
            else
                node.name.aka(_("name")).set(
                    item.new_name.aka(_("name")).req_nonblank().
                        as_crm_string())

                node.admin.aka(_("administrative status")).set(
                    item.admin.aka(_("administrative status")).
                        as_crm_boolean())
            end
        end
    end

    t:close()
end


local function fetch_device(item, node)
    local name
    local oper

    name = node.name.aka(_("name")).get_string()
    node.aka(string.format("\"%s\"", name))

    item.name       = name
    item.new_name   = name
    item.vendor     = node.vendor.aka(_("vendor")).get_string()
    item.model      = node.model.aka(_("model")).get_string()
    item.serial     = node.serial.aka(_("serial")).get_string()
    item.admin      = node.admin.aka(_("administrative status")).
                                                    get_boolean()
    item.ejected    = node.ejected.aka(_("ejection status")).
                                                    get_boolean()
    item.connected  = node.connected.aka(_("connection status")).
                                                    get_boolean()

    oper            = node.oper.aka(_("operating status")).
                                                    get_boolean()
    item.oper       = oper

    if oper then
        item.capacity.value, item.capacity.unit =
            node.capacity.aka(_("capacity")).
                get_int_u64():decimal_scaled_bytes()
    end
end


local function lookup_device(unit)
    local id

    if unit.instanceof("st_media") then
        return unit
    end

    for id, unit in unit.lower.as_iter() do
        unit = lookup_device(unit.deref())
        if unit ~= nil then
            return unit
        end
    end

    return nil
end


local function select_aux_sw_device(unit_list, extfs)
    if extfs.oper.aka(_("operating status")).get_boolean() then
        local unit = extfs.storage_unit.aka(_("storage volume"))
        if unit.deref() and unit.exists() then
            unit = lookup_device(unit)
            unit_list[unit.get_name()].aux_sw_hosted = true
        end
    end
end


function storage_devices.fetch(conf, query, prvt, form)
    local t     = crm.transaction():webui_open_ro()
    local mit   = t:mit()
    local extfs = mit.extfs.aka(_("auxiliary software"))
    local id
    local node

    for id, node in mit.storage.unit.aka(_("unit set")).
                                     iaka(_("unit #%s")).as_iter() do
        if node.instanceof("st_media") then
            fetch_device(form.unit[id].create(), node)
        end
    end

    if extfs.exists() and extfs.supported.get_boolean() then
        select_aux_sw_device(form.unit, extfs)
    end

    t:close()
end


return storage_devices
