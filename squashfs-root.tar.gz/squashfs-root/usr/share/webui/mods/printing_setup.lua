---
-- Printing setup WebUI module.
-- @release $Id: printing_setup.lua 140715 2009-11-25 08:31:03Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local printing_setup    = {}

function printing_setup.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local printing  = t:mit().printing
    local smb       = t:mit().samba

    printing.admin.aka(_("administrative status")).set_boolean(
                                                form.admin.as_boolean())
    if smb.exists() then
        smb.admin.aka(_("administrative status")).
            set_boolean(form.smb.admin.as_boolean())
        smb.workgroup.aka(_("workgroup")).
            set_string(form.smb.workgroup.aka(_("workgroup")).
                       req_nonblank().get())
        smb.netbios_name.aka(_("server name")).
            set_string(form.smb.netbios_name.aka(_("server name")).
                       req_nonblank().get())
        smb.server_string.aka(_("server description")).
            set_string(form.smb.server_string.
                        aka(_("server description")).get())
    end

    t:close()
end


function printing_setup.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local printing  = t:mit().printing
    local smb       = t:mit().samba

    form.oper = printing.oper.aka(_("operating status")).get_boolean()
    form.admin = printing.admin.aka(_("administrative status")).
                                        get_boolean()
    if smb.exists() then
        form.smb.oper = smb.oper.aka(_("operating status")).
                                get_boolean()
        form.smb.admin = smb.admin.aka(_("administrative status")).
                                get_boolean()
        form.smb.workgroup = smb.workgroup.aka(_("workgroup")).
                                get_string()
        form.smb.netbios_name = smb.netbios_name.aka(_("server name")).
                                    get_string()
        form.smb.server_string = smb.server_string.
                                aka(_("server description")).get_string()
end

    t:close()
end


return printing_setup
