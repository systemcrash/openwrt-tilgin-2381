---
-- WebUI development controls WebUI module.
-- @release $Id:$
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local webui_dev = {}


local function apply_c11n(crm_c11n, form_c11n)
    local admin = form_c11n.admin.as_boolean()

    if not admin then
        crm_c11n.admin.set_boolean(admin)
    end

    crm_c11n.location.set_string(form_c11n.location.get())

    if admin then
        crm_c11n.admin.set_boolean(admin)
    end
end


function webui_dev.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()

    mit.httpd.webui.proto.set_string(form.proto.get())
    mit.webui.debug.set_boolean(form.debug.as_boolean())
    apply_c11n(mit.webui.c11n.aka(_("customization")),
               form.c11n.aka(_("customization")))

    if form.action.get() == "restart" then
        mit.httpd.webui.restart.aka(_("restart WebUI")).exec()
    end

    t:close()
end


local function fetch_c11n(form_c11n, crm_c11n)
    form_c11n.oper = crm_c11n.oper.as_number()
    form_c11n.admin = crm_c11n.admin.as_number()
    form_c11n.location = crm_c11n.location.get_string()
end


function webui_dev.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local id, proto

    form.proto = mit.httpd.webui.proto.name.get_string()
    for id, proto in mit.enum.httpd_app_proto.as_iter() do
        form.proto[id] = proto.name.get_string()
    end

    form.debug = mit.webui.debug.as_number()

    fetch_c11n(form.c11n.create(), mit.webui.c11n.aka(_("customization")))

    t:close()
end


return webui_dev


