---
-- Switch filter creating WebUI module.
-- @release $Id: qos_flow_new.lua 138153 2009-09-14 15:36:15Z nikolai.kondrashov $
--

local crm                       = require("webui.crm")
local hdf                       = require("webui.hdf")
local webui_mods                = {}
webui_mods.switch               = {}
webui_mods.switch.filter_set    = require("webui_mods.switch.filter_set")
local switch_filter_new         = {}


function switch_filter_new.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()

    prvt.id = webui_mods.switch.filter_set.add(
                t:mit().ethernet.switch.super.filter,
                form.label.aka(_("label")).get())

    t:close()
end


function switch_filter_new.fetch(conf, query, prvt, form)
    form.created_id = prvt.id
end


return switch_filter_new



