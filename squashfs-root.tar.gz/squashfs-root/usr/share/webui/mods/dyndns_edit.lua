---
-- Dyndns records edit WebUI module.
-- @release $Id:$
--

local crm               = require("webui.crm")
local webui_mods        = {}
webui_mods.conn         = {}
webui_mods.conn.tree    = require("webui_mods.conn.tree")
webui_mods.conn.fppool  = require("webui_mods.conn.fppool")
webui_mods.conn.slct    = require("webui_mods.conn.slct")
local dyndns_edit       = {}


function dyndns_edit.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local mit       = t:mit()
    local id
    local node

    id = query.id.get()
    if not id then
        error(_("Failed to get dyndns entry id"))
    end

    form.friendlyname.req_nonempty()

    node = mit.dyndns.table[id]
    if node.exists() then
        local action = form.action.get()

        if action == "delete" then
            mit.dyndns.del.exec(
                {link = crm.value.link(node.get_path())})
            prvt.deleted = true
        elseif action == "renew" then
            node.renew.aka(_("dyndns renew")).exec()
        else
            local conn  = webui_mods.conn.slct.get_path(form)
            local admin = form.admin.as_boolean()
            local password = form.password.get()
            local hidd_password = form.hidd_password.get()
            local server_type = form.server.type.get()
            local url = nil

            if server_type == "wellknown" then
                url = form.server.wellknown.aka(_("well-known server")).get()
            elseif server_type == "custom" then
                url = form.server.custom.aka(_("custom server")).get()
            elseif server_type == "" then
                error(_("Server type is not set"))
            else
                error(_("Invalid server type"))
            end

            if admin then
                if url == nil or url == "" then
                    error(_("Server URL isn't specified"))
                end 
                if (not conn or conn == "") then
                    error(_("Connection is not specified"))
                end
            end
            node.friendlyname.aka(_("name")).
                set_string(form.friendlyname.aka(_("name")).get())
            node.hostname.aka(_("hostname")).
                set_string(form.hostname.aka(_("hostname")).get())
            node.server.aka(_("server url")).set_string(url)
            node.port.aka(_("server port")).set_u16(
                                        form.port.aka(_("server port")).
                                            req_range(0,65535))
            node.user.aka(_("user")).
                set_string(form.user.aka(_("user")).get())

            node.token.aka(_("token")).
                set_string(form.token.aka(_("token")).get())

            if password ~= hidd_password then
                node.passwd.aka(_("password")).set_string(password)
            end

            node.renew_timeout.aka(_("renew timeout")).set_u32(
                                    form.renew_timeout.aka(_("renew timeout")))
            node.retry_timeout.aka(_("retry timeout")).set_u32(
                                    form.retry_timeout.aka(_("retry timeout")))

            local targetip_type = form.targetip.type.aka(_("Target IP type")).get()
            node.ip_mode.aka(_("target ip mode")).set_link("/enum/ddns_ip_mode/" ..
                                                   targetip_type)
            if targetip_type == "Manual" then
                node.ip.aka(_("ip")).set(form.targetip.custom.aka(_("custom ip")).as_crm_ip_addr())    
            end
            node.admin.aka(_("administrative status")).set_boolean(admin)

            node.conn.set_link(conn or "")
        end
    end

    t:close()
end

local server_list = {
    {
        name = "DynDNS", 
        url= "https://[USERNAME]:[PASSWORD]@members.dyndns.org/nic/update?hostname=[DOMAIN](&myip=[IP])",
        service_provider = "dyndns"
    },
    {
        name = "NoIP", 
        url = "https://[USERNAME]:[PASSWORD]@dynupdate.no-ip.com/nic/update?hostname=[DOMAIN](&myip=[IP])",
        service_provider = "noip"
    },
    {   
        name = "ChangeIP", 
        url = "https://[USERNAME]:[PASSWORD]@nic.changeip.com/nic/update?u=[USERNAME]&p=[PASSWORD]&cmd=update&hostname=[DOMAIN](&ip=[IP])",
        service_provider = "changeip"
    },
    {
        name = "DNSdynamic", 
        url = "https://[USERNAME]:[PASSWORD]@www.dnsdynamic.org/api/?hostname=[DOMAIN](&myip=[IP])",
        service_provider = "dnsdynamic"
    },
    {
        name = "EntryDNS",
        url = "https://entrydns.net/records/modify/[TOKEN](?ip=[IP])",
        service_provider = "entrydns"
    },
    {
        name = "DuckDNS",
        url = "https://www.duckdns.org/update?domains=[DOMAIN]&token=[TOKEN](&ip=[IP])",
        service_provider = "duckdns"
    }
}

function dyndns_server_fetch(form, url)
    local itm_id
    local itm
    local new_itm
    local found = false
    for itm_id, itm in ipairs(server_list) do
        new_itm = form.dyndns_server[itm.service_provider].create()
        new_itm.name = itm.name
        new_itm.server = itm.url
        if url == itm.url then
            form.server.wellknown = url
            form.server.type = "wellknown"
            found = true
        end
    end

    if found == false then
        form.server.custom = url
        form.server.type = "custom"
    end
end 

function dyndns_edit.fetch(conf, query, prvt, form)

    if prvt.deleted.as_boolean() then
        return
    end

    local t             = crm.transaction():webui_open_ro()
    local mit           = t:mit()
    local id
    local node
    local item
    local url
    webui_mods.conn.tree.smmr(form, mit)
    webui_mods.conn.fppool.list(form, mit)

    id = query.id.get()
    if not id then
        error(_("Failed to get dyndns entry id"))
    end

    node = mit.dyndns.table[id]
    
    if node.exists() then
        form.friendlyname       = node.friendlyname.get_string()
        form.hostname           = node.hostname.get_string()
        url                     = node.server.get_string()
        form.port               = node.port.as_string()
        form.user               = node.user.get_string()
        form.password           = node.passwd.get_string()
        form.oper               = node.oper.get_boolean()
        form.admin              = node.admin.get_boolean()
        form.renew_timeout      = node.renew_timeout.as_string()
        form.retry_timeout      = node.retry_timeout.as_string()
        form.targetip.custom    = node.ip.get_octets_as_ip_addr()
        form.targetip.type      = node.ip_mode.name.aka(_("Target IP mode")).get_string()

        form.password           = string.gsub(tostring(form.password),
                                              "(.)",
                                              function(a) return '*' end)
        form.token              = node.token.get_string()

        webui_mods.conn.slct.id(form, node.conn.get_link(), mit)


    end

    dyndns_server_fetch(form, url)

    t:close()
end


return dyndns_edit
