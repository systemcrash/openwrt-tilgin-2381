---
-- Storage user creating WebUI module.
-- @release $Id: storage_user_new.lua 134347 2009-06-04 10:16:41Z nikolai.kondrashov $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local req               = require("webui_mods.storage.account").req
local storage_user_new  = {}


function storage_user_new.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local ac        = t:mit().storage.ac
    local name
    local password
    local index
    local user
    local ok, e

    name = req.name(form.name.aka(_("name"))).get()
    password = req.password(form.password.aka(_("password"))).get()

    index = ac.user.add.exec({}, {"index"})
    user = ac.user.table[index:as_string()]

    ok, e = pcall(function ()
        user.name.aka(_("name")).set_string(name)
        user.password.aka(_("password")).set_string(password)
        user.admin.aka(_("administrative status")).set_boolean(true)
        user.allow_http_access.set_boolean(true)
        user.allow_smb_access.set_boolean(true)
    end)

    if not ok then
        ac.user.del.exec({index = index}, {})
        error(e)
    end

    t:close()
end


return storage_user_new


