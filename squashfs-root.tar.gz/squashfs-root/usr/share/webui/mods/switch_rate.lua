---
-- Switch rate limit management WebUI module.
-- @release $Id: switch_rate.lua 167030 2014-06-08 12:36:59Z maxim.menshchikov $
--

local crm                   = require("webui.crm")
local hdf                   = require("webui.hdf")
local int                   = require("webui.int")
local webui_mods            = {}
webui_mods.switch           = {}
webui_mods.switch.if_set    = require("webui_mods.switch.if_set")
local switch_rate           = {}
local kiara                 = false


local unit_base_mul = int.u32(2 ^ 10)

local unit_list = {
    {name = "Kbps", mul = int.u32(2 ^ 0)},
    {name = "Mbps", mul = int.u32(2 ^ 10)},
--  {name = "Gbps", mul = int.u32(2 ^ 20)},
}


local function apply_rate(c_rate, h_rate, c_max_rate)
    local max_value
    local mul, num
    local value

    if h_rate.mul.is_blank() then
        return
    end

    mul = int.u32(h_rate.mul.aka(_("multiplier")).req_number().get())
    num = int.u32(h_rate.num.is_blank()
                    and 0
                     or h_rate.num.aka(_("value")).req_number().get())

    max_value = c_max_rate.get_int_u32() / unit_base_mul

    if (num > (max_value / mul)) then
        value = int.u32(0)
    else
        value = num * mul
    end

    c_rate.set_int_u32(value)
end


local function apply_port(c_port, h_port)
    apply_rate(c_port.ingress_rate_limit.aka(_("ingress rate limit")),
               h_port.ingress.aka(_("ingress rate limit")),
               c_port.max_downstream_bitrate.
                        aka(_("maximum downstream bitrate")))

    apply_rate(c_port.egress_rate_limit.aka(_("egress rate limit")),
               h_port.egress.aka(_("egress rate limit")),
               c_port.max_upstream_bitrate.
                        aka(_("maximum upstream bitrate")))
end


function switch_rate.apply(conf, query, form, prvt)
    local t             = crm.transaction():webui_open_rw()
    local mit           = t:mit()
    local h_port_list   = form.port.iaka(_("port #%s"))

    -- Apply ports
    for port_id, c_port in
        webui_mods.switch.if_set.as_port_iter(
            mit.ethernet.switch.super.available.
                aka(_("interface set")).iaka(_("interface #%s"))) do
        apply_port(c_port, h_port_list[port_id])
    end

    t:close()
end


local function fetch_rate(h_rate, c_rate, c_max_rate)
    local value
    local max_value
    local unit_index, unit, last_unit

    max_value = c_max_rate.get_int_u32() / unit_base_mul
    value = c_rate.get_int_u32()

    if (value > int.u32(0)) and (value < max_value) then
        for unit_index, unit in ipairs(unit_list) do
            if (value % unit.mul) > int.u32(0) then
                break
            end
            last_unit = unit
        end

        h_rate.num = tostring(value / last_unit.mul)
        h_rate.mul = tostring(last_unit.mul)
    end
end


local function fetch_port(h_port, c_port)
    h_port.name = c_port.name.aka(_("name")).get_string()
    h_port.hide_ingress = 
        kiara and not c_port.wan.aka(_("port WAN")).get_boolean()

    fetch_rate(h_port.ingress,
               c_port.ingress_rate_limit.
                        aka(_("ingress rate limit")),
               c_port.max_downstream_bitrate.
                        aka(_("maximum downstream bitrate")))

    fetch_rate(h_port.egress,
               c_port.egress_rate_limit.
                        aka(_("egress rate limit")),
               c_port.max_upstream_bitrate.
                        aka(_("maximum upstream bitrate")))
end


function switch_rate.fetch(conf, query, prvt, form)
    local t             = crm.transaction():webui_open_ro()
    local mit           = t:mit()
    local h_unit_list   = form.unit.create()
    local h_port_list   = form.port.create()

    kiara = mit.ethernet.hwswitch.name.aka(_("hwswitch name")).
                get_string() == "ifx"

    -- Output units
    for unit_index, unit in ipairs(unit_list) do
        h_unit_list[tostring(unit.mul)] = unit.name
    end

    -- Fetch ports
    for port_id, c_port in
        webui_mods.switch.if_set.as_port_iter(
            mit.ethernet.switch.super.available.
                aka(_("interface set")).iaka(_("interface #%s"))) do
        fetch_port(h_port_list[port_id].create(), c_port)
    end

    t:close()
end


return switch_rate
