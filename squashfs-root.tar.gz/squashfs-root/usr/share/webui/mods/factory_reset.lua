---
-- Factory reset WebUI module.
-- @release $Id:$
--

local crm           = require("webui.crm")
local factory_reset = {}


function factory_reset.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()

    mit.system.factory_reset.
        aka(_("reset configuration to factory defaults")).exec()
    prvt.reset = true

    t:close()
end


function factory_reset.fetch(conf, query, prvt, form)
    form.reset = prvt.reset.get()
end


return factory_reset
