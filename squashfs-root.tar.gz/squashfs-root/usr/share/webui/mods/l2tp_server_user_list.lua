---
-- L2TP user list WebUI module.
-- @release $Id:  $
--

local crm               = require("webui.crm")
local hdf               = require("webui.hdf")
local l2tp_server_user_list = {}


local function apply_user(l2tp, c_user, h_user, context)
    local id
    local group
    local secret = h_user.secret.aka(_("password")).req_nonempty().get()

    c_user.username.aka(_("name")).
            set_string(h_user.username.aka(_("name")).get())
    c_user.secret.aka(_("password")).
            set_string(h_user.secret.get())

    if context == "ppp" then
        c_user.pap.aka(_("PAP authentication")).
                set_boolean(h_user.pap.as_boolean())
        c_user.chap.aka(_("CHAP authentication")).
                set_boolean(h_user.chap.as_boolean())
    end
end


function l2tp_server_user_list.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local l2tp        = t:mit().l2tp

    local id
    local h_user
    
    local context = query.context.get()
    if not context and not (context == "ppp" or context == "l2tp") then
        error(_("Incorrect context."))
    end

    for id, h_user in form.user.iter() do
        local c_user
        if context == "ppp" then
            c_user = l2tp.ppp_user.table[id]
        elseif context == "l2tp" then
            c_user = l2tp.l2tp_user.table[id]
        end
        if c_user.exists() then
            if h_user.delete.as_boolean() then
                if context == "ppp" then
                    l2tp.ppp_user.del.exec({ link = crm.value.link(c_user.get_path()) })
                elseif context == "l2tp" then
                    l2tp.l2tp_user.del.exec({ link = crm.value.link(c_user.get_path()) })
                end
            else
                apply_user(l2tp, c_user, h_user, context)
            end
        end
    end

    t:close()
end

function l2tp_server_user_list.fetch(conf, query, prvt, form)
    local t           = crm.transaction():webui_open_rw()
    local l2tp        = t:mit().l2tp
    local id
    local node
    local item
    local iter_table
    local context = query.context.get()
    if not context and not (context == "ppp" or context == "l2tp") then
        error(_("Incorrect context."))
    end
    if context == "ppp" then
        iter_table = l2tp.ppp_user.table.as_iter()
    elseif context == "l2tp" then
        iter_table = l2tp.l2tp_user.table.as_iter()
    end
    form.sec_context = context
    for id, node in iter_table do
        item = form.user[id].create()

        item.username               = node.username.get_string()
        item.secret                 = node.secret.get_string()
        item.pap                    = node.pap.get_boolean()
        item.chap                   = node.chap.get_boolean()
    end

    t:close()
end


return l2tp_server_user_list
