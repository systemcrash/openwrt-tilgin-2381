---
-- Terminal equipment status WebUI module.
-- @release $Id:$
--

local crm   = require("webui.crm")
local te = {}

function te.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local usb_upper         = mit.port.USB.upper

    if not mit.term_equip.exists() then
        form.supported = false
        t:close()
        return
    end

    form.supported = true

    for id, c_upper in usb_upper.as_iter() do
        local type =  c_upper.iface.type.as_string()
        if type == "usb_serial_if" or type == "usb_eth_if" then
            if #c_upper.iface.usb_dev.get_link() ~= 0 then
                local item          = form.mt_list[id].create()
                local te_node       = c_upper.iface.prop.te.link
                local manuf         = te_node.mt.manuf.aka(_("manufacturer")).get_string()
                local model         = te_node.mt.model.aka(_("model")).get_string()

                if model:find(manuf) ~= nil then
                    item.name = model
                else
                    item.name = manuf .. " " .. model
                end

                item.status         = te_node.pin.status.name.get_string()

            end
        end
    end

    t:close()
end


return te
