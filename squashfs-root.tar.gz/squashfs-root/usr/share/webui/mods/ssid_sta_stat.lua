---
-- Associated client statistics module
-- @release $Id:$
---

local crm = require("webui.crm")
local ssid_sta_stat = {}

function ssid_sta_stat.fetch(conf, query, prvt, form)
    local t         = crm.transaction():webui_open_ro()
    local mit       = t:mit()
    local sta_id, ssid_id, node

    sta_id = query.sta.get()
    ssid_id = query.ssid.get()
    if not sta_id or not ssid_id then
        error(_("Failed to get station id"))
    end

    form.mac       = mit["if"].table[ssid_id].sta[sta_id].
                        mac.aka("MAC address").get_octets_as_mac_addr()

    node           = mit["if"].table[ssid_id].sta[sta_id].stat
    form.tx_rate   = node.tx_rate.aka(_("tx rate")).get_int_u32()
    form.rx_rate   = node.rx_rate.aka(_("rx rate")).get_int_u32()
    form.standards = node.standards.aka(_("standards")).get_string()

    form.rssi = node.rssi.aka(_("RSSI")).get_s32()
    form.out_bytes      = node.out_bytes.aka(_("out bytes")).get_int_u64()
    form.in_bytes       = node.in_bytes.aka(_("in bytes")).get_int_u64()
    form.out_packets    = node.out_packets.aka(_("out packets")).get_int_u64()
    form.in_packets     = node.in_packets.aka(_("in packets")).get_int_u64()
    form.out_unicast    = node.out_unicast.aka(_("out unicast")).get_int_u64()
    form.in_unicast     = node.in_unicast.aka(_("in unicast")).get_int_u64()

    t:close()
end

return ssid_sta_stat
