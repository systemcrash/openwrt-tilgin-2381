---
-- Storage folder list WebUI module.
-- @release $Id: storage_folder_list.lua 144246 2010-03-11 11:25:21Z nikolai.kondrashov $
--

local crm                   = require("webui.crm")
local hdf                   = require("webui.hdf")
local int                   = require("webui.int")
local storage_folder_list   = {}


function storage_folder_list.apply_folder(d, s)
    d.enabled = s.enabled.as_crm_boolean()
end


function storage_folder_list.apply_fs(d, s)
    local manage_dirs
    local mount_oper

    manage_dirs = d.manage_dirs.get_boolean()
    mount_oper = d.mount_oper.get_boolean()

    for id, item in s.folder.iter() do
        local node = d.dir.table[id]

        if node.exists() then
            local name = node.name.get_string()

            if manage_dirs and name ~= "/" or
               not manage_dirs and name == "/" then
                repeat
                    if manage_dirs and mount_oper then
                        if item.delete.as_boolean() then
                            d.dir.del.exec{link =
                                           crm.value.string(node.get_path())}
                            break
                        end
                        node.name.set_string(item.name.req_nonblank().get())
                    end

                    storage_folder_list.apply_folder(node, item)
                until true
            end
        end
    end

    local new_name = s.new_folder.name
    if manage_dirs and not new_name.is_empty() then
        d.dir.add.exec{name =
                       new_name.as_crm_string(),
                       enabled =
                       crm.value.boolean(true)}
    end
end


function storage_folder_list.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()
    local id
    local node
    local item

    for id, item in form.unit.iaka(_("unit #%s")).iter() do
        node = mit.storage.unit.iaka(_("unit #%s"))[id]

        if node.mountable.get_boolean() then
            storage_folder_list.apply_fs(node.fs, item.fs)
        end
    end

    t:close()
end


local function fetch_folder(d, s)
    d.enabled = s.enabled.get_boolean()
end


local function fetch_fs(d, s)
    local size
    local used
    local manage_dirs
    local id
    local node

    d.type = s.type.name.get_string()

    size = s.size.get_int_u64()
    used = s.used.get_int_u64()

    d.size.value, d.size.unit = size:decimal_scaled_bytes()
    d.used.value, d.used.unit = used:decimal_scaled_bytes()
    d.free.value, d.free.unit = (size - used):decimal_scaled_bytes()

    d.mount_oper    = s.mount_oper.get_boolean()
    d.mount_admin   = s.mount_admin.get_boolean()
    manage_dirs     = s.manage_dirs.get_boolean()
    d.manage_dirs   = manage_dirs

    for id, node in s.dir.table.as_iter() do
        local name = node.name.get_string()

        if manage_dirs and name ~= "/" or
           not manage_dirs and name == "/" then
            local item = d.folder[id].create()

            item.name = name
            fetch_folder(item, node)
        end
    end
end


function storage_folder_list.fetch(conf, query, prvt, form)
    local t     = crm.transaction():webui_open_ro()
    local mit   = t:mit()
    local id
    local node
    local item

    for id, node in mit.storage.unit.aka(_("unit set")).
                                     iaka(_("unit #%s")).as_iter() do
        if node.mountable.get_boolean() then
            local oper

            item = form.unit[id].create()

            item.type       = "volume"
            item.name       = node.name.aka(_("name")).get_string()
            item.admin      = node.admin.aka(_("administrative status")).
                                                            get_boolean()
            item.connected  = node.connected.aka(_("connection status")).
                                                            get_boolean()
            oper            = node.oper.aka(_("operating status")).
                                                            get_boolean()
            item.oper       = oper

            if oper then
                item.capacity.value, item.capacity.unit =
                    node.capacity.aka(_("capacity")).
                        get_int_u64():decimal_scaled_bytes()
            end

            fetch_fs(item.fs.create(), node.fs)
        end
    end

    t:close()
end


return storage_folder_list
