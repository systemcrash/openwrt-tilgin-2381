---
-- L2TP configuration module.
-- @release $Id:$
--

local crm   = require("webui.crm")
local webui_mods        = {}
webui_mods.lan          = {}
webui_mods.lan.grp_set  = require("webui_mods.lan.grp_set")
webui_mods.conn         = {}
webui_mods.conn.tree    = require("webui_mods.conn.tree")
webui_mods.conn.fppool  = require("webui_mods.conn.fppool")
webui_mods.conn.slct    = require("webui_mods.conn.slct")
local l2tp_server     = {}

local function classify_id(s)
    if not s or s == "%none" then
        return "none"
    end
    if s == "%fromcert" then
        return "fromcert"
    end
    if s:sub(1, 1) == "@" then
        return "exact"
    end
    return "ip";
end

local function truncate_id(s, s_class)
    if not s_class or s_class == "none" or s_class == "fromcert" or not s then
        return "";
    end
    if s_class == "exact" then
        return s:sub(2)
    end
    return s;
end

local function build_id(s, s_class, right)
    if not s_class or not s or s_class == "none" then
        return "%none"
    elseif s_class == "fromcert" then
        return "%fromcert"
    elseif s_class == "exact" then
        return "@" .. s
    elseif s_class == "ip" then
        return s
    else
        if right == true then
            return "%right"
        else
            return "%left"
        end
    end
end

function l2tp_server.apply(conf, query, form, prvt)
    local t                 = crm.transaction():webui_open_rw()
    local l2tp              = t:mit().l2tp
    local conn              = webui_mods.conn.slct.get_path(form)
    local group_path        = webui_mods.lan.grp_set.get_path(form)

    l2tp.noccp.aka(_("noccp")).set_boolean(not form.ccp.as_boolean())
    l2tp.novj.aka(_("novj")).set_boolean(not form.vj.as_boolean())
    l2tp.mru.aka(_("mru")).set(form.mru.aka(_("mru")).req_range(0, 10000).as_crm_u16())
    l2tp.mtu.aka(_("mtu")).set(form.mtu.aka(_("mtu")).req_range(0, 10000).as_crm_u32())
    l2tp.maxfail.aka(_("maxfail")).set(form.maxfail.aka(_("maxfail")).req_range(0, 100000).as_crm_u16())

    l2tp.lcp_echo_failure.aka(_("lcp_echo_failure")).set(form.lcp_echo_failure.aka(_("lcp_echo_failure")).req_range(0, 100000).as_crm_u16())
    l2tp.lcp_echo_interval.aka(_("lcp_echo_interval")).set(form.lcp_echo_interval.aka(_("lcp_echo_interval")).req_range(0, 100000).as_crm_u16())

    l2tp.dpd_delay.aka(_("dpd_delay"))
        .set(form.dpd_delay.aka(_("dpd_delay"))
        .req_range(1, 100000000).as_crm_u32())
    l2tp.dpd_timeout.aka(_("dpd_timeout"))
        .set(form.dpd_timeout.aka(_("dpd_timeout"))
        .req_range(1, 100000000).as_crm_u32())

    l2tp.max.aka(_("max")).set(form.max.aka(_("max")).req_number().as_crm_u8())
    --l2tp.port.aka(_("port")).set(form.port.aka(_("port")).req_range(0, 65535).as_crm_u16())

    if not conn or conn == "" then
        l2tp.conn.aka(_("connection")).set_link("")
    else
        l2tp.conn.aka(_("connection")).set_link(conn or "")
    end
    if not group_path or group_path == "" then
        l2tp.langr.aka(_("lan group")).set_link("")
    else
        l2tp.langr.aka(_("lan group")).set_link(group_path)
    end
    l2tp.admin.aka(_("enabled")).set_boolean(form.enabled.as_boolean())

    local ipsec = form.ipsec.as_boolean()
    l2tp.ipsec.aka(_("IPSEC")).set_boolean(ipsec)

    local authby_secret = form.authby_secret.as_boolean()
    l2tp.authby_secret.set_boolean(authby_secret)
    if authby_secret == true then
        l2tp.psk.aka(_("PSK")).set_string(form.psk.aka("Pre-shared key").req_nonempty().get())
    else
        local certr = form.certr.get()
        local certl = form.certl.get()
        if not certr or certr == "" then
            certr = nil 
        else
            certr = "/security/certificate/store/table/" .. certr
        end
        if not certl or certl == "" then
            if ipsec == true then
                error(_("Local certificate must be set"))
            end
            certl = nil
        else
            certl = "/security/certificate/store/table/" .. certl
        end
        l2tp.cert_r.aka(_("Remote certificate")).set_link(certr)
        l2tp.cert_l.aka(_("Local certificate")).set_link(certl)
    end

    local id_l_origin = form.id_l_origin.get()
    local id_l = form.id_l.get()
    l2tp.id_l.aka(_("Local ID")).set_string(build_id(id_l, id_l_origin, false))

    local id_r_origin = form.id_r_origin.get()
    local id_r = form.id_r.get()
    l2tp.id_r.aka(_("Remote ID")).set_string(build_id(id_r, id_r_origin, true))

    local radius = form.radius.as_boolean()
    l2tp.radius.aka(_("RADIUS state")).set_boolean(radius)
    if radius == true then
        form.authserver.aka("Authentication server").req_nonempty()
        form.authsecret.aka("Authentication server secret").req_nonempty()
        form.acctserver.aka("Account server").req_nonempty()
        form.acctsecret.aka("Account server secret").req_nonempty()
    end
    l2tp.authserver.aka(_("Authentication server")).set_string(form.authserver.aka("Authentication server").get())
    l2tp.authsecret.aka(_("Authentication server secret")).set_string(form.authsecret.aka("Authentication server secret").get())
    l2tp.acctserver.aka(_("Account server")).set_string(form.acctserver.aka("Account server").get())
    l2tp.acctsecret.aka(_("Account server secret")).set_string(form.acctsecret.aka("Account server secret").get())
    l2tp.nas_identifier.aka(_("NAS identifier")).set_string(form.nas_identifier.aka("NAS identifier").get())
    l2tp.radius_timeout.aka(_("Timeout")).set(form.radius_timeout.aka("Timeout").req_range(0, 10000).as_crm_u32())
    l2tp.radius_retries.aka(_("Retries")).set(form.radius_retries.aka("Retries").req_range(0, 10000).as_crm_u32())

    l2tp.ppp_auth_required.aka(_("Require authentication")).set_boolean(form.ppp_auth_required.as_boolean())
    l2tp.ppp_auth_pap.aka(_("PAP auth")).set_boolean(form.ppp_auth_pap.as_boolean())
    l2tp.ppp_auth_chap.aka(_("CHAP auth")).set_boolean(form.ppp_auth_chap.as_boolean())
    l2tp.ppp_auth_mschap.aka(_("MS-CHAP auth")).set_boolean(form.ppp_auth_mschap.as_boolean())
    l2tp.ppp_auth_mschap2.aka(_("MS-CHAPv2 auth")).set_boolean(form.ppp_auth_mschap2.as_boolean())

    l2tp.l2tp_challenge.aka(_("L2TP challenge")).set_boolean(form.l2tp_challenge.as_boolean())

    t:close()
end

function l2tp_server.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local l2tp              = t:mit().l2tp
    local cert              = t:mit().security.certificate

    local item
    local id
    local node

    local current_certr
    local current_certl

    local current_psk

    form.oper = l2tp.oper.aka(_("operating status")).get_boolean()
    form.ccp = not l2tp.noccp.aka(_("noccp")).get_boolean()
    form.vj = not l2tp.novj.aka(_("novj")).get_boolean()
    form.mru = l2tp.mru.aka(_("mru")).as_string()
    form.mtu = l2tp.mtu.aka(_("mtu")).as_string()
    form.maxfail = l2tp.maxfail.aka(_("maxfail")).as_string()

    form.lcp_echo_failure = l2tp.lcp_echo_failure.aka(_("lcp_echo_failure")).as_string()
    form.lcp_echo_interval = l2tp.lcp_echo_interval.aka(_("lcp_echo_interval")).as_string()

    form.dpd_delay   = l2tp.dpd_delay.aka(_("dpd_delay")).as_string()
    form.dpd_timeout = l2tp.dpd_timeout.aka(_("dpd_timeout")).as_string()
    form.max = l2tp.max.aka(_("max")).as_string()
    --form.port = l2tp.port.aka(_("port")).as_string()

    form.enabled = l2tp.admin.aka(_("enabled")).get_boolean()

    form.ipsec = l2tp.ipsec.aka(_("IPSEC")).get_boolean()

    webui_mods.lan.grp_set.smmr(form, mit)
    webui_mods.lan.grp_set.fetch_client_list(form, mit)
    webui_mods.lan.grp_set.slct_path(form, l2tp.langr.get_link())

    webui_mods.conn.tree.smmr(form, mit)
    webui_mods.conn.fppool.list(form, mit)
    webui_mods.conn.slct.id(form, l2tp.conn.get_link(), mit)

    for id, node in cert.store.table.as_iter() do
        item = form.cert[id].create()
        item.name = node.subject.get_string()
        local private = node.private.get_string()
        if private ~= nil and private ~= "" then
            item.has_private = 1
        else
            item.has_private = 0
        end
    end

    form.authby_secret = l2tp.authby_secret.aka(_("Auth by secret")).get_boolean()
    form.psk = l2tp.psk.aka(_("PSK")).get_string()
    current_certr = l2tp.cert_r.aka(_("Remote certificate")).get_link()
    current_certl = l2tp.cert_l.aka(_("Local certificate")).get_link()
    form.certl = current_certl:match("^/security/certificate/store/table/([^/]+)")
    form.certr = current_certr:match("^/security/certificate/store/table/([^/]+)")
    
    local id_l = l2tp.id_l.aka(_("Local ID")).get_string()
    local id_l_origin = classify_id(id_l)
    form.id_l_origin = id_l_origin
    form.id_l = truncate_id(id_l, id_l_origin)

    local id_r = l2tp.id_r.aka(_("Remote ID")).get_string()
    local id_r_origin = classify_id(id_r)
    form.id_r_origin = id_r_origin
    form.id_r = truncate_id(id_r, id_r_origin)
    
    form.radius = l2tp.radius.aka(_("Radius state")).get_boolean()
    form.authserver = l2tp.authserver.aka(_("Authentication server")).get_string()
    form.authsecret = l2tp.authsecret.aka(_("Auth server secret")).get_string()
    form.acctserver = l2tp.acctserver.aka(_("Account server")).get_string()
    form.acctsecret = l2tp.acctsecret.aka(_("Account server secret")).get_string()
    form.nas_identifier = l2tp.nas_identifier.aka(_("NAS identifier")).get_string()
    form.radius_timeout = l2tp.radius_timeout.aka(_("Timeout")).as_string()
    form.radius_retries = l2tp.radius_retries.aka(_("Retries")).as_string()

    form.ppp_auth_required = l2tp.ppp_auth_required.aka(_("Require authentication")).get_boolean()
    form.ppp_auth_pap = l2tp.ppp_auth_pap.aka(_("Auth PAP")).get_boolean()
    form.ppp_auth_chap = l2tp.ppp_auth_chap.aka(_("Auth PAP")).get_boolean()
    form.ppp_auth_mschap = l2tp.ppp_auth_mschap.aka(_("Auth MS-CHAP")).get_boolean()
    form.ppp_auth_mschap2 = l2tp.ppp_auth_mschap2.aka(_("Auth MS-CHAPv2")).get_boolean()
    
    form.l2tp_challenge = l2tp.l2tp_challenge.aka(_("L2TP challenge")).get_boolean()

    form.nated = l2tp.nated.aka(_("NAT state")).get_boolean()
    t:close()
end


return l2tp_server
