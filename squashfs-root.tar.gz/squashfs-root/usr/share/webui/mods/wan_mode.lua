---
-- WAN mode WebUI module.
-- @release $Id: wan_mode.lua 178063 2016-01-28 20:17:22Z marina.maslova $
--

local crm   = require("webui.crm")
local wan_mode = {}

function wan_mode.apply(conf, query, form, prvt)
    local t     = crm.transaction():webui_open_rw()
    local mit   = t:mit()
    local c_wan_mode, mode

    if mit.bezeqint.wan_mode.exists() then
        c_wan_mode = mit.bezeqint.wan_mode
    else
        c_wan_mode = mit.ppe.wan_mode
    end

    mode = form.mode.aka(_("WAN mode")).get()

    c_wan_mode.aka(_("WAN mode status")).set_string(mode)

    prvt.reboot = form.reboot.get()

    t:close()

end

function wan_mode.fetch(conf, query, prvt, form)
    local t                 = crm.transaction():webui_open_ro()
    local mit               = t:mit()
    local h_mode_list, c_mode_list, c_mode
    local id, c_node, h_node

    form.reboot = prvt.reboot.get()

    if mit.bezeqint.wan_mode.exists() then
        c_mode = mit.bezeqint.wan_mode
        c_mode_list = mit.enum.bezeqint_wan_mode
    else
        c_mode = mit.ppe.wan_mode
        c_mode_list = mit.enum.wan_mode
    end

    form.mode = c_mode.aka(_("WAN mode status")).name.get_string()

    -- Fetch possible WAN modes
    h_mode_list = form.mode_list.create()
    for id, c_node in c_mode_list.aka(_("WAN modes")).as_iter() do
        local h_node = h_mode_list[c_node.value.as_string()].create()

        h_node.name = c_node.name.get_string()
    end

    t:close()
end

return wan_mode
