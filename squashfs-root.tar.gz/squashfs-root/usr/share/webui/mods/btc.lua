---
-- BitTorrent client WebUI module.
-- @release $Id: btc.lua 162075 2012-11-27 23:49:44Z marina.maslova $
--

local crm               = require("webui.crm")
local webui_mods        = {}
webui_mods.storage      = {}
webui_mods.storage.tree = require("webui_mods.storage.tree")

local btc               = {}


function btc.apply(conf, query, form, prvt)
    local t         = crm.transaction():webui_open_rw()
    local node      = t:mit().btc
    local password  = form.password.aka(_("password")).get()
    local hidd_password  = form.hidd_password.aka(_("hidden password")).get()

    node.st_dir.aka(_("storage dir")).
        set_link(webui_mods.storage.tree.get_path(form.storage))
    node.config_dir.aka(_("config dir")).
        set_string(form.config_dir.aka(_("config dir")).get())
    node.dl_dir.aka(_("download dir")).
        set_string(form.dl_dir.aka(_("download dir")).get())
    node.watch_dir.aka(_("watch dir")).
        set_string(form.watch_dir.aka(_("watch dir")).get())

    node.dht.aka(_("dht")).set_boolean(form.dht.as_boolean())
    node.portmap.aka(_("portmap")).set_boolean(form.portmap.as_boolean())

    node.pl_global.aka(_("global peerlimit")).set_u32(
        form.pl_global.aka(_("global peerlimit")))
    node.pl_torrent.aka(_("torrent peerlimit")).set_u32(
        form.pl_torrent.aka(_("torrent peerlimit")))

    node.peer_port.aka(_("peer port")).set_u16(
        form.peer_port.aka(_("peer port")).req_range(0,65535))
    node.rpc_port.aka(_("rpc port")).set_u16(
        form.rpc_port.aka(_("rpc port")).req_range(0,65535))

    node.auth.aka(_("auth")).set_boolean(form.auth.as_boolean())
    node.username.aka(_("username")).set_string(
        form.username.aka(_("username")).get())

    if password ~= hidd_password then
        node.password.aka(_("password")).set_string(password)
    end

    node.admin.aka(_("administrative status")).set_boolean(
        form.admin.as_boolean())

    t:close()
end

function btc.fetch(conf, query, prvt, form)

    local t     = crm.transaction():webui_open_ro()
    local mit   = t:mit()
    local node  = mit.btc

    webui_mods.storage.tree.smmr(form.storage.create(), mit)
    webui_mods.storage.tree.slct(form.storage, node.st_dir.get_link())

    form.config_dir     = node.config_dir.get_string()
    form.dl_dir         = node.dl_dir.get_string()
    form.watch_dir      = node.watch_dir.get_string()
    form.dht            = node.dht.get_boolean()
    form.portmap        = node.portmap.get_boolean()
    form.peer_port      = node.peer_port.as_string()
    form.rpc_port       = node.rpc_port.as_string()
    form.pl_global      = node.pl_global.as_string()
    form.pl_torrent     = node.pl_torrent.as_string()
    form.auth           = node.auth.get_boolean()
    form.username       = node.username.get_string()
    form.password       = string.gsub(tostring(node.password.get_string()),
                                      "(.)", function(a) return '*' end)
    form.oper           = node.oper.get_boolean()
    form.admin          = node.admin.get_boolean()

    t:close()
end


return btc
