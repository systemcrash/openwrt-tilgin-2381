---
-- Account WebUI set.
-- @release $Id:$
--

local crm       = require("webui.crm")
local account   = {}


function account.link(prm, prnt_link, id)
    assert(prnt_link ~= nil)
    assert(id ~= nil)
    assert(#id > 0)

    return prnt_link .. "/voip/account/" .. id;
end


function account.stat(prm, link)
    local t         = crm.transaction():webui_open_ro()
    local account   = t:mit()[link]

    if not account.exists() then
        error(_("not found"))
    end

    if account.param.PhoneNumber.
        aka(_("phone number")).get_string():len() == 0 then
        error(_("no phone number"))
    end

    t:close()
end


function account.list(prm, prnt_link, h_list)
    local t         = crm.transaction():webui_open_ro()
    local c_list    = t:mit()[prnt_link .. "/voip/account"]

    local phone_number

    for account_id, c_account in c_list.as_iter() do
        phone_number = c_account.param.PhoneNumber.get_string()
        if #phone_number > 0 then
            h_list[account_id] = phone_number
        end
    end

    t:close()
end


return account
