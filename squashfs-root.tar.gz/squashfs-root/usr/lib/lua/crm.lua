---
-- Object-oriented Lua CRM interface.
-- @release $Id$
--

local meta = {}

function meta.__index(t, k)
    local v = require("crm." .. k)
    t[k] = v
    return v
end

local crm =  setmetatable({}, meta)

---
-- Pose for a package snapshot - load all sub-packages.
--
function crm:_pose_for_snapshot()
    local packages = {
                "err",
                "mapi",
                "node",
                "status",
                "subscription",
                "tc_type",
                "transaction",
                "value",
                "value_type"
            }

    -- Load all subpackages
    for i, n in pairs(packages) do
        local p = self[n]
    end

    -- Remove package loading metatable since all packages are loaded now
    -- and to catch packages which weren't added to the above list
    setmetatable(self, nil)
end

function crm.handle_events(wait)
    return crm.mapi.handle_events(nil, wait)
end

return crm
