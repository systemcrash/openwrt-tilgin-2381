---
-- Object-oriented ClearSilver HDF interface.
-- @release $Id$
--

local luahdf    = require("luahdf")
local hdf       = {}
hdf.err         = require("hdf.err")
hdf.key         = {}
hdf.key.NODE    = {}
hdf.key.PARENT  = {}
hdf.key.SUFFIX  = {}
hdf.key.TITLE   = {}
hdf.key.ITITLE  = {}

local KEY_NODE      = hdf.key.NODE
local KEY_PARENT    = hdf.key.PARENT
local KEY_SUFFIX    = hdf.key.SUFFIX
local KEY_TITLE     = hdf.key.TITLE
local KEY_ITITLE    = hdf.key.ITITLE


function hdf.wrap(node, parent, suffix)
    if not node then
        return nil
    end

    assert(getmetatable(node) == luahdf)

    return setmetatable({[KEY_NODE] = node,
                        -- Referencing the parent is important to scaring
                        -- the garbage collector off the tree root.
                         [KEY_PARENT] = parent,
                         [KEY_SUFFIX] = suffix},
                        hdf)
end


local hdf_mt    = {}
function hdf_mt.__call()
    return hdf.wrap(luahdf())
end
setmetatable(hdf, hdf_mt)


function hdf:__index(suffix)
    return setmetatable({[KEY_PARENT] = self,
                         [KEY_SUFFIX] = suffix}, hdf)
end


function hdf:__call(...)
    local s = rawget(self, KEY_SUFFIX)
    local m = hdf[s]
    local p = rawget(self, KEY_PARENT)

    if type(m) ~= "function" then
        error(string.format("Unknown method \"%s\"", s))
    end

    return m(p, ...)
end


function hdf:origin(tail)
    local node      = rawget(self, KEY_NODE)
    local parent    = rawget(self, KEY_PARENT)
    local path      = rawget(self, KEY_SUFFIX)

    if node then
        return node, tail
    end

    if tail then
        path = path .. "." .. tail
    end

    return hdf.origin(parent, path)
end


function hdf:get_obj()
    local node, path    = hdf.origin(self)

    return node:get_obj(path)
end


function hdf:exists()
    return not self.get_obj():is_null()
end


function hdf:resolve()
    local this_node = self.get_obj()

    if this_node then
        rawset(self, KEY_NODE, this_node)
    end

    return self
end


function hdf:create()
    local node, path    = hdf.origin(self)
    local this_node     = node:get_node(path)

    rawset(self, KEY_NODE, this_node)

    return self
end


function hdf:name()
    local node, path = hdf.origin(self)

    return node:obj_name(path)
end


function hdf:get()
    local node, path = hdf.origin(self)

    return node:get_value(path)
end


function hdf:set(value)
    local node, path = hdf.origin(self)

    return node:set_value(path, value)
end


function hdf:sort(cmp)
    return self.get_obj():sort_obj(
            function (a, b)
                return cmp(hdf.wrap(a, self, a:obj_name()),
                           hdf.wrap(b, self, b:obj_name()))
            end)
end


function hdf:__newindex(suffix, value)
    local node, path = hdf.origin(self, suffix)

    return node:set_value(path, value)
end


function hdf:__tostring()
    local node, path = hdf.origin(self)

    return node:get_value(path)
end


function hdf:iter()
    self.resolve()

    local node = rawget(self, KEY_NODE)
    if not node then
        return function() end
    end

    local next_node  = node:obj_child()

    return function ()
        if next_node then
            local node = next_node
            next_node = node:obj_next()
            return node:obj_name(), hdf.wrap(node, self, node:obj_name())
        end
    end
end


function hdf:aka(title)
    rawset(self, KEY_TITLE, title)
    return self
end


function hdf:iaka(ititle)
    rawset(self, KEY_ITITLE, ititle)
    return self
end


function hdf:title()
    local title = rawget(self, KEY_TITLE)

    if not title then
        local parent    = rawget(self, KEY_PARENT)

        if getmetatable(parent) == hdf then
            local fmt = rawget(parent, KEY_ITITLE)

            if fmt then
                title = string.format(fmt, rawget(self, KEY_SUFFIX))
            end
        end
    end

    return title
end


function hdf:branch_title(subtitle)
    local title     = hdf.title(self)
    local parent    = rawget(self, KEY_PARENT)
    local array

    if subtitle ~= nil then
        if type(subtitle) == "table" then
            array = subtitle
        else
            array = {subtitle}
        end
    else
        array = {}
    end

    if title ~= nil then
        table.insert(array, 1, title)
    end

    if getmetatable(parent) == hdf then
        return hdf.branch_title(parent, array)
    else
        return table.concat(array, ": ")
    end
end


function hdf:branch_title_list()
    local branch    = {}
    local title     = self.title()

    if title == nil then
        local parent

        repeat
            parent = rawget(self, KEY_PARENT)
            if getmetatable(parent) ~= hdf then
                return {"<" .. table.concat(branch, ".") .. ">"}
            end

            table.insert(branch, 1, rawget(self, KEY_SUFFIX))

            self = parent
            title = self.title()
        until title ~= nil

        branch = {"<" .. table.concat(branch, ".") .. ">"}
    end

    table.insert(branch, 1, title)

    while true do
        self = rawget(self, KEY_PARENT)
        if getmetatable(self) ~= hdf then
            break
        end

        title = self.title()
        if title ~= nil then
            table.insert(branch, 1, title)
        end
    end

    return branch
end


function hdf:is_empty()
    local value = tostring(self)
    return value == nil or #value == 0
end


function hdf:is_blank()
    local value = tostring(self)

    return value == nil or
           string.match(value, "^%s*$")
end


function hdf:is_regex(regex)
    local value = tostring(self)

    if value == nil then
        value = ""
    end

    return string.match(value, regex)
end


function hdf:is_range(min, max)
    local n = tonumber(tostring(self))

    return (n ~= nil) and (n >= min) and (n <= max)
end


function hdf:is_number()
    return tonumber(tostring(self)) ~= nil
end


function hdf:as_boolean()
    local n = tonumber(tostring(self))

    return (n ~= nil and n ~= 0)
end


function hdf:as_number()
    return tonumber(tostring(self))
end


function hdf:copy(src)
    local node, path    = hdf.origin(self)

    node:copy(path, src.get_obj())
end


function hdf:remove()
    local node, path    = hdf.origin(self)

    node:remove_tree(path)
    rawset(self, KEY_NODE, nil)
end


--
-- Import table structure; simultaneous presence of values and subtrees for
-- nodes is not supported.
--
function hdf:import_table(t)
    local k, v

    if type(t) == "table" then
        self.create()
        for k, v in pairs(t) do
            self[k].import_table(v)
        end
    else
        self.set(tostring(t))
    end
end


return hdf
