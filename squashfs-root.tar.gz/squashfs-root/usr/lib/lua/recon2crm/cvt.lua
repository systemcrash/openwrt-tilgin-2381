--
-- Value convert functions
--

local data    = require("recon2crm.process.data")
local util    = require("recon2crm.util")
local script  = require("recon2crm.script")

local cvt     = {}

--- Dummy boolean converter
function cvt.boolean(val)
    return val, "boolean"
end

--- Dummy s32 converter
function cvt.s32(val)
    return val, "s32"
end

--- Dummy string converter
function cvt.string(val)
    return val, "string"
end

--- Dummy link converter
function cvt.link(val)
    return val, "link"
end

---
-- Convert comma-separated list (RECON) to CRM set in string
-- representation.
--
function cvt.list2set(str)
    if str == "" then
        return "()", "set"
    else
        return "(\"" .. str .. "\")", "set"
    end
end


---
-- Map Disabled/Enabled to boolean False/True correspondingly.
--
function cvt.enabled2bool(str)
    if str == "0" or str == "Disable" then
        return "False", "boolean"
    elseif str == "1" or str == "Enable" then
        return "True", "boolean"
    else
        return nil
    end
end

---
-- Convert hours to seconds.
--
function cvt.hour2sec(hours)
    return hours * 60 * 60
end

---
-- Convert minutes to seconds.
--
function cvt.min2sec(min)
    return min * 60
end

---
-- Mapping of IPv4 in dotted format to octets.
--
function cvt.ip4_dotted_to_octets(str)
    local ip = {str:match("^%s*(%d+)%.(%d+)%.(%d+)%.(%d+)%s*$")}

    ip[1] = tonumber(ip[1]) or 0
    ip[2] = tonumber(ip[2]) or 0
    ip[3] = tonumber(ip[3]) or 0
    ip[4] = tonumber(ip[4]) or 0

    return ("%02x%02x%02x%02x"):format(ip[1], ip[2], ip[3], ip[4]), "octets"
end

---
-- Mapping of IPv4 netmask in dotted format to prefix length.
--
function cvt.ip4_netmask_to_prefix(str)
    local mask2prefix = {  [0x00000000] = 0,
        [0x80000000] = 1,  [0xc0000000] = 2,
        [0xe0000000] = 3,  [0xf0000000] = 4,
        [0xf8000000] = 5,  [0xfc000000] = 6,
        [0xfe000000] = 7,  [0xff000000] = 8,
        [0xff800000] = 9,  [0xffc00000] = 10,
        [0xffe00000] = 11, [0xfff00000] = 12,
        [0xfff80000] = 13, [0xfffc0000] = 14,
        [0xfffe0000] = 15, [0xffff0000] = 16,
        [0xffff8000] = 17, [0xffffc000] = 18,
        [0xffffe000] = 19, [0xfffff000] = 20,
        [0xfffff800] = 21, [0xfffffc00] = 22,
        [0xfffffe00] = 23, [0xffffff00] = 24,
        [0xffffff80] = 25, [0xffffffc0] = 26,
        [0xffffffe0] = 27, [0xfffffff0] = 28,
        [0xfffffff8] = 29, [0xfffffffc] = 30,
        [0xfffffffe] = 31, [0xffffffff] = 32,
    }
    local ip = {str:match("^%s*(%d+)%.(%d+)%.(%d+)%.(%d+)%s*$")}

    ip[1] = tonumber(ip[1])
    ip[2] = tonumber(ip[2])
    ip[3] = tonumber(ip[3])
    ip[4] = tonumber(ip[4])

    return mask2prefix[((ip[1] * 256 + ip[2]) * 256 + ip[3]) * 256 + ip[4]], "u8"
end


---
-- Mapping of MAC in colon format to octets.
--
function cvt.mac_to_octets(str)
    return str:gsub(":", ""), "octets"
end

---
-- Mapping of permission to use connection for the service to
-- priority.
--
function cvt.cpfpool_perm2prio(perm)
    return perm == "0" and "none" or "quinary", "string"
end

---
-- Mapping of WLAN channel (Auto) to CRM analogue (0).
--
function cvt.wlan_channel(str)
    return str == "Auto" and "0" or str, "s32"
end

---
-- Create CRM link by RECON WAN connection ID.
--
function cvt.conn2link(vcm)
    if not vcm or vcm == "" then
        return "", "link"
    else
        local type, layer, id = vcm:match("^i3_(%l+)_(%l)h_(%d+)$")

        if type then
            return "/RECON/connection/id/" .. type .. "_" .. id, "link"
        else
            return "", "link"
        end
    end
end

---
-- Create CRM link to interface by RECON WAN connection ID.
--
function cvt.conn2if(vcm)
    local lnk = cvt.conn2link(vcm)

    if lnk ~= "" then
        return lnk .. "/if", "link"
    else
        return "", "link"
    end
end

---
-- Map REOCN LAN group name/ID to LAN group link.
--
function cvt.lan_group(vcm)
    local id = vcm:match("^lan_(%d*)$")

    if id then
        return "/RECON/lan/group/id/" .. id, "link"
    elseif vcm ~= "" then
        return "/RECON/lan/group/name/" .. util.cname(vcm), "link"
    else
        return "", "link"
    end
end

---
-- Map ATM VC name/ID to link.
--
function cvt.atm_vc(vcm)
    local id = vcm:match("^atm_vc_(%d*)$")

    if id then
        return "/RECON/atm_vc/id/" .. id, "link"
    elseif vcm ~= "" then
        return "/RECON/atm_vc/name/" .. util.cname(vcm), "link"
    else
        return "", "link"
    end
end

---
-- Map visibility to access control permission.
--
function cvt.visible2ac(val)
    return val == "0" and "----" or "GRSW", "string"
end

---
-- Service to CRM service class name.
--
function cvt.service2class(val)
    local class = val:match("^Service: (%l+)$")

    if not class or class == "default" then
        return "", "link"
    else
        if class == "voice" then 
            class = "voip"
        end
        return "/service/class/table/" .. class, "link"
    end
end

---
-- Map port name to link.
--
function cvt.port(name)
    local port = data.port[name]

    if not port then
        port = {}
        data.port[name] = port
        port.link = "/RECON/if/port/" .. name
        script.prio_map(10, "/port/" .. name, port.link)
    end
    return port.link, "link"
end


---
-- Map Ethernet port LAN interface link.
--
function cvt.eth_port_lan_if(name)
    local iface = data.lan_eth_if[name]

    if not iface then
        iface = {}
        data.lan_eth_if[name] = iface
        iface.link = "/RECON/if/port_if/" .. name
        script.prio_find(10, "/if/table",
            { "lower", "link", (cvt.port(name)),
              "wan", "boolean", "False" },
            iface.link)
    end
    return iface.link, "link"
end

---
-- Mapping of RIP interface name to link.
--
function cvt.rip_iface2link(iface)
    if iface == "WAN" then
        return "/connection/fallback/ppool/default/current/if", "link"
    else
        return (cvt.lan_group(iface)) .. "/ipif", "link"
    end
end

return cvt
