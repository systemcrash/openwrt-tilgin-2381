local log = require("recon2crm.log")
local cvt = require("recon2crm.cvt")
local map = {}

-- Mapping domains
map.dom = {}

---
-- Convert string with whitespace separated words to arguments list.
--
local function split(s)
    local word_list = {};

    for word in s:gmatch("%s*(%S+)") do
        table.insert(word_list, word)
    end

    return unpack(word_list)
end

---
-- Read RECON-to-CRM mapping from files
--
function map.read()
    for file in io.popen("ls ${ROOT}/usr/share/crm/recon2crm.*.map"):lines() do
        local dom = file:match(".*recon2crm\.([^\.]*)\.map")
        local table = {}

        map.dom[dom] = table

        for line in io.lines(file) do
            if line:sub(1, 1) ~= "#" then
                local var, crm, conv, post = split(line)
                local conv_fn

                if not var then
                    -- Empty line
                elseif table[var] then
                    log.error("Skip duplicate mapping for '%s' in " ..
                              "'%s' domain\n", var, dom)
                else
                    if not conv or conv == '""' then
                        conv_fn = nil
                    else
                        conv_fn = cvt[conv]
                        if not conv_fn then
                            log.error("Unknown converter '%s' for " ..
                                      "'%s' to '%s'\n", conv, var, crm)
                        end
                    end

                    table[var] = {
                        crm     = (crm ~= '""' and crm) or nil,
                        cvt     = conv_fn,
                        post    = (not not post) and (post ~= '""')
                    }
                end
            end
        end
    end
end

---
-- Map RECON parameter to CRM.
--
-- @param dom           Domain
-- @param param         Parameter
-- @param value         Value to be mapped (if needed)
--
function map.apply(dom, param, value)
    local table = map.dom[dom]
    local entry

    if not table then
        return nil
    end
    entry = table[param]
    if not entry then
        return nil
    end

    if entry.cvt then
        return entry.crm, entry.post, entry.cvt(value)
    else
        return entry.crm, entry.post, value
    end
end

return map
