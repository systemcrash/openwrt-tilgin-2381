local log  = require("recon2crm.log")

local util = {}

---
-- Raise formatted error.
--
function util.errorf(fmt, ...)
    error(fmt:format(...), 2)
end

---
-- Raise fatal error.
--
function util.fatal_error(e)
    error({ msg = e }, 2)
end

---
-- Protect against non-fatal errors, just log them.
--
function util.failsafe_call(f, ...)
    local ok, e = pcall(f, ...)

    if not ok then
        if type(e) == "table" then
            error(e)
        else
            log.error("%s", tostring(e))
            return false
        end
    else
        return true
    end
end

---
-- Canonical name.
--
function util.cname(str)
    return str:gsub("%W", "_")
end


---
-- Check if specified bit set in value.
--
-- @param val           Value
-- @param bit           Bit number starting from 0
--
function util.is_bit_set(val, bit)
    return (val / 2 ^ bit) % 2
end

---
-- Clear specified bit.
--
-- @param val           Value
-- @param bit           Bit to be cleared
--
function util.clear_bit(val, bit)
    return val - util.is_bit_set(val, bit) * 2 ^ bit
end


return util
