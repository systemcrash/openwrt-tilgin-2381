local log = {}

--- Log message prefix
log.prefix = ""

--- Log message
function log.msg(level, fmt, ...)
    io.stderr:write(log.prefix .. ": ")
    if level then
        io.stderr:write(level .. ": ")
    end
    io.stderr:write(fmt:format(...))
    io.stderr:write("\n")
end

--- Log debug message
function log.debug(fmt, ...)
--    log.msg("DEBUG", fmt, ...)
end

--- Log error message
function log.error(fmt, ...)
    log.msg("ERROR", fmt, ...)
end

--- Log warning message
function log.warn(fmt, ...)
    log.msg("WARN", fmt, ...)
end

--- Log always enabled trace message
function log.trace(fmt, ...)
    log.msg(nil, fmt, ...)
end

return log
