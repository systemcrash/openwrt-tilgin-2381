local log     = require("recon2crm.log")
local map     = require("recon2crm.map")
local cvt     = require("recon2crm.cvt")
local script  = require("recon2crm.script")

local process = {}

-- Custom pattern-style match
local custom  = {}
process.custom = custom

-- Processing data storage
local data = require("recon2crm.process.data")
process.data = data


custom.wan_link       = require("recon2crm.process.wan_link")
custom.conn           = require("recon2crm.process.conn")
custom.cpfpool        = require("recon2crm.process.cpfpool")
custom.atm_vc         = require("recon2crm.process.atm_vc")
custom.lan_group      = require("recon2crm.process.lan_group")
custom.wlan_ssid      = require("recon2crm.process.wlan_ssid")
custom.static_route   = require("recon2crm.process.static_route")
custom.rip_iface      = require("recon2crm.process.rip_iface")
custom.eth_phy_aneg   = require("recon2crm.process.eth_phy_aneg")
custom.eth_phy_cntl   = require("recon2crm.process.eth_phy_cntl")
custom.switch_rl      = require("recon2crm.process.switch_rl")
custom.service_access = require("recon2crm.process.service_access")
custom.upnp           = require("recon2crm.process.upnp")

--
-- CRM parameter
--
custom.crm = {
    pattern = "^(/.+)$",
    param = function(val, var)
        script.prio_set(40, var, val)
    end
}

--
-- WLAN
--
custom.wlan = {
    pre = function()
        script.select(1)
        script.find("/port",
                    { "port_type", "string", "wlan_port" },
                    "/RECON/port/wlan")
        script.map("/RECON/port/wlan", "/RECON/if/port/wlan")
    end
}

--
-- Wireless SSID override
--
custom.wlan_ssid_override = {
    pattern = "^wlan:settings/ssid_override$",
    param = function(val, var)
        if val == "0" then
            script.prio_set(10,
                "/RECON/if/port/wlan/add_upper/./access/~operator",
                "GRSW", "string")
        else
            script.prio_action(10, "/recon/pm/cleanup_local_ssid")
            script.prio_set(10,
                "/RECON/if/port/wlan/add_upper/./access/~operator",
                "GR--", "string")
        end
    end
}

--
-- Wireless factory default SSID restore
--
custom.wlan_ssid_restore_default = {
    pattern = "^wlan:settings/ssid_restore_default$",
    param = function(val, var)
        if val ~= "0" then
            script.action("/recon/pm/restore_default_ssid")
        end
    end
}

--
-- Wireless factory default SSID override
--
custom.wlan_def_ssid_remove = {
    pattern = "^wlan:settings/def_ssid_remove$",
    param = function(val, var)
        if val ~= "0" then
            script.prio_action(10, "/recon/pm/cleanup_default_ssid")
        end
    end
}

--
-- SNTP servers
--
custom.sntp_server = {
    pattern = "^sntp:settings/(%l+)_server$",
    param = function(val, srv)
        if val ~= "" and val ~= "0.0.0.0" then
            script.prio_action(40, "/ntp/add_server",
                               { "server", "string", val },
                               "link", "/ntp/server/" .. srv)
        end
    end
}


--
-- WebUI user
--
custom.webui_user = {
    pattern = "^webui/user/(%l+)$",
    param = function(val, access)
        local login, password = val:match("([^:]+):(.*)");

        if not data.webui_user then
            data.webui_user = {}
            script.prio_action(40, "/generic/cleanup",
                               { "link", "link", "/webui/user" })
        end

        if not data.webui_user[access] then
            data.webui_user[access] = { cfg = {} }
        end

        data.webui_user[access].cfg.login = login

        script.prio_action(40, "/webui/add_user",
                           { "name", "string", login,
                             "password", "string", password,
                             "access_level", "string", access },
                           "link", "/RECON/webui/user/" .. access)
    end
}


--
-- WebUI user lock
--
custom.webui_user_lock = {
    pattern = "^webui/lock/(%l+)$",
    param = function(val, access)
        script.prio_set(50, "/RECON/webui/user/" .. access .. "/locked",
                        val, "boolean")
    end
}

--
-- WebUI user shell
--
custom.webui_user_shell = {
    pattern = "^webui/shell/(%l+)$",
    param = function(val, access)
        script.prio_set(50, "/RECON/webui/user/" .. access .. "/shell",
                        val, "string")
    end
}

---
-- Process service access list parameter.
--
-- @param service       Service name
-- @param dom           WAN or LAN domain
-- @param val           Access list
--
function service_access_list(service, dom, val)
    custom.service_access.entry(service).dom[dom] = val
end

---
-- Process service access enabled parameter.
--
-- @param service       Service name
-- @param val           Enabled (1) or disabled (0)
--
function service_access_enabled(service, val)
    custom.service_access.entry(service).enabled = val
end

custom.webui_access_enabled = {
    pattern = "^web_access/enabled$",
    param = function(val, var)
        service_access_enabled("webui_http", val)
    end
}

custom.webui_access_address = {
    pattern = "^web_access/address$",
    param = function(val, var)
        service_access_list("webui_http", "wan", val)
    end
}

custom.ping_access_enabled = {
    pattern = "^allow_ping_enable$",
    param = function(val, var)
        service_access_enabled("ping", val)
    end
}

custom.ping_access_address = {
    pattern = "^allow_ping_network$",
    param = function(val, var)
        service_access_list("ping", "wan", val)
    end
}

custom.storage_http_wan_access_address = {
    pattern = "^storage/access/http/wan/subnet$",
    param = function(val, var)
        service_access_list("storage_http", "wan", val)
    end
}

custom.storage_http_lan_access_address = {
    pattern = "^storage/access/http/lan/subnet$",
    param = function(val, var)
        service_access_list("storage_http", "lan", val)
    end
}

custom.telnet_wan_access_address = {
    pattern = "^telnet/access/wan/subnet$",
    param = function(val, var)
        service_access_list("telnet", "wan", val)
    end
}

custom.telnet_lan_access_address = {
    pattern = "^telnet/access/lan/subnet$",
    param = function(val, var)
        service_access_list("telnet", "lan", val)
    end
}


-- VoIP accounts
custom.voip_account = {}

---
-- VoIP account parameter processing.
--
-- @param val           Value
-- @param var           Parameter
-- @param name          Account name (letter)
--
function custom.voip_account.param(val, var, name)
    local table = data.voip_account
    local link

    if not table then
        table = {}
        data.voip_account = table
--        script.action("/generic/cleanup",
--                      { "link", "link", "/voip/account" })
    end

    link = table[name]
    if not link then
        link = "/RECON/voip/account/" .. name
        table[name] = link
        script.action("/voip/add_account",
                      { "name", "string", name },
                      "link", link)
    end

    if var == "Calls_from" then
        script.set(link .. "/param/" .. var, cvt.list2set(val))
    else
        script.set(link .. "/param/" .. var, val)
    end
end

-- VoIP MSNs 
custom.voip_msn = {}
custom.voip_msn.map = {
    Calls_from_Phone_ISDN       = { param = "calls_from", prio = 50 },
    Display_Name_Phone_ISDN     = { param = "display_name" },
    MSN                         = { param = "phone" },
    Internal_Number_Phone_ISDN  = { param = "internal_num" },
}

---
-- Process ISDN Phones (MSN) paraemter.
--
-- @param val           Value
-- @param var           Parameter
-- @param name          MSN name (letter)
--
function custom.voip_msn.param(val, var, name)
    local table = data.voip_msn
    local link
    local map 

    if not table then
        table = {}
        data.voip_msn = table
        script.action("/generic/cleanup",
                      { "link", "link", "/voip/msn" })
    end

    link = table[name]
    if not link then
        link = "/RECON/voip/msn/" .. name
        table[name] = link
        script.action("/voip/add_msn",
                      { "name", "string", name },
                      "link", link)
    end

    map = custom.voip_msn.map[var]
    if map then
        if map.prio then
            script.prio_set(map.prio, link .. "/" .. map.param, val)
        else
            script.set(link .. "/" .. map.param, val)
        end
    end
end

--
-- "Transparent" parameters processing.
--
custom.transparent = {
    map = {
        [{ "^(MSN)_(%u)$", 
          "^(Calls_from_Phone_ISDN)_(%u)$",
          "^(Internal_Number_Phone_ISDN)_(%u)$",
          "^(Display_Name_Phone_ISDN)_(%u)$"
        }] = custom.voip_msn.param,
        [{ "^(Calls_from)_(%u)$",
          "^(PhoneNumber)_(%u)$",
          "^(Username)_(%u)$",
          "^(Password)_(%u)$",
          "^(Outbound_Proxy)_(%u)$",
          "^(Registration_Server)_(%u)$",
          "^(Display_Name)_(%u)$",
          "^(Registration)_(%u)$",
          "^(Registration_Interval)_(%u)$",
          "^(Web_Password)_(%u)$",
          "^(Q_Value)_(%u)$",
          "^(SIP_PredefinedRouteOutbound)_(%u)$",
          "^(SIP_PredefinedServiceRoute)_(%u)$",
          "^(IMS_Enable_MMTel_ICSI)_(%u)$",
          "^(IMS_Device_Capabilities)_(%u)$",
          "^(IMS_CDIVN)_(%u)$",
          "^(Busy_Serial_Enabled)_(%u)$",
          "^(IMS_Early_Media_Handling)_(%u)$",
        }] = custom.voip_account.param,
        [{ "^Account_(%u)_(Ringing.)$"
        }] = function(val, name, var)
            custom.voip_account.param(val, var, name)
        end,
        [{ "^Supported_Codecs$",
          "^Group_Numbers$",
          "^Internal_Numbers$",
          "^Active_SIP_Accounts$",
          "^Calls_from_Group_Number_.+$"
        }] = function(val, var)
            script.set("/recon/pm/table/" .. var, cvt.list2set(val))
        end,
        [{ "^STUN_Server$",
          "^Hot_Line$",
          "^Warm_Line_Timer$",
          "^Enable_Splash$",
          "^Message_Waiting_Tone_Enabled$",
          "^Use_DHCP$",
          "^DNS_Server_1$",
          "^NTP_Address$",
          "^MGCP_CallAgent$",
          "^Language$",
          "^Vendor_Class_Id$",
          "^Enable_Pers_Prov$"
        }] = function(val, var)
            script.set("/recon/pm/voip_st/" .. var, val, "string")
        end,
        [{ "^IP_Address$",
          "^IP_Broadcast$",
          "^IP_Gateway$",
          "^IP_Netmask$",
          "^Data_IP_Address$",
          "^Data_IP_Netmask$",
          "^Data_IP_Broadcast$",
          "^Management_IP_Address$",
          "^Management_IP_Netmask$",
          "^Management_IP_Broadcast$",
          "^Voice_IP_Address$",
          "^Voice_IP_Netmask$",
          "^Voice_IP_Broadcast$",
          "^VOIP_IfName$"
         }] = function(val, var)
            script.set("/recon/pm/voip_cache/" .. var, val, "string")
        end,
    }
}

return process
