--
-- Switch rate limit
--

local util    = require("recon2crm.util")
local cvt     = require("recon2crm.cvt")
local script  = require("recon2crm.script")

local process = {}
local data    = {}

require("recon2crm.process.data").switch_rl = data
data.cfg = {}

-- Switch rate limit parameter template.
process.pattern = "^RL_(%S*)$"

---
-- Switch rate limit parameter processing.
--
-- @param val           Value
-- @param var           Parameter
--
function process.param(val, var)
    if var == "STEPS" then
        local num
        local kbps

        data.step = {}
        for step in val:gmatch("%s*([^,]+)%s*,?") do
            if step == "Full Rate" then
                kbps = 0
            else
                num = step:match("(%d+)%s*Mbps")
                if num then
                    kbps = num * 1024
                else
                    num = step:match("(%d+)%s*Kbps")
                    if num then
                        kbps = num
                    end
                end
            end
            table.insert(data.step, kbps)
        end
    else
        local idx
        local dir, port = var:match("^(%u)X_(%w*)$")
        local entry

        if dir then
            if dir == "R" then
                dir = "in"
            elseif dir == "T" then
                dir = "e"
            else
                util.errorf("Unknown switch rate limit direction '%s'", dir)
            end
            cvt.port(port)
            idx = port .. "/" .. dir
            entry = data.cfg[idx]
            if not entry then
                entry = {}
                data.cfg[idx] = entry
            end
            entry.override = script.override
            entry.step = tonumber(val) + 1
        else
            util.errorf("Not supported switch rate limit parameter '%s'", var)
        end
    end
end

---
-- Configure switch rate limit in accordance with collected information.
--
function process.post()
    local override_save = script.override

    script.select(20)

    for idx, entry in pairs(data.cfg) do
        script.override = entry.override
        script.set("/RECON/if/port/" .. idx .. "gress_rate_limit",
                   data.step[entry.step], "u32")
    end

    script.override = override_save
end

return process
