--
-- Connection fallback
--

local cvt     = require("recon2crm.cvt")
local script  = require("recon2crm.script")

local process = {}

-- Connection fallback pool parameter pattern
process.pattern = "^([%l_]*):priority_(%d)/connection$"

-- Mapping of numeric connection priority to CRM
process.prio = { ["1"] = "primary", ["2"] = "secondary", ["3"] = "tertiary" }

-- Mapping of RECON connection service name to CRM
process.service = {
    default = "default",
    management_traffic = "management",
    voip = "voip"
}

---
-- Connection fallback pool parameter processing.
--
function process.param(conn, service, prio)
    -- Output to conneciton post configuration script to be sure
    -- that connection already exist
    script.prio_set(30, (cvt.conn2link(conn)) .. "/pfpool/" ..
                        process.service[service],
                    process.prio[prio], "string")
end

return process
