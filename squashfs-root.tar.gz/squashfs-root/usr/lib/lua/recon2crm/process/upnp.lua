--
-- UPnP
--

local log     = require("recon2crm.log")
local util    = require("recon2crm.util")
local map     = require("recon2crm.map")
local script  = require("recon2crm.script")

local process = {}
local data    = {}

require("recon2crm.process.data").upnp = data

-- UPnP parameter pattern
process.pattern = "^upnp_(%d+):settings/(%S+)$"

---
-- UPnP parameters processing
--
-- @param val           Value
-- @parma id            UPnP instance ID
-- @param par           Parameter
--
function process.param(val, id, par)
    local link
    local crm_param, post, crm_value, crm_type

    link = data[id]
    if not link then
        link = "/upnp/table/recon_" .. id
        data[id] = link
        script.prio_action(40, "/upnp/add",
                           { "config_map", "string", "recon_" .. id },
                           "link", link)
    end

    crm_param, post, crm_value, crm_type = map.apply("upnp", par, val)
    if crm_param then
        script.prio_set(post and 50 or 40, link .. "/" .. crm_param,
                        crm_value, crm_type)
    else
        util.errorf("Unknown UPnP parameter: %s", par)
    end
end

return process
