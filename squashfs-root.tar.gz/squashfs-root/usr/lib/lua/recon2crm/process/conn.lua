--
-- WAN connections
--

local log      = require("recon2crm.log")
local util     = require("recon2crm.util")
local map      = require("recon2crm.map")
local script   = require("recon2crm.script")
local wan_link = require("recon2crm.process.wan_link")

local process  = {}
local data     = {}

require("recon2crm.process.data").conn = data

-- WAN connection parameter pattern
process.pattern = "^i3_(%l+)_(%l)h_(%d+):(%S+)$"

-- WAN connection RECON to CRM type mapping
process.type = {
    static = "Static",
    dhcp   = "DHCP",
    bridge = "Bridge",
    pppoe  = "PPPoE",
    pppoa  = "PPPoA",
    clip   = "CLIP"
}

---
-- WAN connection parameter processing
--
-- @param val           Value
-- @param type          RECON connection type
-- @param layer         RECON connection parameter layer
-- @param id            Connnection ID
-- @Param var           Parameter name
--
function process.param(val, type, layer, id, var)
    local vcm_id = type .. "_" .. id
    local crm_param, post, crm_value, crm_type
    local conn, link

    crm_param, post, crm_value, crm_type =
        map.apply("conn", layer .. ":" .. var, val)

    if not crm_param then
        util.errorf("Unknown connection parameter: %s", var)
    end

    conn = data[vcm_id]
    if not conn then
        conn = { cfg = {} }
        data[vcm_id] = conn
        conn.type = process.type[type]
        if not conn.type then
            util.errorf("Unknown connection type '%s' var=%s", type, var)
        end
        link = "/RECON/connection/id/" .. vcm_id
        conn.link = link
        if conn.type ~= "pppoe" then
            script.prio_set(30, link .. "/admin", "True", "boolean")
        end
    else
        link = conn.link
    end

    if var == "settings/link" then
        conn.link_type = crm_value
    elseif var == "settings/atm_vc" then
        conn.atm_vc = crm_value
    else
        script.prio_set(post and 30 or 20, link ..  crm_param,
                        crm_value, crm_type)
    end
end

---
-- Generate script commands to add WAN connection
--
-- @param id            Connection ID
-- @param entry         Table with connection data
--
function process.add(id, entry)
    local atm_vc = entry.atm_vc
    local pdu = ""
    local link_type = entry.link_type
    local conn_dev

    if atm_vc then
        -- TODO support routed connections
        if entry.type == "DHCP" or entry.type == "Static" then
            pdu = "Bridged"
        end
    end

    -- If configuration is inherited, link type may be unspecified
    if not link_type or link_type == "" then
        if atm_vc then
            link_type = "ADSL2"
        else
            link_type = "Ethernet"
        end
    end

    conn_dev = wan_link.dev(link_type)
    if not conn_dev then
        util.errorf("No WAN connection device for '%s'", link_type)
    end

    if not wan_link.types[link_type].clean then
        wan_link.types[link_type].clean = true
        -- Clean up connection before ATM VC
        script.prio_action(8, "/generic/cleanup",
                           { "link", "link", conn_dev .. "/configured" })
    end

    script.action(conn_dev .. "/add",
                  { "type", "string", entry.type .. pdu,
                    "config_map", "string", "recon_" .. id },
                  "link", entry.link)

    if atm_vc then
        script.set(entry.link .. "/layer/atm_vc/up_param/link", atm_vc, "link")
    end
end

---
-- WAN connection post-processing.
--
-- Generate commands to add all WAN connections.
--
function process.post()
    script.select(15)
    for id, entry in pairs(data) do
        if not util.failsafe_call(process.add, id, entry) then
            log.error("Failed to configure connection %s\n", id)
        end
    end
end

return process
