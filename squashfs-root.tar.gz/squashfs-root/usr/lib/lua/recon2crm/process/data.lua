--
-- Table with data collected during parameters processing.
--

local data = {}

-- Ports
data.port = {}

-- Ethernet LAN interfaces
data.lan_eth_if = {}

return data
