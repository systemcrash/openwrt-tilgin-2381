--
-- RIP interfaces
--

local log     = require("recon2crm.log")
local util    = require("recon2crm.util")
local map     = require("recon2crm.map")
local script  = require("recon2crm.script")

local process = {}
local data    = {}

require("recon2crm.process.data").rip_iface = data

-- RIP interface parameter pattern
process.pattern = "^rip_iface_(%d+):settings/(%S+)$"

---
-- RIP interface parameter processing
--
-- @param val           Value
-- @parma id            RIP interface ID
-- @param par           Parameter
--
function process.param(val, id, par)
    local link
    local crm_param, post, crm_value, crm_type

    link = data[id]
    if not link then
        link = "/rip/iface/recon_" .. id
        data[id] = link
        script.prio_set(50, link .. "/active", "True", "boolean")
    end

    if par == "name" then
        return
    end

    crm_param, post, crm_value, crm_type = map.apply("rip_iface", par, val)
    if crm_param then
        if crm_param == "iface" then
            script.prio_action(35, "/rip/add_iface",
                               { "iface", "link", crm_value },
                               "link", link)
        else
            script.prio_set(post and 50 or 40, link .. "/" .. crm_param,
                            crm_value, crm_type)
        end
    else
        util.errorf("Unknown RIP interface parameter: %s", par)
    end
end

return process
