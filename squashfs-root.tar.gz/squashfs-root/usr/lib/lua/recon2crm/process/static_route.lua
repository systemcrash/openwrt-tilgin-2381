--
-- Static routes
--

local log     = require("recon2crm.log")
local util    = require("recon2crm.util")
local cvt     = require("recon2crm.cvt")
local script  = require("recon2crm.script")

local process = {}
local data    = {}

require("recon2crm.process.data").static_route = data

-- Static route parameter pattern
process.pattern = "^static_route_(%d+):settings/(%S+)$"

---
-- Static route parameter processing.
--
-- @param val           Value
-- @param id            Static route ID
-- @param par           Parameter
--
function process.param(val, id, par)
    local obj = data[id]

    if not obj then
        obj = { cfg = {} }
        data[id] = obj
    end

    obj.cfg[par] = val
end

---
-- Generate CRM script action to add static route.
--
-- @param id            Static route ID
-- @param cfg           Static route paramters
--
function process.add(id, cfg)
    local params = {}
    local state
    local prefix
    local oif

    if not cfg.destination or cfg.destination == "" then
        log.error("Invalid static route %s with unspecified destination\n", id)
        return
    end

    if cfg.enabled == "1" then
        state = "KEEPALIVE"
    else
        state = "DISABLED"
    end
    table.insert(params, "state")
    table.insert(params, "string")
    table.insert(params, state)

    table.insert(params, "dst")
    table.insert(params, "octets")
    table.insert(params, (cvt.ip4_dotted_to_octets(cfg.destination)))

    if cfg.netmask then
        prefix = (cvt.ip4_netmask_to_prefix(cfg.netmask))
    end
    if not prefix  then
        prefix = 32
    end
    table.insert(params, "prefix")
    table.insert(params, "u8")
    table.insert(params, prefix)

    if cfg.gateway then
        table.insert(params, "gw")
        table.insert(params, "octets")
        table.insert(params, (cvt.ip4_dotted_to_octets(cfg.gateway)))
    end

    oif = (cvt.conn2if(cfg.connection))
    if oif then
        table.insert(params, "oif")
        table.insert(params, "link")
        table.insert(params, oif)
    end

    if cfg.metric then
        table.insert(params, "prio")
        table.insert(params, "u32")
        table.insert(params, cfg.metric)
    end


    script.action("/route/add", params,
                  "link", "/RECON/static/route/id/" .. id)
end

---
-- Add static routes in accordance with collected parameters.
--
function process.post()
    script.select(40)
    for id, obj in pairs(data) do
        if not util.failsafe_call(process.add, id, obj.cfg) then
            log.error("Failed to configure static route %s\n", id)
        end
    end
end

return process
