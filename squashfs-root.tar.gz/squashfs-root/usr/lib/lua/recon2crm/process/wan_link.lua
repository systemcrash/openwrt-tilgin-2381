--
-- WAN link
--

local util    = require("recon2crm.util")
local script  = require("recon2crm.script")

local process = {}

-- WAN link parameter pattern
process.pattern = "^wan_link/(%w*)$"

process.types = {
    Ethernet = { stack = "eth", port_type = "eth_port" },
    VDSL2    = { stack = "eth", port_type = "dsl_port" },
    ADSL2    = { stack = "atm", port_type = "dsl_port" }
}

---
-- Get connection device link by RECON WAN link type.
--
-- @param link_type     RECON WAN link type
--
function process.dev(link_type)
    local t = process.types[link_type]
    local conn_dev

    if not t then
        util.errorf("Unknown WAN link type '%s'", link_type)
    end

    conn_dev = "/RECON/connection/device/" .. link_type

    if not t.mapped then
        t.mapped = true
        script.prio_find(1, "/connection/device/table",
            { "port/port_type", "string", t.port_type,
              "link/prop/conn_stack/stack/name", "string", t.stack, },
            conn_dev)
    end
    return conn_dev
end

---
-- WAN link admin status parameter processing.
--
-- @param val           Value
-- @param link_type     RECON WAN link type
--
function process.param(val, link_type)
    local conn_dev = process.dev(link_type)

    if conn_dev then
        script.prio_set(1, conn_dev .. "/link/admin", val)
    end
end

return process 
