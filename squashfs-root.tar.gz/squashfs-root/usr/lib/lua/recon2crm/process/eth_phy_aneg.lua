--
-- Physical Ethernet ports PHY autonegotiation
--

local util    = require("recon2crm.util")
local cvt     = require("recon2crm.cvt")
local script  = require("recon2crm.script")

local process = {}

-- PHY autonegotiation parameter template.
process.pattern = "^PHY_ANEG_(%S*)$"

---
-- PHY autonegotiation parameter processing.
--
-- @param val           Value
-- @param var           Parameter
--
function process.param(val, port)
    local port_link = (cvt.port(port))
    local num = tonumber("0x" .. val)

    script.set(port_link .. "/prop/autoneg/speed_adv/10/Half",
               util.is_bit_set(num, 5), "boolean")
    script.set(port_link .. "/prop/autoneg/speed_adv/10/Full",
               util.is_bit_set(num, 6), "boolean")
    script.set(port_link .. "/prop/autoneg/speed_adv/100/Half",
               util.is_bit_set(num, 7), "boolean")
    script.set(port_link .. "/prop/autoneg/speed_adv/100/Full",
               util.is_bit_set(num, 8), "boolean")
    script.set(port_link .. "/prop/autoneg/tx_pause",
               util.is_bit_set(num, 10), "boolean")

    num = util.clear_bit(
              util.clear_bit(
                  util.clear_bit(
                      util.clear_bit(
                          util.clear_bit(num, 5),
                          6),
                      7),
                  8),
              10)
    if num ~= 0 then
        util.errorf("Not supported Ethernet PHY autoneg bits 0x%x", num)
    end
end

return process
