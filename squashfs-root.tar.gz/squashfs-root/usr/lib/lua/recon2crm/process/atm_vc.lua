--
-- ATM VC
--

local util    = require("recon2crm.util")
local map     = require("recon2crm.map")
local script  = require("recon2crm.script")

local process = {}
local data    = {}

require("recon2crm.process.data").atm_vc = data

-- ATM VC parameter pattern
process.pattern = "^atm_vc_(%d+):settings/(%S+)$"

--- ATM VC pre-processing hook
function process.pre()
    script.select(1)
    script.find("/if/table",
                { "type", "string", "atm_link" },
                "/RECON/if/atm_link")
end

--- ATM VC parameter processing
function process.param(val, id, par)
    local upper = "/RECON/atm/vc/" .. id
    local link = upper .. "/iface"

    if not data.configured then
        data.configured = true
        -- Cleanup ATM VC's after connections cleanup
        script.prio_action(10, "/generic/cleanup",
                           { "link", "link", "/RECON/if/atm_link/upper" })
    end

    if par == "name" then
        local cname = util.cname(val)

        script.prio_action(10, "/RECON/if/atm_link/add_upper",
                           { "config_map", "string", "recon_atm_vc_" .. id,
                             "type", "string", "atm_vc_if",
                             "name", "string", val },
                           "upper", upper)
        script.prio_map(10, link, "/RECON/atm_vc/id/" .. id)
        script.prio_map(10, link, "/RECON/atm_vc/name/" .. cname)
        script.prio_set(20, link .. "/admin", "True", "boolean")
    else
        local crm_param, post, crm_value, crm_type =
           map.apply("atm_vc", par, val)

        if crm_param then
            script.prio_set(15, link .. "/" .. crm_param, crm_value, crm_type)
        else
            util.errorf("Unknown ATM VC parameter: %s", par)
        end
    end
end

return process
