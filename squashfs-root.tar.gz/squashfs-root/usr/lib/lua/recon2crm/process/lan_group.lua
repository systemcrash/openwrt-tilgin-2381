--
-- LAN groups
--

local log     = require("recon2crm.log")
local util    = require("recon2crm.util")
local cvt     = require("recon2crm.cvt")
local script  = require("recon2crm.script")

local process = {}
local data    = {}

require("recon2crm.process.data").lan_group = data

-- LAN group parameter pattern
process.pattern = "^lan_(%d+):group/(%S+)$"

---
-- LAN group parameter processing.
--
-- Just add into processing data to be used on post-processing.
--
-- @param val           Value
-- @param id            LAN group ID
-- @param par           Parameter name
--
function process.param(val, id, par)
    local group, pool, pool_par, opt, opt_par

    group = data[id]
    if not group then
        group = { cfg = {}, dhcp_pool = {} }
        data[id] = group
    end

    pool, pool_par = par:match("dhcp/pool_(%w)/(.+)")
    if not pool then
        group.cfg[par] = val
    else
        local pool_entry = group.dhcp_pool[pool]

        if not pool_entry then
            pool_entry = { opt = {}, opt_link = {} }
            group.dhcp_pool[pool] = pool_entry
        end

        opt, opt_par = pool_par:match("option_(%w)/(.+)")
        if not opt then
            pool_entry[pool_par] = val
        else
            local opt_entry = pool_entry.opt[opt]

            if not opt_entry then
                opt_entry = {}
                pool_entry.opt[opt] = opt_entry
            end
            opt_entry[opt_par] = val
        end
    end
end

---
-- Configure LAN group DHCP server.
--
-- @param id            LAN group ID
-- @param entry         LAN group parameters
-- @param ds            DHCP server link
--
-- @todo Split function into smaller.
--
local function configure_lan_group_dhcp_server(id, entry, ds)
    local def_pool = entry.dhcp_pool["0"]
    local dsp
    local pool_num
    local nextserver
    local link

    for name, pool in pairs(entry.dhcp_pool) do
        -- Skip misconfigured pools with no matching criteria
        if pool.chaddr or pool.vendor_id then
            dsp = ds .. "/subnet/pool/" .. name
            pool_num = name:byte() - ("A"):byte() + 1

            script.action(ds .. "/add_subnet",
                          { "name", "string", name },
                          "link", dsp)
            script.set(dsp .. "/prio", pool_num, "u16")
            script.set(dsp .. "/minaddr",
                cvt.ip4_dotted_to_octets(entry.cfg["dhcp/server/ip/start"]))
            script.set(dsp .. "/maxaddr",
                cvt.ip4_dotted_to_octets(entry.cfg["dhcp/server/ip/end"]))

            -- Chaddr filtering
            if pool.chaddr then
                script.action(dsp .. "/filter/add_key",
                              { "type", "string", "dhcp_chaddr" })
                script.set(dsp .. "/filter/key/dhcp_chaddr/chaddr",
                           cvt.mac_to_octets(pool.chaddr))
                if pool.chaddr_mask then
                    script.set(dsp .. "/filter/key/dhcp_chaddr/mask",
                               cvt.mac_to_octets(pool.chaddr_mask))
                end
            end

            -- Vendor ID filtering
            if pool.vendor_id then
                script.action(dsp .. "/filter/add_key",
                              { "type", "string", "dhcp_vendor" })
                script.set(dsp .. "/filter/key/dhcp_vendor/vendor",
                           pool.vendor_id, "string")
                script.set(dsp .. "/filter/key/dhcp_vendor/match",
                           pool.vendor_id_mode, "string")
            end

            -- Next server
            nextserver = pool.nextserver
            if not nextserver and def_pool then
                nextserver = def_pool.nextserver
            end
            if nextserver then
                script.set(dsp .. "/next_server", cvt.ip4_dotted_to_octets(nextserver))
            end

            -- Add common options
            if def_pool then
                for id, opt in pairs(def_pool.opt) do
                    link = pool.opt_link[opt.tag]
                    if not link then
                        link = dsp .. "/option/tag/" .. opt.tag
                        pool.opt_link[opt.tag] = link
                        script.action(dsp .. "/option/add",
                                      { "enabled", "boolean", "True",
                                        "tag", "u8", opt.tag,
                                        "string", "string", opt.value },
                                      "link", link)
                    else
                        script.set(link .. "/value/string", opt.value, "string")
                    end
                end
            end

            -- Add pool options
            for id, opt in pairs(pool.opt) do
                link = pool.opt_link[opt.tag]
                if not link then
                    link = dsp .. "/option/tag/" .. opt.tag
                    pool.opt_link[opt.tag] = link
                    script.action(dsp .. "/option/add",
                                  { "enabled", "boolean", "True",
                                    "tag", "u8", opt.tag,
                                    "string", "string", opt.value },
                                  "link", link)
                else
                    script.set(link .. "/value/string", opt.value, "string")
                end
            end

        end
    end
end

---
-- Generate CRM script commands to add and configure LAN group.
--
-- @param id            LAN group ID
-- @param entry         LAN group parameters
--
-- @todo Split function into smaller.
--
function process.add(id, entry)
    local lglink = "/RECON/lan/group/id/" .. id

    local cfg = entry.cfg
    local name = cfg.name or ""
    local cname = util.cname(name)
    local prio = cfg.priority
    local vifs = cfg.vifs

    if prio then
        script.action("/lan/add_group",
                      { "priority", "s8", prio,
                        "config_map", "string", "recon_" .. id },
                      "link", lglink)
    else
        script.action("/lan/add_group",
                      { "config_map", "string", "recon_" .. id },
                      "link", lglink)
    end

    script.set(lglink .. "/name", name, "string")
    script.set(lglink .. "/description", cfg.description or "", "string")

    -- Add LAN group name to link mapping
    script.find("/lan/group",
                { "name", "string", name },
                "/RECON/lan/group/name/" .. cname)

    -- Visibility
    if cfg.visible then
        script.set(lglink .. "/./access/~operator",
                   cvt.visible2ac(cfg.visible))
    end

    -- Interfaces configuration
    if vifs then
        local iface

        for ifname, vlan in vifs:gmatch("%s*([^:]+):(%S+)") do

            log.debug("Add virtual interface " .. ifname .. " VLAN " .. vlan ..
                      " to group " .. id)

            iface = (cvt.eth_port_lan_if(ifname))

            if vlan == "-1" then
                script.action(lglink .. "/add_vif",
                              { "if", "link", iface },
                              "link",
                              lglink .. "/vif/" .. ifname .. "__1")
            else
                script.action(lglink .. "/add_vif",
                              { "if", "link", iface,
                                "vid", "s16", vlan },
                              "link",
                              lglink .. "/vif/" .. ifname .. "_" .. vlan)
            end
        end
    end

    local rt_conn = cfg["route_conn"]
    if rt_conn then
        local conn_link
        local service

        if rt_conn == "None" then
            conn_link = ""
        else
            service = rt_conn:match("^Service: (%a*)$")
            if service then
                conn_link = "/connection/fallback/ppool/" .. service .. "/current"
            elseif rt_conn:match("^i3_[%w_]+$") then
                conn_link = (cvt.conn2link(rt_conn))
            else
                log.warn("LAN group %s invalid routed connection '%s'\n",
                         id, rt_conn)
                conn_link = ""
            end
        end
        script.prio_set(20, lglink .. "/rt_conn", conn_link, "link")
    end

    if cfg["pass_through_conn"] then
        script.prio_set(20, lglink .. "/ppp_pt/conn",
                        cvt.conn2link(cfg["pass_through_conn"]))
    end

    -- IP configuration
    if not cfg["manage_ip"] or cfg["manage_ip"] == "No" then
        return
    end

    script.set(lglink .. "/swbridge_connected", "True", "boolean")
    script.set(lglink .. "/managed_by", "LAN", "string")

    -- LAN group IP interface mapping (to be sure that interface index in
    -- IP address link is remapped)
    script.map(lglink .. "/ipif", lglink .. "/if")

    local iplink = lglink .. "/ip"

    if cfg["manage_ip"] == "DHCP Client" then
        -- Use 'ipif' link to be configuration backward-compatible
        script.action(lglink .. "/ip/add",
                      { "type", "string", "ip_addr_dhcp" },
                      "link", iplink)
        script.set(iplink .. "/admin", "True", "boolean")
        return
    end

    -- Static IP configuration

    local addr = (cvt.ip4_dotted_to_octets(cfg["static/ip"]))
    local netmask = cfg["static/netmask"]
    local domain = cfg["static/domain"]

    -- Use 'ipif' link to be configuration backward-compatible
    script.action(lglink .. "/ip/add",
                  { "type", "string", "ip_addr_static" },
                  "link", iplink)
    script.set(iplink .. "/addr", addr, "octets")
    script.set(iplink .. "/prefix", cvt.ip4_netmask_to_prefix(netmask))
    script.set(iplink .. "/admin", "True", "boolean")

    if domain then
        script.set(lglink .. "/domain", domain, "string")
    end

    -- DHCP provider configuration
    local relay

    if not cfg["dhcpprovider"] or cfg["dhcpprovider"] == "no" then
        return
    elseif cfg["dhcpprovider"] == "relay" then
        relay = "True"
    else
        relay = "False"
    end

    script.set(lglink .. "/dhcpprovider/relay", relay, "boolean")
    script.set(lglink .. "/dhcpprovider/configurable", "True", "boolean")

    local dplink = lglink .. "/dhcp/provider"

    script.map(lglink .. "/dhcpprovider/link", dplink)

    if relay == "True" then
        script.set(dplink .. "/server_ip",
                   cvt.ip4_dotted_to_octets(cfg["dhcp/relay/server"]))
        script.prio_set(20, dplink .. "/server_if",
                        cvt.conn2if(cfg["dhcp/relay/via_conn"]))
    else
        script.action(lglink .. "/dhcpprovider/add_server_subnet")

        local snlink = lglink .. "/dhcp/subnet"

        script.map(lglink .. "/dhcpprovider/server_subnet", snlink)

        script.set(snlink .. "/minaddr",
                   cvt.ip4_dotted_to_octets(cfg["dhcp/server/ip/start"]))
        script.set(snlink .. "/maxaddr",
                   cvt.ip4_dotted_to_octets(cfg["dhcp/server/ip/end"]))

        if cfg["dhcp/server/lease"] then
            script.action(snlink .. "/option/add",
                          { "enabled", "boolean", "True",
                            "name", "string", "lease" },
                          "link", snlink .. "/option/name/lease")
            script.set(snlink .. "/option/name/lease/value/string",
                       cfg["dhcp/server/lease"], "string")
        end

        script.action(snlink .. "/option/add",
                      { "enabled", "boolean", "True",
                        "name", "string", "router" },
                      "link", snlink .. "/option/name/router")
        script.set(snlink .. "/option/name/router/value/binary", addr, "octets")

        script.action(snlink .. "/option/add",
                      { "enabled", "boolean", "True",
                        "name", "string", "dns" },
                      "link", snlink .. "/option/name/dns")
        script.set(snlink .. "/option/name/dns/value/binary", addr, "octets")

        script.action(snlink .. "/option/add",
                      { "enabled", "boolean", "True",
                        "name", "string", "subnet" },
                      "link", snlink .. "/option/name/subnet")
        script.set(snlink .. "/option/name/subnet/value/string",
                   netmask, "string")

        if domain then
            script.action(snlink .. "/option/add",
                          { "enabled", "boolean", "True",
                            "name", "string", "domain" },
                          "link", snlink .. "/option/name/domain")
            script.set(snlink .. "/option/name/domain/value/string",
                       domain, "string")
        end

        if not util.failsafe_call(configure_lan_group_dhcp_server,
                                  id, entry, dplink) then
            log.error("Failed to configure LAN group %s DHCP server\n", id)
        end
    end

    script.set(dplink .. "/admin", "True", "boolean")
end

---
-- Genereate commands to cleanup existing LAN groups and add a new.
--
function process.post()
    local need_cleanup = true

    script.select(10)
    for id, entry in pairs(data) do
        if need_cleanup then
            script.prio_action(5, "/generic/cleanup",
                               { "link", "link", "/lan/group" })
            need_cleanup = false
        end
        if not util.failsafe_call(process.add, id, entry) then
            log.error("Failed to configure LAN group %s\n", id)
        end
    end
end

return process
