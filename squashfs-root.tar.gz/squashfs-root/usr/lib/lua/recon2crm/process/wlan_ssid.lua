--
-- Wireless SSID
--

local log     = require("recon2crm.log")
local util    = require("recon2crm.util")
local map     = require("recon2crm.map")
local cvt     = require("recon2crm.cvt")
local script  = require("recon2crm.script")

local process = {}

-- WLAN SSID parameter pattern
process.pattern = "^wlan_ssid_(%d+):settings/(%S+)$"

---
-- WLAN SSID parameter processing.
--
-- @param val           Value
-- @param id            WLAN SSID ID
-- @param par           Parameter
--
function process.param(val, id, par)
    local upper = "/RECON/if/port/wlan/ssid/" .. id
    local link = upper .. "/iface"
    local psk_link = link .. "/security/rsn_psk/table/"
    local par_map = {
        { p = "^name$",
          f = function()
            script.prio_action(20, "/RECON/if/port/wlan/add_upper",
                               { "config_map", "string", "recon_ssid_" .. id,
                                 "type", "string", "wlan_drv_if",
                                 "name", "string", val },
                               "upper", upper)
            script.prio_map(20, link, "/RECON/wlan/ssid/id/" .. id)
            script.prio_set(20, link .. "/ssid", val, "string")
            script.prio_set(70, link .. "/admin", "True", "boolean")
          end },
        { p = "^lan_name$",
          f = function()
            local lan_group = (cvt.lan_group(val))

            script.prio_action(40, lan_group .. "/add_vif",
                               { "if", "link", link },
                               "link", lan_group .. "/vif/ssid/" .. id)
          end },
        { p = "^psk(.*)_used$",
          f = function(psk)
            if psk == "_zero" then
                -- 'mac' is a key parameter, but it is not specified for
                -- default psk
                script.prio_action(30, link .. "/security/rsn_psk/add",
                                   { "mac", "octets", "000000000000" },
                                   "link", psk_link .. psk)
            end
            script.prio_set(40, psk_link .. psk .. "/psk_used", val, "boolean")
          end },
        { p = "^psk(.*)$",
          f = function(psk)
            script.prio_set(40, psk_link .. psk .. "/psk", val, "octets")
          end },
        { p = "^mac(.*)$",
          f = function(psk)
            -- 'mac' is a key parameter, but it is not specified for
            -- default psk
            script.prio_action(30, link .. "/security/rsn_psk/add",
                               { "mac", "octets", (cvt.mac_to_octets(val)) },
                               "link", psk_link .. psk)
          end },
        { p = "^passphrase(.*)$",
          f = function(psk)
            script.prio_set(40, psk_link .. psk .. "/passphrase", val, "string")
          end },
        { p = "^enable(.*)$",
          f = function(psk)
            if val == "1" then
                script.prio_set(50, psk_link .. psk .. "/enabled",
                                val, "boolean")
            end
          end },
    }

    for i, m in ipairs(par_map) do
        local arg = par:match(m.p)

        if arg then
            m.f(arg)
            return
        end
    end

    local crm_param, post, crm_value, crm_type =
        map.apply("wlan_ssid", par, val)

    if crm_param then
        script.prio_set(post and 60 or 40, link .. "/" .. crm_param,
                        crm_value, crm_type)
    else
        util.errorf("Unknown WLAN SSID parameter: %s", par)
    end
end

return process
