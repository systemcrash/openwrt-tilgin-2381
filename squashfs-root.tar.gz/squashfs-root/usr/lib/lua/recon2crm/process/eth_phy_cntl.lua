--
-- Physical Ethernet ports PHY control 
--

local util    = require("recon2crm.util")
local cvt     = require("recon2crm.cvt")
local script  = require("recon2crm.script")

local process = {}

-- PHY control parameter template.
process.pattern = "^PHY_CNTL_(%S*)$"

---
-- PHY control parameter processing.
--
-- @param val           Value
-- @param var           Parameter
--
function process.param(val, port)
    local port_link = (cvt.port(port))
    local num = tonumber("0x" .. val)

    script.set(port_link .. "/prop/autoneg/enabled",
               util.is_bit_set(num, 12), "boolean")
    script.set(port_link .. "/speed_admin",
               (util.is_bit_set(num, 13) ~= 0) and "100" or "10", "u16")
    script.set(port_link .. "/full_duplex_admin",
               util.is_bit_set(num, 8), "boolean")

    num = util.clear_bit(util.clear_bit(util.clear_bit(num, 8), 12), 13)
    if num ~= 0 then
        util.errorf("Not supported Ethernet PHY contol bits 0x%x", num)
    end
end

return process
