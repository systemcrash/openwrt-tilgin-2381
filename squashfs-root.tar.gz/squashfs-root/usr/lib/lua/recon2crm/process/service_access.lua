--
-- Service access configuration
--

local cvt     = require("recon2crm.cvt")
local script  = require("recon2crm.script")

local process = {}
local data    = {}


---
-- Get service access entry
--
-- @param service       Service name
--
function process.entry(service)
    local entry = data[service]

    if not entry then
        entry = { dom = {} }
        data[service] = entry
    end

    return entry
end

---
-- Configure service access for specified subnet.
--
-- @param srv           Service name
-- @param dom           WAN or LAN domain
-- @param enabled       Should rule be enabled (True/False stirng)?
-- @param id            Rule ID
-- @param val           Subnet
--
local function configure_service_access_subnet(srv, dom, enabled, id, val)
    local rules = "/service/instance/table/" .. srv .. "/rule"
    local addr, prefix = val:match("([^/]+)/(.*)")

    if not addr then
        addr = val
        prefix = 32
    end

    script.action(rules .. "/add",
                  { "wan", "boolean", dom == "wan" and "True" or "False",
                    "address", "octets",
                    addr == "0" and "00000000" or
                        (cvt.ip4_dotted_to_octets(addr)),
                    "prefix", "u8", prefix,
                    "enabled", "boolean", enabled },
                  "link", rules .. "/table/recon_" .. dom .. "_" .. id)
end


---
-- Configure service access for specified subnets.
--
-- @param srv           Service name
-- @param dom           WAN or LAN domain
-- @param enabled       Should rule be enabled (True/False stirng)?
-- @param val           Comma-separated subnets
--
local function configure_service_access(srv, dom, enabled, val)
    local id = 0

    for s in val:gmatch("%s*([^%s,]+)%s*,?") do
        id = id + 1
        configure_service_access_subnet(srv, dom, enabled, id, s)
    end
end

---
-- Configure services access in accordance with collected parameters.
--
function process.post()
    script.select(40)
    for srv, entry in pairs(data) do
        local enabled = entry.enabled

        if not enabled then
            if srv == "storage_http" or srv == "telnet" then
                enabled = "True"
            else
                enabled = "False"
            end
        end
        for dom, val in pairs(entry.dom) do
            configure_service_access(srv, dom, enabled, val)
        end
    end
end

return process
