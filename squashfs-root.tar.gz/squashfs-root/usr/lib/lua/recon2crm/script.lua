local util    = require("recon2crm.util")

local script  = {}
local scripts = {}

-- Variables
script.override = false

---
-- io.write wrapper to raise fatal exception in the case of failure.
--
local function io_write(str)
    local ok, e = pcall(io.write, str)

    if not ok then
        util.fatal_error(e)
    end
end

---
-- io_write wrapper to deal with format string.
--
local function io_printf(fmt, ...)
    io_write(fmt:format(...))
end

---
-- Generate CRM set request.
--
-- @param path          CRM MIT path
-- @param val           Value
-- @param type          CRM value type
--
function script.set(path, val, type)
    io_printf('%sset "%s" %s "%s"\n',
              script.override and "o" or "", path, type or "auto", val)
end

---
-- Generate CRM map request.
--
-- @param path          CRM MIT path
-- @param val           Mapping "from" value
--
function script.map(path, val)
    io_printf('map "%s" "%s"\n', path, val)
end


---
-- "Triple" iterator function.
--
local function triple_iter_fn(args)
    if args[1] then
        return table.remove(args, 1),
               table.remove(args, 1),
               table.remove(args, 1)
    else
        return nil
    end
end

---
-- "Triple" iterator for 'for' loop.
--
local function triple_iter(args)
    return triple_iter_fn, args
end

---
-- Generate CRM action request.
--
-- @param path          CRM action path
-- @param in_args       Action input arguments table
-- @param out_name      Action output parameter name
-- @param out_value     Action output parameter value
--
function script.action(path, in_args, out_name, out_value)
    local chunks = {}

    table.insert(chunks, "action \""  .. path .. "\" {\n")
    if in_args then
        for n, t, v in triple_iter(in_args) do
            table.insert(chunks,
                         ('    in "%s" %s "%s"\n'):format(n, t, v))
        end
    end
    if out_name then
        table.insert(chunks,
                     ('    out "%s" "" "%s"\n'):format(out_name, out_value))
    else
        table.insert(chunks, '    out "" "" ""\n')
    end
    table.insert(chunks, "}\n")
    io_write(table.concat(chunks))
end

---
-- Generate CRM find request.
--
-- @param path          CRM set path
-- @param in_args       Search input arguments (criteria)
-- @param out           Search result link
--
function script.find(path, in_args, out)
    local chunks = {}

    table.insert(chunks, "find \""  .. path .. "\" {\n")
    for n, t, v in triple_iter(in_args) do
        table.insert(chunks,
                     ('    in "%s" %s "%s"\n'):format(n, t, v))
    end
    table.insert(chunks, ('    out "%s"\n'):format(out))
    table.insert(chunks, "}\n")
    io_write(table.concat(chunks))
end


function script.select(prio)
    if not scripts[prio] then
        scripts[prio] = {}
        scripts[prio].name = script.root .. "/tmp/recon2crm." .. prio .. ".crm"
        scripts[prio].handle = io.open(scripts[prio].name, "w+")
    end
    io.output(scripts[prio].handle)
end

---
-- Generate CRM set request with specified priority.
--
function script.prio_set(prio, path, val, type)
    local old = io.output()

    script.select(prio)
    script.set(path, val, type)
    io.output(old)
end

---
-- Generate CRM map request with specified priority.
--
function script.prio_map(prio, path, val)
    local old = io.output()

    script.select(prio)
    script.map(path, val)
    io.output(old)
end

---
-- Generate CRM action with specified priority.
--
function script.prio_action(prio, path, in_args, out_name, out_value)
    local old = io.output()

    script.select(prio)
    script.action(path, in_args, out_name, out_value)
    io.output(old)
end

---
-- Generate CRM find with specified priority.
--
function script.prio_find(prio, path, in_args, out)
    local old = io.output()

    script.select(prio)
    script.find(path, in_args, out)
    io.output(old)
end

---
-- Merge intermediate scripts into one
--
function script.merge(result_script)
    local scripts_prios = {}
    local scripts_list = ""

    -- Create array or priorities to sort
    for prio, script in pairs(scripts) do
        table.insert(scripts_prios, prio)
        script.handle:close()
    end
    table.sort(scripts_prios)

    -- Create list of intermediate scripts in accordance with priority
    for pos, prio in ipairs(scripts_prios) do
        scripts_list = scripts_list .. " " .. scripts[prio].name
    end

    -- Concatenate intermediate scripts
    os.execute("cat" .. scripts_list .. " >" .. result_script)
end

---
-- Remove temporary files
--
function script.cleanup()
    for prio, script in pairs(scripts) do
        os.remove(script.name)
    end
end

return script
