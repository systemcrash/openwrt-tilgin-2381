--
-- CRM printing spooler library.
--
-- @author  Nikolai Kondrashov <Nikolai.Kondrashov@oktetlabs.ru>
-- @id $Id: crmlp.lua 144202 2010-03-09 10:39:38Z nikolai.kondrashov $
--
local crm   = require("crm")
local crmlp = {}


function crmlp.lkp_printer(printing, printer_name)
    for printer_id, printer in printing.printer.table.iaka("printer %s").
                                                        as_iter() do
        if printer.name.aka("name").as_string() == printer_name then
            return printer_id, printer
        end
    end
end


local function slice_list(t, s, e)
    local slice = {}

    for i = s, e, 1 do
        table.insert(slice, t[i])
    end

    return slice
end


local function brace_list(list)
    for k in pairs(list) do
        list[k] = "<" .. list[k] .. ">"
    end
    return list
end


local function wrap_func(func, printer_name, ...)
    local t         = crm.transaction():open("clp", crm.tc_type.RW, 10000)
    local printing  = t:mit().printing

    local printer_id, printer   = crmlp.lkp_printer(printing, printer_name)

    if not printer then
        error(("Unknown printer \"%s\""):format(printer_name))
    end

    func(printer, ...)

    t:close()
end


function crmlp.main(func, arg_list, ...)
    local arg_name_list = {"printer_name", ...}

    -- Disable traces unless CLP_DEBUG environment variable
    -- is set to a non-zero number
    if (tonumber(os.getenv("CLP_DEBUG")) or 0) == 0 then
        debug = false
    end

    if #arg_list ~= #arg_name_list then
        io.stderr:write("Invalid number of arguments\n" ..
                        "Usage: " ..
                        arg_list[0]:match("[^/]+$") .. " " ..
                        table.concat(brace_list(arg_name_list), " ") ..
                        "\n")
        return 1
    end

    local ok, e = pcall(wrap_func, func,
                        unpack(slice_list(arg_list, 1, #arg_name_list)))

    if ok then
        return 0
    else
        io.stderr:write(tostring(e) .. "\n")
        return 1
    end
end

return crmlp
