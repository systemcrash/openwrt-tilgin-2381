---
-- Lua utilities - basic error, an error with single message string.
-- @release $Id: $
--

local oo        = require("loop.simple")
local err       = {}
err.Basic       = oo.class({_NAME = "err.Basic"}, require("err.Abstract"))


---
-- Initialize an error.
--
-- @param str   Error message string.
--
-- @return New error.
--
function err.Basic:__init(str)
    return oo.rawnew(self, {str = str})
end


---
-- Retrieve error message.
--
-- @return Error message.
--
function err.Basic:msg()
    return self.str
end


return err.Basic
