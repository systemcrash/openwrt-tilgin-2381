---
-- Lua utilities - errno error, an error with errno code
-- @release $Id: Errno.lua 144719 2010-03-22 11:18:44Z nikolai.kondrashov $
--

local oo        = require("loop.simple")
local errno     = require("errno")
local err       = {}
err.Errno       = oo.class({_NAME = "err.Errno"}, require("err.Abstract"))


---
-- Initialize an error.
--
-- @param errnum    Error number.
--
-- @return New error.
--
function err.Errno:__init(errnum)
    return oo.rawnew(self, {errnum = errnum})
end


---
-- Retrieve error message.
--
-- @return Error message.
--
function err.Errno:msg()
    return errno.tostring(self.errnum)
end


return err.Errno
