---
-- Lua utilities - basic formatted error, an abstract error which formats
-- basic message.
-- @release $Id: $
--

local oo            = require("loop.simple")
local err           = {}
err.Basic           = require("err.Basic")
err.BasicFormatted  = oo.class({_NAME = "err.BasicFormatted"}, err.Basic)

---
-- Format error message, using format string from @e fmt field, if any.
--
-- @return Error message.
--
function err.BasicFormatted:msg()
    -- Ask the superclass to generate the message for us
    local m = err.Basic.msg(self);

    if type(self.fmt) == "string" then
        return string.format(self.fmt, m)
    else
        return m
    end
end


return err.BasicFormatted
