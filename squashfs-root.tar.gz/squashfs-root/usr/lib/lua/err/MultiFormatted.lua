---
-- Lua utilities - multi-formatted error, an abstract error which stores and
-- formats arbitrary arguments with arbitrary format string.
-- @release $Id: $
--

local oo            = require("loop.simple")
local err           = {}
err.Abstract        = require("err.Abstract")
err.MultiFormatted  = oo.class({_NAME = "err.MultiFormatted"},
                               err.Abstract)

---
-- Initialize error, using argument description from class @e arg field.
--
function err.MultiFormatted.__init(class, ...)
    local self  = err.Abstract:__init()
    local val   = {...}
    local i
    local arg

    if type(class.arg) == "table" then
        for i, arg in ipairs(class.arg) do
            self[arg.name] = val[i]
        end
    end

    return oo.rawnew(class, self)
end


---
-- Format error message, using format string from @e fmt field and argument
-- description from @e arg field.
--
-- @return Error message.
--
function err.MultiFormatted:msg()
    local val   = {}
    local i
    local arg

    if type(self.arg) == "table" then
        for i, arg in ipairs(self.arg) do
            if type(arg.conv) == "function" then
                val[i] = arg.conv(self[arg.name])
            else
                val[i] = self[arg.name]
            end
        end
    end

    if type(self.fmt) ~= "string" then
        return string.format(self.fmt, unpack(val))
    end
    
    return ""
end


return err.MultiFormatted
