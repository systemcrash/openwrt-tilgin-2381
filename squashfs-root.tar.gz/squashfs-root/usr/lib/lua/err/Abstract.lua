---
-- Lua utilities - abstract error, an error without message.
-- @release $Id: $
--

local oo        = require("loop.simple")
local err       = {}
err.Abstract    = oo.class({_NAME = "err.Abstract"})


---
-- Initialize an error.
--
-- @return New error.
--
function err.Abstract:__init()
    return oo.rawnew(self)
end


---
-- Attach a sub-error to this error
--
-- @param sub   Sub-error
--
-- @return This error with sub-error attached below.
--
function err.Abstract:attach(sub)
    self.err = sub
    return self
end


---
-- Match an error class in an error chain.
--
-- @param class Error class to look for.
--
-- @return First matching error in the error chain, or nil if none.
--
function err.Abstract:match(class)
    if oo.instanceof(self, class) then
        return self
    elseif not oo.instanceof(self, err.Abstract) then
        return nil
    end

    return self.err:match(class)
end


---
-- Format this error stack message.
-- 
-- @return Error stack message.
--
function err.Abstract:stack_msg()
    local e = self
    local s = {}
    local m

    repeat
        if type(e.msg) == "function" then
            m = e:msg()
            if #m > 0 then
                s[#s + 1] = m
            end
        end
        e = e.err
    until (e == nil) or (type(e) ~= "table")

    return table.concat(s, ": ")
end


function err.Abstract:dump()
    local s = {}

    if type(self._TRACEBACK) == "string" then
        s[#s + 1] = self._TRACEBACK
    end

    do
        local t = {}

        if self._NAME then
            t[#t + 1] = self._NAME
        end

        if type(self.msg) == "function" then
            t[#t + 1] = self:msg()
        end

        if #t > 0 then
            s[#s + 1] = table.concat(t, ": ")
        end
    end

    return table.concat(s, "\n")
end


---
-- Convert this error to a string
--
-- @return String representation.
--
function err.Abstract:__tostring()
    local e             = self
    local dump          = {}
    local msg           = {}
    local str           = {}
    local d
    local m

    repeat
        -- Format dump
        if oo.instanceof(e, err.Abstract) then
            -- Get stripped dump
            d = debug and string.match(e:dump(), "^%s*(.-)%s*$") or nil
            -- Get stripped single-line message
            m = string.gsub(string.match(e:msg(), "^%s*(.-)%s*$"), "\n", " ")
        else
            -- Get error's stripped string representation
            local s = string.match(tostring(e), "^%s*(.-)%s*$")

            -- Make error string representation be the dump
            d = debug and s or nil
            -- Make last line of string representation be the message
            m = string.match(s, "([^\n]*)$")
        end

        -- If dump is non-empty
        if d ~= nil and #d > 0 then
            -- Remember dump
            table.insert(dump, 1, d)
        end

        -- If message is non-empty
        if m ~= nil and #m > 0 then
            -- Remember message
            msg[#msg + 1] = m
        end

        -- Continue with sub-error
        e = oo.instanceof(e, err.Abstract) and e.err or nil
    until e == nil

    -- If there are any dumps
    if #dump > 0 then
        str[#str + 1] = table.concat(dump, "\n\n")
    end

    -- If there are any messages
    if #msg > 0 then
        str[#str + 1] = table.concat(msg, ": ")
    end

    return table.concat(str, "\n\n")
end


return err.Abstract


