---
-- WebUI-extended object-oriented Lua HDF interface.
-- @release $Id: hdf.lua 158244 2011-10-19 13:15:44Z marina.maslova $
--


local intl  = require("intl")
local hdf   = require("hdf")
local crm   = {}
crm.value   = require("crm.value")


for i, n in ipairs({"u8", "s8", "u16", "s16", "u32", "s32", "u64", "s64",
                    "string"}) do
    hdf["as_crm_" .. n] = function (self)
        return crm.value[n](self)
    end
end


function hdf:req_nonempty()
    if self.is_empty() then
        error(hdf.err.Req(_("%s is not specified"), self))
    end

    return self
end


function hdf:req_nonblank()
    if self.is_blank() then
        error(hdf.err.Req(_("%s is blank"), self))
    end

    return self
end


function hdf:req_number()
    if not self.is_number() then
        error(hdf.err.Req(_("invalid %s, must be an integer number"), self))
    end

    return self
end


function hdf:req_specified()
    if self.is_blank() then
        error(hdf.err.Req(_("%s is not specified"), self))
    end

    return self
end


function hdf:req_regex(desc, regex)
    if not self.is_regex(regex) then
        error(hdf.err.Req(_("%%s is invalid, must be %s"):format(desc),
                          self))
    end

    return self
end


function hdf:req_range(min, max)
    if not self.req_specified().is_range(min, max) then
        error(hdf.err.Req(_("invalid %%s, must be an integer " ..
                            "in range %s-%s"):
                            format(tostring(min), tostring(max)),
                          self))
    end

    return self
end


function hdf:as_crm_boolean()
    return crm.value.boolean(self.as_boolean())
end


function hdf:as_crm_ip_addr()
    local str, ip, tmp, i

    str = tostring(self)

    if str == nil or str:match("^%s*$") then
        error(hdf.err.Conv(_("%s: IP address is not specified"), self))
    end

    ip = {str:match("^%s*(%d+)%.(%d+)%.(%d+)%.(%d+)%s*$")}

    if ip[1] then
        ip[1] = tonumber(ip[1])
        ip[2] = tonumber(ip[2])
        ip[3] = tonumber(ip[3])
        ip[4] = tonumber(ip[4])

        if ip[1] > 255 or ip[2] > 255 or ip[3] > 255 or ip[4] > 255 then
            error(hdf.err.Conv(_("%s: invalid IP address"), self))
        end
    else
        ip = {}
        local number, j, zero_len, zero_start, tail

        -- try to match IPv4-mapped IPv6 addresses
        -- e.g‥ ::FFFF:204.152.189.11
        tmp = {str:match("(.*:)(%d+)%.(%d+)%.(%d+)%.(%d+)%s*$")}
        tail = 0
        if tmp[1] then
            for i = 2, 5 do
                number = tonumber(tmp[i])

                if not number or number > 255 then
                     error(hdf.err.Conv(_("%s: invalid IP address"), self))
                end
                    
                ip[i + 11] = number
            end
            str = tmp[1]
            tail = 1
        end

        i = 1
        zero_start = 0
        for number in str:gmatch("(%x*):") do
            if number ~= "" then
                tmp[i] = tonumber(number, 16)
            else
                tmp[i] = 0
                zero_start = i
            end
            i = i + 1
        end

        zero_len = 8 - i - tail
        if (zero_len < 0) then
            error(hdf.err.Conv(_("%s: invalid IP address"), self))
        end

        if tail ~= 1 then
            -- get last one
            number = str:match(":(%x*)$")
            if number then
                if number ~= "" then
                    tmp[i] = tonumber(number, 16)
                else
                    tmp[i] = 0
                end
            else
                error(hdf.err.Conv(_("%s: invalid IP address"), self))
            end
        end

        j = 1
        for i = 1, 8 - tail * 2 do
            if (i > zero_start) and (i <= zero_start + zero_len) then
                ip[2 * i] = 0
                ip[2 * i - 1] = 0 
            else
                if not tmp[j] then
                    error(hdf.err.Conv(_("%s: invalid IP address"), self))
                end
                ip[2 * i] = tmp[j] % 256
                ip[2 * i - 1] = (tmp[j] - ip[2 * i]) / 256
                if ip[2 * i - 1] > 255 then
                    error(hdf.err.Conv(_("%s: invalid IP address"), self))
                end
                j = j + 1
            end
        end
    end

    return crm.value.octets_from_array(ip)
end


function hdf:as_crm_mac_addr()
    local mac = {tostring(self):
                    match("^%s*(%x+):(%x+):(%x+):(%x+):(%x+):(%x+)%s*$")}

    if not mac[1] then
        error(hdf.err.Conv(_("%s: invalid MAC address"), self))
    end

    for i, v in ipairs(mac) do
        if #v > 2 then
            error(hdf.err.Conv(_("%s: invalid MAC address"), self))
        end
        mac[i] = tonumber(v, 16)
    end

    return crm.value.octets_from_array(mac)
end


return hdf


