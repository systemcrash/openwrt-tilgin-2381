---
-- WebUI-extended bigger Lua integers.
-- @release $Id: int.lua 134346 2009-06-04 10:15:58Z nikolai.kondrashov $
--

local int   = require("int")
local intl  = require("intl")

function int.u64:binary_scaled_bytes()
    if self < int.u64(2 * 1024) then
        return self, _("bytes")
    elseif self < int.u64(2 * (1024 ^ 2)) then
        return self / 1024, _("KiB")
    elseif self < int.u64(2 * (1024 ^ 3)) then
        return self / (1024 ^ 2), _("MiB")
    elseif self < (2 * (int.u64(1024) ^ 4)) then
        return self / (1024 ^ 3), _("GiB")
    else
        return self / (int.u64(1024) ^ 4), _("TiB")
    end
end


function int.u64:decimal_scaled_bytes()
    if self < int.u64(2 * 1000) then
        return self, _("bytes")
    elseif self < int.u64(2 * (1000 ^ 2)) then
        return self / 1000, _("KB")
    elseif self < int.u64(2 * (1000 ^ 3)) then
        return self / (1000 ^ 2), _("MB")
    elseif self < (2 * (int.u64(1000) ^ 4)) then
        return self / (1000 ^ 3), _("GB")
    else
        return self / (int.u64(1000) ^ 4), _("TB")
    end
end


return int
