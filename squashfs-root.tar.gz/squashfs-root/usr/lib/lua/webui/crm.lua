---
-- WebUI-extended object-oriented Lua CRM interface.
-- @release $Id: crm.lua 134346 2009-06-04 10:15:58Z nikolai.kondrashov $
--

local os    = require("os")
local crm   = require("crm")

crm.transaction.webui_user_env          = "WEBUI_CRM_USER"
crm.transaction.webui_default_user      = "webui"
crm.transaction.webui_default_timeout   = 15000


---
-- Retrieve WebUI CRM username.
--
-- @return WebUI CRM username.
--
function crm.transaction.webui_get_user()
    return os.getenv(crm.transaction.webui_user_env) or
           crm.transaction.webui_default_user
end


---
-- Open transaction with WebUI user.
--
-- @param type      Transaction type
-- @param timeout   Optional transaction timeout
--
-- @return Opened transaction.
--
function crm.transaction:webui_open(type, timeout)
    return self:open(
                self.webui_get_user(),
                type,
                timeout or self.webui_default_timeout)
end


---
-- Open read-only transaction with WebUI user.
--
-- @param timeout   Optional transaction timeout
--
-- @return Opened transaction.
--
function crm.transaction:webui_open_ro(timeout)
    return self:webui_open(crm.tc_type.RO, timeout)
end


---
-- Open read-write transaction with WebUI user.
--
-- @param timeout   Optional transaction timeout
--
-- @return Opened transaction.
--
function crm.transaction:webui_open_rw(timeout)
    return self:webui_open(crm.tc_type.RW, timeout)
end


return crm


