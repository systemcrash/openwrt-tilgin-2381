---
-- Object-oriented ClearSilver error interface.
--
-- Here we hack LOOP a bit.
--
-- @release $Id: $
--

local oo        = require("loop.simple")
local nerr      = oo.class(require("luanerr"),
                           require("err.Abstract"))

function nerr:__init(type, msg)
    return self.raise(type, msg)
end


function nerr.check(e)
    if not nerr.match(e, nerr.type.STATUS_OK) then
        error(e)
    end
end


nerr.msg = nerr.get_desc
nerr.dump = nerr.error_traceback

return nerr
