---
-- Lua utilities - loaded packages/files snapshots.
-- @release $Id: $
--

require("reqfile")

local snapshot = {}


local function prepare_new_list(list, new_list)
    local got_new_item = false

    for k, v in pairs(new_list) do
        if list[k] == nil and type(v) == "table" then
            local f = rawget(v, "_pose_for_snapshot")
            if f ~= nil then
                f(v)
                got_new_item = true
            end
        end
    end

    return got_new_item
end


local function prepare_iter(packages, files)
    local new_packages      = {}
    local got_new_package
    local new_files         = {}
    local got_new_file

    -- Retrieve loaded packages
    for k, v in pairs(package.loaded) do
        new_packages[k] = v
    end

    -- Retrieve loaded files
    for k, v in pairs(reqfile) do
        new_files[k] = v
    end

    -- Prepare packages missing in the original list
    got_new_package = prepare_new_list(packages, new_packages)
    -- Prepare files missing in the original list
    got_new_file = prepare_new_list(files, new_files)

    return (got_new_package or got_new_file), new_packages, new_files
end


function snapshot.take()
    local packages      = {}
    local files         = {}
    local got_new_item

    -- Prepare files and packages until no more new ones are loaded
    repeat
        got_new_item, packages, files = prepare_iter(packages, files)
    until not got_new_item

    -- Take snapshot
    snapshot.state = {packages = packages, files = files}
end


function snapshot.restore()
    local packages
    local files
    
    if snapshot.state ~= nil then
        packages = snapshot.state.packages
        files = snapshot.state.files
    end

    for k in pairs(package.loaded) do
        package.loaded[k] = nil
    end
    if packages ~= nil then
        for k, v in pairs(packages) do
            package.loaded[k] = v
        end
    end

    for k in pairs(reqfile) do
        reqfile[k] = nil
    end
    if files ~= nil then
        for k, v in pairs(files) do
            reqfile[k] = v
        end
    end
end


return snapshot
