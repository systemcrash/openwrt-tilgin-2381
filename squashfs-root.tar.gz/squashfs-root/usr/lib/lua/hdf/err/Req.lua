---
-- Object-oriented ClearSilver HDF interface - requirement failure error.
-- @release $Id: $
--

local oo        = require("loop.simple")
local hdf       = {}
hdf.err         = {}
hdf.err.Node    = require("hdf.err.Node")
hdf.err.Req     = oo.class({_NAME   = "hdf.err.Req"},
                           hdf.err.Node)


function hdf.err.Req:__init(fmt, ...)
    local e = hdf.err.Node:__init(...)
    e.fmt = fmt
    return oo.rawnew(self, e)
end


return hdf.err.Req


