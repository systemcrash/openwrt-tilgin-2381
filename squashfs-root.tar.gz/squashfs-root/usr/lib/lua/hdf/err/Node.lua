---
-- Object-oriented ClearSilver HDF interface - Node error.
-- @release $Id: $
--

local oo        = require("loop.simple")
local hdf       = {}
local err       = {}
err.Abstract    = require("err.Abstract")
hdf.err         = {}
hdf.err.Node    = oo.class({_NAME   = "hdf.err.Node"}, err.Abstract)


---
-- Initialize a node error.
--
-- @param node  Node on which the error has happened.
--
-- @return New error.
--
function hdf.err.Node:__init(node)
    local e = err.Abstract:__init()
    e.node = node
    return oo.rawnew(self, e)
end


---
-- Format error message.
--
-- @return Error message.
--
function hdf.err.Node:msg()
    local s = self.node.branch_title_list()

    assert(self.fmt ~= nil)

    s[#s] = string.format(self.fmt, s[#s])

    return table.concat(s, ": ")
end


return hdf.err.Node
