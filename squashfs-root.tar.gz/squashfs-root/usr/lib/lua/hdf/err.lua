---
-- Object-oriented ClearSilver HDF interface - errors.
-- @release $Id$
--

local meta = {}

function meta.__index(t, k)
    local v = require("hdf.err." .. k)
    t[k] = v
    return v
end

local err = setmetatable({}, meta)

---
-- Pose for a package snapshot - load all sub-packages.
--
function err:_pose_for_snapshot()
    local packages = {
                "Conv",
                "Node",
                "Req",
            }

    -- Load all subpackages
    for i, n in pairs(packages) do
        local p = self[n]
    end

    -- Remove package loading metatable since all packages are loaded now
    -- and to catch packages which weren't added to the above list
    setmetatable(self, nil)
end

return err
