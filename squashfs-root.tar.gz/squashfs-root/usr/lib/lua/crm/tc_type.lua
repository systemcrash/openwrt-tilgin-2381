---
-- Object-oriented Lua CRM interface - transaction type overlay.
-- @release $Id: $
--

local crm = {}
crm.tc_type = require("luacrm.tc_type")

function crm.tc_type.tostring(type)
    return type == crm.tc_type.RO and "read-only"
                                   or "read-write"
end

return crm.tc_type
