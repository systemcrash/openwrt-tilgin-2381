---
-- Object-oriented Lua interface to CRM - transaction.
-- @release $Id$
--

local oo            = require("loop.simple")
local crm           = {}
crm.err             = require("crm.err")
crm.node            = require("crm.node")
crm.value_type      = require("crm.value_type")
crm.value           = require("crm.value")
crm.status          = require("crm.status")
crm.tc_type         = require("crm.tc_type")
crm.transaction     = require("luacrm.transaction")
crm.subscription    = require("crm.subscription")


---
-- Close (commit) transaction.
--
function crm.transaction:close()
    local ok, e = pcall(function ()
        self = self:done(true)
    end)

    if not ok then
        error(crm.err.TransactionClose():attach(e))
    end

    return self
end


---
-- Abort (rollback) transaction.
--
function crm.transaction:abort()
    local ok, e = pcall(function ()
        self = self:done(abort)
    end)

    if not ok then
        error(crm.err.TransactionAbort():attach(e))
    end

    return self
end


local luacrm_open = crm.transaction.open

function crm.transaction:open(user, type, timeout)
    local ok, e = pcall(function ()
        self = luacrm_open(self, user, type, timeout)
    end)

    if not ok then
        if type == crm.tc_type.RO then
            error(crm.err.TransactionOpenRO():attach(e))
        elseif type == crm.tc_type.RW then
            error(crm.err.TransactionOpenRW():attach(e))
        else
            error(e)
        end
    end

    return self
end


---
-- Create new access node for MIT root.
--
function crm.transaction:mit()
    return crm.node.root(self)
end


---
-- Create new access node for MIT path.
--
function crm.transaction:node(path)
    return crm.node(self, path)
end

---
-- Perform save schedule action.
--
function crm.transaction:save_schedule()
    crm.node.root(self).system.config_save.exec({}, {})
end

---
-- Perform voip restart action.
--
function crm.transaction:voip_restart()
    crm.node.root(self).voip.restart.exec({}, {})
end

---
-- Check if a CRM type is inherited from specified type.
--
-- @param name      CRM type name to check.
-- @param base_name Base CRM type name to check against.
--
-- @return True if @e typename is inherited from or is @e base_typename.
--
function crm.transaction:subtypeof(name, base_name)
    while name ~= base_name do
        local ok, e = pcall(function ()
            name = self:get("/type/" .. name .. "/parent/name"):get_string()
        end)

        if not ok then
            if oo.instanceof(e, crm.err.Status) and
               e.rc == crm.status.ENOENT then
                return false
            else
                error(e)
            end
        end
    end

    return true
end


---
-- Subscribe to a node value change.
--
-- @param path   Node path.
-- @param tlock  Required possibility to open a transaction:
--                   nil             - no requirement
--                   crm.tc_type.RO  - read-only transaction
--                   crm.tc_type.RW  - read-write transaction
-- @param period Value checking period, milliseconds.
-- @param notify Notification callback function.
-- @param opaque Optional opaque data to pass to notification function.
--
function crm.transaction:subscribe_change(path, tlock, period,
                                          notify, opaque)
    crm.subscription.subscribe_change(self, path, tlock, period,
                                      notify, opaque)
end


return crm.transaction
