---
-- Object-oriented Lua interface to CRM - value.
-- @release $Id$
--

local crm       = {}
crm.value_type  = require("crm.value_type")
crm.value       = require("luacrm.value")

function crm.value:__tostring()
    local type      = self:get_type()
    local string    = "[" .. crm.value_type.tostring(type) .. "]"

    if type ~= crm.value_type.INVALID and
       type ~= crm.value_type.NOINIT then
       string = string .. " " .. luacrm.value.tostring(self)
    end

    return string
end


-- Create type-initializing constructors (i.e. boolean(), string(), etc.)
local n, f
local t     = {}
for n, f in pairs(crm.value) do
    if type(f) == "function" and string.sub(n, 1, 5) == "init_" then
        t[string.sub(n, 6)] =
            function (v) return f(crm.value(), v) end
    end
end
for n, f in pairs(t) do
    crm.value[n] = f
end


return crm.value
