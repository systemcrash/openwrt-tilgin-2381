---
-- Object-oriented Lua interface to CRM - subscription.
-- @release $Id$
--

return require("luacrm.subscription")
