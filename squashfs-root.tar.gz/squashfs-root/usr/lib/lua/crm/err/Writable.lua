---
-- Object-oriented Lua CRM interface - node writability check error.
-- @release $Id: $
--

local intl          = require("intl")
local oo            = require("loop.simple")
local crm           = {}
crm.err             = {}
crm.err.Writable    = oo.class({_NAME   = "crm.err.Writable",
-- FIXME: use N_ when supported
                                fmt     = _("failed to check if %s " ..
                                            "is writable")},
                               require("crm.err.Node"))
return crm.err.Writable
