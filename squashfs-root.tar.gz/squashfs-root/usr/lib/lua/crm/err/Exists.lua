---
-- Object-oriented Lua CRM interface - node existence check error.
-- @release $Id: $
--

local intl      = require("intl")
local oo        = require("loop.simple")
local crm       = {}
crm.err         = {}
crm.err.Exists  = oo.class({_NAME   = "crm.err.Exists",
-- FIXME: use N_ when supported
                            fmt     = _("failed to check %s existence")},
                           require("crm.err.Node"))
return crm.err.Exists
