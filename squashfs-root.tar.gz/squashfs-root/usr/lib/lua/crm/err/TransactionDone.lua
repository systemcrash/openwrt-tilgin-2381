---
-- Object-oriented Lua CRM interface - abstract transaction finishing error.
-- @release $Id: $
--

local oo                = require("loop.simple")
local crm               = {}
crm.err                 = {}
crm.err.TransactionDone = oo.class({_NAME = "crm.err.TransactionDone",
                                    str   = nil},
                                   require("crm.err.Transaction"))
return crm.err.TransactionDone
