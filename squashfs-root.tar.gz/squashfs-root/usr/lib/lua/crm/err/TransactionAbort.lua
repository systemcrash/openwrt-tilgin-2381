---
-- Object-oriented Lua CRM interface - transaction abortion error.
-- @release $Id: $
--

local intl                  = require("intl")
local oo                    = require("loop.simple")
local crm                   = {}
crm.err                     = {}
crm.err.TransactionAbort    = oo.class({_NAME = "crm.err.TransactionAbort",
-- FIXME: use N_ when supported
                                        str   = _("failed to abort " ..
                                                  "transaction")},
                                       require("crm.err.TransactionDone"))
return crm.err.TransactionAbort
