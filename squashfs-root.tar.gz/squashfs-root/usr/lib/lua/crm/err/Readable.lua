---
-- Object-oriented Lua CRM interface - node readability check error.
-- @release $Id: $
--

local intl          = require("intl")
local oo            = require("loop.simple")
local crm           = {}
crm.err             = {}
crm.err.Readable    = oo.class({_NAME   = "crm.err.Readable",
-- FIXME: use N_ when supported
                                fmt     = _("failed to check if %s " ..
                                            "is readable")},
                               require("crm.err.Node"))
return crm.err.Readable
