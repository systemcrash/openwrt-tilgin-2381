---
-- Object-oriented Lua CRM interface - action parameter reseting error.
-- @release $Id: ActionExecute.lua 139333 2009-10-14 15:29:18Z nikolai.kondrashov $
--

local intl              = require("intl")
local oo                = require("loop.simple")
local crm               = {}
crm.err                 = {}
crm.err.ActionExecute   = oo.class({_NAME   = "crm.err.ActionExecute",
-- FIXME: use N_ when supported
                                    fmt     = _("failed to %s")},
                                   require("crm.err.Action"))
return crm.err.ActionExecute
