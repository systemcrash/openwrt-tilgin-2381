---
-- Object-oriented Lua CRM interface - action parameter reseting error.
-- @release $Id: ActionReset.lua 139333 2009-10-14 15:29:18Z nikolai.kondrashov $
--

local intl          = require("intl")
local oo            = require("loop.simple")
local crm           = {}
crm.err             = {}
crm.err.ActionReset = oo.class({_NAME   = "crm.err.ActionReset",
-- FIXME: use N_ when supported
                                fmt     = _("failed to reset \"%s\" " ..
                                             "action parameters")},
                               require("crm.err.Action"))
return crm.err.ActionReset

