---
-- Object-oriented Lua CRM interface - abstract transaction opening error.
-- @release $Id: $
--

local oo                = require("loop.simple")
local crm               = {}
crm.err                 = {}
crm.err.TransactionOpen = oo.class({_NAME = "crm.err.TransactionOpen",
                                    str   = nil},
                                   require("crm.err.Transaction"))
return crm.err.TransactionOpen
