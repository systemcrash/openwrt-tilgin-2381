---
-- Object-oriented Lua CRM interface - event handling error.
-- @release $Id: $
--

local intl              = require("intl")
local oo                = require("loop.simple")
local crm               = {}
crm.err                 = {}
crm.err.HandleEvents    = oo.class({_NAME = "crm.err.HandleEvents",
-- FIXME: use N_ when supported
                                    fmt   = _("failed to handle " ..
                                               "%s event")},
                                   require("err.BasicFormatted"))
return crm.err.HandleEvents
