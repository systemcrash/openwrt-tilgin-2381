---
-- Object-oriented Lua CRM interface - abstract action error.
-- @release $Id: $
--

local oo        = require("loop.simple")
local crm       = {}
crm.err         = {}
crm.err.Action  = oo.class({_NAME   = "crm.err.Action",
                            fmt     = nil},
                           require("crm.err.Node"))
return crm.err.Action
