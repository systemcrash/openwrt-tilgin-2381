---
-- Object-oriented Lua CRM interface - value retrieval error.
-- @release $Id: $
--

local intl      = require("intl")
local oo        = require("loop.simple")
local crm       = {}
crm.err         = {}
crm.err.Get     = oo.class({_NAME   = "crm.err.Get",
-- FIXME: use N_ when supported
                            fmt     = _("failed to get %s")},
                           require("crm.err.Node"))
return crm.err.Get
