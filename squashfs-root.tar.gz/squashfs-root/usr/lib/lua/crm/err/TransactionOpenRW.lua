---
-- Object-oriented Lua CRM interface - read-write transaction opening error.
-- @release $Id: $
--

local intl                  = require("intl")
local oo                    = require("loop.simple")
local crm                   = {}
crm.err                     = {}
crm.err.TransactionOpenRW   = oo.class({_NAME = "crm.err.TransactionOpenRW",
-- FIXME: use N_ when supported
                                        str   = _("failed to open " ..
                                                  "read-write " ..
                                                  "transaction")},
                                       require("crm.err.TransactionOpen"))
return crm.err.TransactionOpenRW
