---
-- Object-oriented Lua CRM interface - value storing error.
-- @release $Id: $
--

local intl      = require("intl")
local oo        = require("loop.simple")
local crm       = {}
crm.err         = {}
crm.err.Set     = oo.class({_NAME   = "crm.err.Set",
-- FIXME: use N_ when supported
                            fmt     = _("failed to set %s")},
                           require("crm.err.Node"))
return crm.err.Set
