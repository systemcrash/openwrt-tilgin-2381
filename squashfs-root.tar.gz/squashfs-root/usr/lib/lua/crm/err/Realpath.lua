---
-- Object-oriented Lua CRM interface - path resolution error.
-- @release $Id: $
--

local intl          = require("intl")
local oo            = require("loop.simple")
local crm           = {}
crm.err             = {}
crm.err.Realpath    = oo.class({_NAME   = "crm.err.Realpath",
-- FIXME: use N_ when supported
                                fmt     = _("failed to resolve %s path")},
                               require("crm.err.Node"))
return crm.err.Realpath
