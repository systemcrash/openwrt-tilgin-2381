---
-- Object-oriented Lua CRM interface - abstract transaction handling error.
-- @release $Id: $
--

local oo                = require("loop.simple")
local crm               = {}
crm.err                 = {}
crm.err.Transaction     = oo.class({_NAME = "crm.err.Transaction",
                                    str   = nil},
                                   require("err.Basic"))
return crm.err.Transaction
