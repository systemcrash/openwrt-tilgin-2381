---
-- Object-oriented Lua CRM interface - abstract subscription error.
-- @release $Id: $
--

local oo            = require("loop.simple")
local crm           = {}
crm.err             = {}
crm.err.Subscribe   = oo.class({_NAME   = "crm.err.Subscribe",
                                fmt     = nil},
                               require("crm.err.Node"))
return crm.err.Subscribe
