---
-- Object-oriented Lua CRM interface - status error.
-- @release $Id: $
--

local oo        = require("loop.simple")
local crm       = {}
local err       = {}
err.Abstract    = require("err.Abstract")
crm.status      = require("crm.status")
crm.err         = {}
crm.err.Status  = oo.class({_NAME = "crm.err.Status"}, err.Abstract)


---
-- Initialize an error.
--
-- @param rc    Status code.
--
-- @return New error.
--
function crm.err.Status:__init(rc)
    local e = err.Abstract:__init()
    e.rc = rc
    return oo.rawnew(self, e)
end


---
-- Check if a CRM status is OK; if not, raise an error.
--
-- @param rc    Status code.
--
function crm.err.Status.check(rc)
    if rc ~= crm.status.EOK then
        error(crm.err.Status(rc))
    end
end


---
-- Retrieve error message.
--
-- @return Error message.
--
function crm.err.Status:msg()
    return crm.status.tostring(self.rc)
end


return crm.err.Status
