---
-- Object-oriented Lua CRM interface - transaction closing error.
-- @release $Id: $
--

local intl                  = require("intl")
local oo                    = require("loop.simple")
local crm                   = {}
crm.err                     = {}
crm.err.TransactionClose    = oo.class({_NAME = "crm.err.TransactionClose",
-- FIXME: use N_ when supported
                                        str   = _("failed to close " ..
                                                  "transaction")},
                                       require("crm.err.TransactionDone"))
return crm.err.TransactionClose
