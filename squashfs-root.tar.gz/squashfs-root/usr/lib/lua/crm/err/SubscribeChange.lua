---
-- Object-oriented Lua CRM interface - change subscription error.
-- @release $Id: $
--

local intl              = require("intl")
local oo                = require("loop.simple")
local crm               = {}
crm.err                 = {}
crm.err.SubscribeChange = oo.class(
                            {_NAME = "crm.err.SubscribeChange",
-- FIXME: use N_ when supported
                             fmt   = _("failed to subscribe to " ..
                                        "%s change")},
                            require("crm.err.Subscribe"))
return crm.err.SubscribeChange
