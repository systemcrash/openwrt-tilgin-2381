---
-- Object-oriented Lua CRM interface - node error.
-- @release $Id: $
--

local intl      = require("intl")
local oo        = require("loop.simple")
local err       = {}
err.Abstract    = require("err.Abstract")
local crm       = {}
crm.err         = {}
crm.err.Node    = oo.class({_NAME   = "crm.err.Node"}, err.Abstract)


---
-- Initialize a node error.
--
-- @param node  Node on which the error has happened.
-- @param fmt   Message format string.
--
-- @return New error.
--
function crm.err.Node:__init(node, fmt)
    local e = err.Abstract:__init()

    assert(node ~= nil)

    e.node = node

    if fmt ~= nil then
        e.fmt = fmt
    end

    return oo.rawnew(self, e)
end


---
-- Format error message.
--
-- @return Error message.
--
function crm.err.Node:msg()
    local s = self.node.branch_title_list()

    assert(self.fmt ~= nil)

    s[#s] = string.format(intl.gettext(self.fmt), s[#s])

    return table.concat(s, ": ")
end


return crm.err.Node
