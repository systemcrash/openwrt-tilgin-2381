---
-- Object-oriented Lua CRM interface - node.
-- @release $Id$
--


local intl          = require("intl")
local oo            = require("loop.simple")
local err           = require("err")
local crm           = {}
crm.err             = require("crm.err")
crm.value_type      = require("crm.value_type")
crm.value           = require("crm.value")
crm.status          = require("crm.status")
crm.node            = {}
crm.node.key        = {}
crm.node.key.PARENT = {}
crm.node.key.PATH   = {}
crm.node.key.SUFFIX = {}
crm.node.key.TITLE  = {}
crm.node.key.ITITLE = {}

local KEY_PARENT    = crm.node.key.PARENT
local KEY_PATH      = crm.node.key.PATH
local KEY_SUFFIX    = crm.node.key.SUFFIX
local KEY_TITLE     = crm.node.key.TITLE
local KEY_ITITLE    = crm.node.key.ITITLE



---
-- Create node.
--
-- @param parent    Parent node.
-- @param suffix    Path suffix.
--
-- @return New node.
--
local mt = {}
function mt:__call(parent, suffix)
    assert(parent ~= nil)
    assert(suffix ~= nil)

    return setmetatable({[KEY_PARENT] = parent,
                         [KEY_SUFFIX] = tostring(suffix)}, self)
end
setmetatable(crm.node, mt)


---
-- Create root node; in effect, a node without suffix and with transaction
-- as the parent.
--
-- @param transaction   Transaction.
--
-- @return New root node.
--
function crm.node.root(transaction)
    return crm.node(transaction, "")
end


---
-- Create child node with specified suffix.
--
-- @param suffix    Child node path suffix.
--
-- @return New child node.
--
function crm.node:__index(suffix)
    return crm.node(self, suffix)
end


---
-- Get node tree root.
--
-- @return Root node.
--
function crm.node:get_root()
    local parent = rawget(self, KEY_PARENT)

    while getmetatable(parent) == crm.node do
        self = parent
        parent = rawget(self, KEY_PARENT)
    end

    return self
end


---
-- Get node transaction.
--
-- @return Transaction.
--
function crm.node:get_transaction()
    repeat
        self = rawget(self, KEY_PARENT)
    until getmetatable(self) ~= crm.node

    return self
end


---
-- Get node origin, in effect a transaction/path pair.
--
-- @param tail  Optional suffix string or array to append to the path.
--
-- @return Transaction and node path.
--
function crm.node:get_origin(tail)
    local path      = rawget(self, KEY_PATH)
    
    if tail == nil then
        tail = {}
    else
        if type(tail) ~= "table" then
            tail = {tail}
        end
    end

    if path ~= nil then
        table.insert(tail, 1, path)
        return self.get_transaction(), table.concat(tail, "/")
    else
        local parent    = rawget(self, KEY_PARENT)

        table.insert(tail, 1, rawget(self, KEY_SUFFIX))

        if getmetatable(parent) ~= crm.node then
            return parent, table.concat(tail, "/")
        end

        return parent.get_origin(tail)
    end
end


---
-- Get node path.
--
-- @param tail  Optional suffix string or array to append to the path.
--
-- @return Node path.
--
function crm.node:get_path(tail)
    local path      = rawget(self, KEY_PATH)
    
    if tail == nil then
        tail = {}
    else
        if type(tail) ~= "table" then
            tail = {tail}
        end
    end

    if path ~= nil then
        table.insert(tail, 1, path)
        return table.concat(tail, "/")
    else
        local parent    = rawget(self, KEY_PARENT)

        table.insert(tail, 1, rawget(self, KEY_SUFFIX))

        if getmetatable(parent) ~= crm.node then
            return table.concat(tail, "/")
        end

        return parent.get_path(tail)
    end
end


---
-- Get node name, in effect the last item in the CRM path.
--
-- @return Node name
--
function crm.node:get_name()
    return string.match(
                string.match(self.get_path(), "^(.-)/*$"),
                "([^/]*)$")
end


---
-- Set node title
--
-- @param title     Node title.
--
-- @return Node with title set.
--
function crm.node:aka(title)
    rawset(self, KEY_TITLE, title)
    return self
end


---
-- Set node item title
--
-- @param ititle    Node item title.
--
-- @return Node with item title set.
--
function crm.node:iaka(ititle)
    rawset(self, KEY_ITITLE, ititle)
    return self
end


---
-- Format node title.
--
-- @param subtitle  Optional sub-node title.
--
-- @return Node title: either this node title specified with aka(), or
--         parent node item title set with iaka() and formatted with this
--         node suffix.
--
function crm.node:title()
    local title = rawget(self, KEY_TITLE)

    if not title then
        local parent    = rawget(self, KEY_PARENT)

        if getmetatable(parent) == crm.node then
            local fmt = rawget(parent, KEY_ITITLE)

            if fmt then
                title = string.format(fmt, rawget(self, KEY_SUFFIX))
            end
        end
    end

    return title
end


function crm.node:branch_title_list()
    local branch    = {}
    local title     = self.title()
    local path      = nil

    if title == nil then
        repeat

            if path == nil then
                local path = rawget(self, KEY_PATH)
                if path == nil then
                    table.insert(branch, 1, rawget(self, KEY_SUFFIX))
                else
                    table.insert(branch, 1, path)
                end
            end

            self = rawget(self, KEY_PARENT)
            if getmetatable(self) ~= crm.node then
                return {"<" .. table.concat(branch, "/") .. ">"}
            end

            title = self.title()
        until title ~= nil

        branch = {"<" .. table.concat(branch, "/") .. ">"}
    end

    table.insert(branch, 1, title)

    while true do
        self = rawget(self, KEY_PARENT)
        if getmetatable(self) ~= crm.node then
            break
        end

        title = self.title()
        if title ~= nil then
            table.insert(branch, 1, title)
        end
    end

    return branch
end


---
-- Set value for node path, as crm_value.
--
-- @return CRM value.
--
function crm.node:set(value)
    local transaction, path = crm.node.get_origin(self)
    local ok, e = pcall(
        function () value = transaction:set(path, value) end)

    if not ok then
        error(crm.err.Set(self):attach(e))
    end

    return value
end


---
-- Set value on child node path.
--
-- @param suffix    Child node path suffix.
-- @param value     Value to set.
--
-- @return Value just set.
--
function crm.node:__newindex(suffix, value)
    return self[suffix].set(value)
end


--
-- Create functions named like set_<type> which create CRM value with
-- specific type and then set it.
--
local n, f
for n, f in pairs(crm.value) do
    if string.sub(n, 1, 5) == "init_" then
        crm.node["set_" .. string.sub(n, 6)] = function (self, ...)
            local value
            local ok, e = pcall(
                function (...) value = f(crm.value(), ...) end, ...)

            if not ok then
                error(crm.err.Set(self):attach(e))
            end

            return self.set(value)
        end
    end
end


---
-- Execute action.
--
-- @param in_table  Input argument table.
-- @param out_list  Output argument name array.
--
-- @return Output arguments in the order specified by @e out.
--
function crm.node:exec(in_table, out_list)
    local ok, e
    local index, name, value
    local results = {}

    ok, e = pcall(function ()
        self.reset = crm.value.boolean(true)
    end)
    if not ok then
        -- Raise action reset error with status attached
        error(crm.err.ActionReset(self):
                attach(oo.instanceof(e, err.Abstract) and
                       e:match(crm.err.Status) or e))
    end

    if in_table then
        for name, value in pairs(in_table) do
            self[name] = value
        end
    end

    ok, e = pcall(function ()
        self.execute = crm.value.boolean(true)
    end)
    if not ok then
        -- Raise action execution error with status attached
        error(crm.err.ActionExecute(self):
                attach(oo.instanceof(e, err.Abstract) and
                       e:match(crm.err.Status) or e))
    end

    if out_list then
        for index, name in ipairs(out_list) do
            results[index] = self[name].get()
        end
    end

    ok, e = pcall(function ()
        self.reset = crm.value.boolean(true)
    end)
    if not ok then
        -- Raise action reset error with status attached
        error(crm.err.ActionReset(self):
                attach(oo.instanceof(e, err.Abstract) and
                       e:match(crm.err.Status) or e))
    end


    return unpack(results)
end


---
-- Call method on parent node with the name of this node
--
function crm.node:__call(...)
    local suffix = rawget(self, KEY_SUFFIX)
    local method = crm.node[suffix]
    local parent = rawget(self, KEY_PARENT)

    if type(method) ~= "function" then
        error(string.format("Unknown method \"%s\"", suffix))
    end

    return method(parent, ...)
end


---
-- Resolve node path, i.e. follow all symlinks (if any) and return resulting
-- path.
--
-- @return Real node path.
--
function crm.node:realpath()
    local transaction, path = crm.node.get_origin(self)
    local value
    local ok, e = pcall(
        function () value = transaction:realpath(path) end)

    if not ok then
        error(crm.err.Realpath(self):attach(e))
    end

    return value
end


---
-- Check CRM path existence.
--
-- @alg Try to retrieve parent path value (a set or a link resolved to a
--      set). If operation succeeds and the node name is within the
--      retrieved set, the node is considered existing. If operation
--      returned ENOENT, the node is considered non-existing. Any other
--      result raises an error.
--
-- @return True if node exists, false otherwise.
--
function crm.node:exists()
    local transaction, path = crm.node.get_origin(self)
    local exists
    local ok, e = pcall(
        function () exists = transaction:exists(path) end)

    if not ok then
        error(crm.err.Exists(self):attach(e))
    end

    return exists
end


---
-- Check CRM path existence.
--
-- @note DEPRECATED.
--
-- @alg Identical to 'exists'.
--
-- @return True if node exists, false otherwise.
--
crm.node.stat = crm.node.exists


---
-- Check CRM path readability.
--
-- @alg Try to get the value for node path. If operation succeeded the node
--      is considered readable. If operation returned EACCESS, the node is
--      considered non-readable. Any other result raises an error.
--
-- @return True if node is readable, false otherwise.
--
function crm.node:readable()
    local transaction, path = crm.node.get_origin(self)
    local readable
    local ok, e = pcall(
        function () readable = transaction:readable(path) end)

    if not ok then
        error(crm.err.Readable(self):attach(e))
    end

    return readable
end


---
-- Check CRM path writability.
--
-- @alg Retrieves node 'writable' property.
--
-- @return True if node is writable, false otherwise.
--
function crm.node:writable()
    local transaction, path = crm.node.get_origin(self)
    local writable
    local ok, e = pcall(
        function () writable = transaction:writable(path) end)

    if not ok then
        error(crm.err.Writable(self):attach(e))
    end

    return writable
end

---
-- Check CRM path visibility.
--
-- @alg If webui_access field exists for the node and
--      greater than access of the logged in user, return false.
--      Otherwise return true.
--
-- @return True if node is readable, false otherwise.
--
function crm.node:visible()
    local transaction, path = crm.node.get_origin(self)
    local readable
    local ok, e = pcall(
        function () readable = transaction:visible(path) end)

    if not ok then
        error(crm.err.Visible(self):attach(e))
    end

    return readable
end


---
-- Get value for node path, as crm_value.
--
-- @return CRM value.
--
function crm.node:get()
    local transaction, path = crm.node.get_origin(self)
    local value
    local ok, e = pcall(
        function () value = transaction:get(path) end)

    if not ok then
        error(crm.err.Get(self):attach(e))
    end

    return value
end

---
-- Try to get value for node path, as crm_value.
-- If no value in the CRM (ENOENT returned) then return nil
--
-- @return CRM value.
--
function crm.node:try_get()
    local transaction, path = crm.node.get_origin(self)
    local value
    local ok, e = pcall(
        function () value = transaction:get(path) end)

    if not ok then
        -- check if the error is ENOENT
        if oo.instanceof(e, crm.err.Status) and
           e.rc == crm.status.ENOENT then
            return nil
        else
            error(crm.err.Get(self):attach(e))
        end
    end

    return value
end

---
-- Check if a CRM node has creator, i.e. it has property "creator" which is
-- not an empty link.
--
-- @return True if the node has creator.
--
function crm.node:has_creator()
    local creator = self["."].creator.aka(_("creator"))

    return creator.exists() and creator.get_link():len() > 0
end


--
-- Create functions named like get_<type> which retrieve CRM value and then
-- get its contents.
--
local n, f
for n, f in pairs(crm.value) do
    if string.sub(n, 1, 4) == "get_" then
        crm.node[n] = function (self)
            local value = self.get()
            local result
            local ok, e = pcall(
                function () result = {f(value)} end)

            if not ok then
                error(crm.err.Get(self):attach(e))
            end

            return unpack(result)
        end
    end
end

--
-- Create functions named like try_get_<type> which retrieve CRM value
-- and then get its contents. If there is no such node (CRM call will
-- return CRM_ENOENT) then functions return nil.
--
local n, f
for n, f in pairs(crm.value) do
    if string.sub(n, 1, 4) == "get_" then
        crm.node["try_" .. n] = function (self)
            local value = self.try_get()
            local result

            if value == nil then 
                return nil
            else
                local ok, e = pcall(
                    function () result = {f(value)} end)

                if not ok then
                    error(crm.err.Get(self):attach(e))
                end

            end

            return unpack(result)
        end
    end
end

---
-- Dereference link node.
--
-- @return Self (with path set to link path, if the node is a link);
--         @e nil if the node is an empty link.
--
function crm.node:deref()
    local value = self.get()

    if value:get_type() == crm.value_type.LINK then
        local link = value:get_link()
        if #link == 0 then
            return nil
        end
        rawset(self, KEY_PATH, self:get_link())
    end

    return self
end


---
-- Get value for node path, as string.
--
-- @return CRM value.
--
function crm.node:as_string()
    local value     = self.get()
    local string
    local ok, e = pcall(
        function () string = value:as_string() end)

    if not ok then
        error(crm.err.Get(self):attach(e))
    end

    return string
end


---
-- Get value for node path, as number.
--
-- @return CRM value.
--
function crm.node:as_number()
    local value     = self.get()
    local number
    local ok, e = pcall(
        function () number = value:as_number() end)

    if not ok then
        error(crm.err.Get(self):attach(e))
    end

    return number
end


---
-- Get set value for node path, as sub-node iterator.
--
-- @return Sub-node iterator.
--
function crm.node:as_iter()
    local value = self.get()
    local array
    local ok, e = pcall(
        function () array = value:get_set_as_array() end)

    local ipairs_f, ipairs_s, ipairs_i
    local suffix

    if not ok then
        error(crm.err.Get(self):attach(e))
    end

    ipairs_f, ipairs_s, ipairs_i = ipairs(array)

    local fn = function ()
        ipairs_i, suffix    = ipairs_f(ipairs_s, ipairs_i)

        if suffix ~= nil then
            return suffix, self[suffix]
        end
    end

    return fn
end


---
-- Get set value for node path, as iterator over readable sub-nodes.
--
-- @return Permitted sub-node iterator.
--
function crm.node:as_iter_readable()
    local iter_fn = self.as_iter()

    return function ()
        while true do
            local suffix, node = iter_fn()

            if not suffix then
                return nil
            end

            if node.readable() then
                return suffix, node
            end
        end
    end
end


---
-- Check if the CRM node is an instance of the specified CRM type.
--
-- @param type  Type to check for.
--
-- @return True if this node is instance of @e type.
--
function crm.node:instanceof(type)
    local transaction   = self:get_transaction()

    return transaction:subtypeof(self["."].type.get_string(), type)
end


---
-- Subscribe to a value change.
--
-- @param tlock  Required possibility to open a transaction:
--                   nil             - no requirement
--                   crm.tc_type.RO  - read-only transaction
--                   crm.tc_type.RW  - read-write transaction
-- @param period Value checking period, milliseconds.
-- @param notify Notification callback function.
-- @param opaque Optional opaque data to pass to notification function.
--
-- ---
-- -- Notification function prototype.
-- -- @param mapi       MAPI.
-- -- @param path       Changed value path.
-- -- @param old        Old value.
-- -- @param new        New value.
-- -- @param opaque     Optional opaque data passed on subscription.
-- --
--
function crm.node:subscribe_change(tlock, period, notify, opaque)
    local transaction, path = crm.node.get_origin(self)
    local subscription
    local ok, e = pcall(
        function ()
            subscription =
                transaction:subscribe_change(path, tlock, period,
                                             notify, opaque)
        end)

    if not ok then
        error(crm.err.SubscribeChange(self):attach(e))
    end

    return subscription
end


return crm.node
