---
-- Object-oriented Lua CRM interface - status overlay.
-- @release $Id: $
--

return require("luacrm.status")
