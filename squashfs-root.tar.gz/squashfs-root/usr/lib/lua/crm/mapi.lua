---
-- Object-oriented Lua interface to CRM - MAPI.
-- @release $Id: $
--

local crm       = {}
crm.mapi        = require("luacrm.mapi")
crm.transaction = require("crm.transaction")


---
-- Create a transaction.
--
-- @return New transaction instance.
--
function crm.mapi:transaction()
    return crm.transaction(self);
end


return crm.mapi
