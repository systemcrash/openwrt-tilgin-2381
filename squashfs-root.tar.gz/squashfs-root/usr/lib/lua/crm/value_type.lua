---
-- Object-oriented Lua CRM interface - value type overlay.
-- @release $Id: $
--

return require("luacrm.value_type")
