---
-- Lua utilities - "reqfile" - keep a cache of file chunks
-- @release $Id: reqfile.lua 145030 2010-03-29 14:08:50Z nikolai.kondrashov $
--

local fs        = require("fs")
local reqfile   = {}

local meta  = {}

function meta.__call(t, path)
    local realpath  = fs.realpath(path)
    local m         = t[realpath]

    if (m == nil) then
        m = dofile(realpath)
        t[realpath] = m
    end

    return m
end

setmetatable(reqfile, meta)
_G.reqfile = reqfile
return reqfile
